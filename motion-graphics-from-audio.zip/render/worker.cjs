/* ── Server-side frame renderer: pipes JPEG frames to ffmpeg ── */
const fs = require('fs');
const { spawn } = require('child_process');
const { once } = require('events');
const { createCanvas, registerFont } = require('/home/user/sandbox/node_modules/canvas');
const ffmpegPath = require('/home/user/sandbox/node_modules/ffmpeg-static');
const { drawMotionFrame } = require('/tmp/motion-bundle.cjs');

const startFrame = Number(process.argv[2]);
const endFrame = Number(process.argv[3]); // exclusive
const outPath = process.argv[4];
const FPS = 30;
const W = 1280;
const H = 720;

const fdir = '/home/user/sandbox/fonts/';
[
  ['Regular', '400'],
  ['Medium', '500'],
  ['SemiBold', '600'],
  ['Bold', '700'],
  ['ExtraBold', '800'],
  ['Black', '900'],
].forEach(([n, w]) => registerFont(fdir + `Vazirmatn-${n}.ttf`, { family: 'Vazirmatn', weight: w }));
registerFont(fdir + 'Amiri-Regular.ttf', { family: 'Amiri', weight: '400' });
registerFont(fdir + 'Amiri-Bold.ttf', { family: 'Amiri', weight: '700' });

const { dur, env } = JSON.parse(fs.readFileSync('/tmp/envelope.json', 'utf8'));
const canvas = createCanvas(W, H);
const ctx = canvas.getContext('2d');

const ff = spawn(
  ffmpegPath,
  [
    '-y',
    '-loglevel',
    'error',
    '-f',
    'image2pipe',
    '-framerate',
    String(FPS),
    '-i',
    '-',
    '-an',
    '-c:v',
    'libx264',
    '-preset',
    'veryfast',
    '-crf',
    '21',
    '-pix_fmt',
    'yuv420p',
    '-g',
    '60',
    '-threads',
    '1',
    outPath,
  ],
  { stdio: ['pipe', 'ignore', 'inherit'] },
);

ff.on('error', (e) => {
  console.error('ffmpeg spawn error', e);
  process.exit(1);
});

(async () => {
  const t0 = Date.now();
  for (let i = startFrame; i < endFrame; i++) {
    const t = i / FPS;
    const idx = Math.min(env.length - 1, Math.max(0, Math.floor(t * 10)));
    const energy = env[idx] ?? 0.25;
    drawMotionFrame(ctx, t, W, H, energy, { showSubtitles: true, showHud: true }, dur);
    const jpg = canvas.toBuffer('image/jpeg', { quality: 0.94, chromaSubsampling: 2 });
    if (!ff.stdin.write(jpg)) {
      await once(ff.stdin, 'drain');
    }
    if (i % 300 === 0) {
      const el = (Date.now() - t0) / 1000;
      const done = i - startFrame + 1;
      const speed = done / el;
      console.log(
        `[${outPath}] frame ${i}/${endFrame} (${(((i - startFrame) / (endFrame - startFrame)) * 100).toFixed(1)}%) ` +
          `${speed.toFixed(1)} fps, eta ${Math.round((endFrame - i) / speed)}s`,
      );
    }
  }
  ff.stdin.end();
  await once(ff, 'close');
  console.log(`[${outPath}] DONE frames ${startFrame}..${endFrame} in ${Math.round((Date.now() - t0) / 1000)}s`);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
