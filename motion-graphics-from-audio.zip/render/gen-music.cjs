/* ── Offline music & SFX synthesizer for server-side MP4 render ── */
const fs = require('fs');
const SR = 32000;
const DUR = JSON.parse(fs.readFileSync('/tmp/envelope.json', 'utf8')).dur;
const N = Math.ceil(SR * DUR);
const { buildMixEvents } = require('/tmp/motion-bundle.cjs');
const events = buildMixEvents(DUR);

const music = new Float32Array(N);
const sfx = new Float32Array(N);

let seed = 987654321;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296;
};

function envAt(t, attack, hold, release, total) {
  if (t < 0 || t > total) return 0;
  if (t < attack) return t / attack;
  if (t < hold) return 1;
  return Math.max(0, 1 - (t - hold) / Math.max(0.001, release));
}

function addChord(start, freqs) {
  const total = 18;
  const startI = Math.floor(start * SR);
  const endI = Math.min(N, Math.floor((start + total) * SR));
  const notes = freqs.flatMap((f) => [f, f * 1.004, f * 2, f * 3, f / 2]);
  const amps = [0.016, 0.012, 0.005, 0.0025, 0.018];
  const phases = notes.map(() => rnd() * Math.PI * 2);
  for (let i = startI; i < endI; i++) {
    const t = (i - startI) / SR;
    const env = envAt(t, 3.6, 14, 4, total);
    if (env <= 0) continue;
    let s = 0;
    for (let k = 0; k < notes.length; k++) {
      s += Math.sin((2 * Math.PI * notes[k] * i) / SR + phases[k]) * amps[k % amps.length];
    }
    // subtle slow tremolo
    s *= 1 + 0.12 * Math.sin(2 * Math.PI * 0.09 * i / SR);
    music[i] += s * env;
  }
}

function addPluck(start, freq) {
  const total = 2.4;
  const startI = Math.floor(start * SR);
  const endI = Math.min(N, Math.floor((start + total) * SR));
  for (let i = startI; i < endI; i++) {
    const t = (i - startI) / SR;
    const env = Math.exp(-t / 0.34) * Math.min(1, t / 0.006);
    if (env < 0.0005) continue;
    const s =
      Math.sin((2 * Math.PI * freq * i) / SR) +
      0.4 * Math.sin((2 * Math.PI * freq * 2 * i) / SR) +
      0.18 * Math.sin((2 * Math.PI * freq * 3 * i) / SR);
    // echo taps
    const echo = 0.3 * envAt(t - 0.42, 0.004, 0.02, 0.9, total) + 0.09 * envAt(t - 0.84, 0.004, 0.02, 0.9, total);
    music[i] += s * env * 0.035 + s * echo * 0.03;
  }
}

function addChime(start, freq) {
  const total = 1.8;
  const startI = Math.floor(start * SR);
  const endI = Math.min(N, Math.floor((start + total) * SR));
  const partials = [1, 1.5, 2.02];
  for (let i = startI; i < endI; i++) {
    const t = (i - startI) / SR;
    const env = Math.exp(-t / 0.4) * Math.min(1, t / 0.008);
    let s = 0;
    for (let p = 0; p < partials.length; p++) {
      s += Math.sin((2 * Math.PI * freq * partials[p] * i) / SR) * (p === 0 ? 1 : 0.4);
    }
    sfx[i] += s * env * 0.045;
  }
}

function addWhoosh(start) {
  const total = 1.15;
  const startI = Math.floor(start * SR);
  const endI = Math.min(N, Math.floor((start + total) * SR));
  let lp = 0;
  for (let i = startI; i < endI; i++) {
    const t = (i - startI) / SR;
    const p = t / total;
    const cutoff = p < 0.55 ? 240 + (2100 - 240) * (p / 0.55) : 2100 - (2100 - 320) * ((p - 0.55) / 0.45);
    const a = Math.min(0.9, (2 * Math.PI * cutoff) / SR);
    const white = rnd() * 2 - 1;
    lp = lp + a * (white - lp);
    const env = p < 0.28 ? p / 0.28 : Math.exp(-(p - 0.28) / 0.25);
    sfx[i] += lp * env * 0.5;
  }
}

function addRiser(start) {
  const total = 3.5;
  const startI = Math.floor(start * SR);
  const endI = Math.min(N, Math.floor((start + total) * SR));
  let hp = 0;
  let lp = 0;
  for (let i = startI; i < endI; i++) {
    const t = (i - startI) / SR;
    const p = t / total;
    const cutoff = 300 + (4200 - 300) * Math.min(1, p / 0.75);
    const a = Math.min(0.95, (2 * Math.PI * cutoff) / SR);
    const white = rnd() * 2 - 1;
    lp = lp + a * (white - lp);
    hp = white - lp;
    const env = p < 0.75 ? p / 0.75 : Math.max(0, 1 - (p - 0.75) / 0.25);
    sfx[i] += hp * env * 0.16;
    sfx[i] += Math.sin(2 * Math.PI * (80 + 240 * p) * i / SR) * env * 0.02;
  }
}

let nc = 0,
  np = 0,
  nch = 0,
  nw = 0;
for (const ev of events) {
  if (ev.time > DUR - 0.5) continue;
  if (ev.type === 'chord' && ev.freqs) {
    addChord(ev.time, ev.freqs);
    nc++;
  } else if (ev.type === 'pluck' && ev.freq) {
    addPluck(ev.time, ev.freq);
    np++;
  } else if (ev.type === 'chime' && ev.freq) {
    addChime(ev.time, ev.freq);
    nch++;
  } else if (ev.type === 'whoosh') {
    addWhoosh(ev.time);
    nw++;
  } else if (ev.type === 'riser') {
    addRiser(ev.time);
  }
}
console.log(`synthesized chords=${nc} plucks=${np} chimes=${nch} whooshes=${nw}`);

function writeWav(path, buf, peakTarget) {
  // gentle end fades
  const fadeIn = SR * 2;
  const fadeOut = SR * 4;
  for (let i = 0; i < fadeIn && i < buf.length; i++) buf[i] *= i / fadeIn;
  for (let i = 0; i < fadeOut && i < buf.length; i++) buf[buf.length - 1 - i] *= i / fadeOut;
  let peak = 0;
  for (let i = 0; i < buf.length; i++) peak = Math.max(peak, Math.abs(buf[i]));
  const gain = peak > 0 ? peakTarget / peak : 1;
  const data = Buffer.alloc(buf.length * 2);
  for (let i = 0; i < buf.length; i++) {
    let v = Math.max(-1, Math.min(1, buf[i] * gain));
    data.writeInt16LE(Math.round(v * 32767), i * 2);
  }
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + data.length, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(SR, 24);
  header.writeUInt32LE(SR * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path, Buffer.concat([header, data]));
  console.log(path, 'written', (data.length / 1024 / 1024).toFixed(1), 'MB peak->', peakTarget);
}

writeWav('/tmp/music.wav', music, 0.42);
writeWav('/tmp/sfx.wav', sfx, 0.5);
console.log('music/sfx ready — duration', DUR.toFixed(2), 's');
