import { ArrayBufferTarget, Muxer } from 'mp4-muxer';
import { drawMotionFrame } from './renderer';
import { AUDIO_SRC_LOCAL, AUDIO_SRC_REMOTE, FALLBACK_DURATION } from './timeline';
import {
  DEFAULT_MIX,
  buildEnergyEnvelope,
  renderMixedAudioBuffer,
  type MixSettings,
} from './audioEngine';

export interface ExportProgress {
  phase: 'preparing' | 'encoding_audio' | 'rendering_video' | 'finalizing';
  percent: number;
  currentFrame: number;
  totalFrames: number;
  elapsedSec: number;
  etaSec: number;
  detail: string;
}

export interface ExportResult {
  blob: Blob;
  filename: string;
  sizeBytes: number;
  codecLabel: string;
  mimeType: string;
}

export interface ExportOptions {
  resolution: '720p' | '1080p';
  fps?: number;
  showSubtitles: boolean;
  showHud: boolean;
  mix?: MixSettings;
  signal?: AbortSignal;
  onProgress?: (p: ExportProgress) => void;
  onPreviewCanvas?: (canvas: HTMLCanvasElement) => void;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Explicitly load every font family/weight the canvas renderer uses */
export async function ensureCanvasFontsLoaded(): Promise<void> {
  const specs = [
    '700 40px "Amiri"',
    '400 40px "Amiri"',
    '500 20px "Vazirmatn"',
    '600 24px "Vazirmatn"',
    '700 24px "Vazirmatn"',
    '800 36px "Vazirmatn"',
  ];
  try {
    await Promise.all(specs.map((s) => document.fonts.load(s, 'بسم الله نصر ۱۲۳')));
    await document.fonts.ready;
  } catch {
    /* fonts may fail offline — canvas falls back to system fonts */
  }
}

/** Fetch the voice track with local→remote fallback */
export async function fetchVoiceArrayBuffer(): Promise<ArrayBuffer> {
  try {
    const r = await fetch(AUDIO_SRC_LOCAL);
    if (r.ok) return await r.arrayBuffer();
  } catch {
    /* try remote */
  }
  const r2 = await fetch(AUDIO_SRC_REMOTE);
  if (!r2.ok) throw new Error('دریافت فایل صوتی ناموفق بود.');
  return r2.arrayBuffer();
}

async function pickSupportedVideoConfig(width: number, height: number, fps: number) {
  const candidates: Array<{ webCodec: string; muxCodec: 'avc' | 'vp9'; label: string }> = [
    { webCodec: 'avc1.640028', muxCodec: 'avc', label: 'H.264 High' },
    { webCodec: 'avc1.4d002a', muxCodec: 'avc', label: 'H.264 Main' },
    { webCodec: 'avc1.42E01F', muxCodec: 'avc', label: 'H.264 Baseline' },
    { webCodec: 'avc1.42001E', muxCodec: 'avc', label: 'H.264 Constrained' },
    { webCodec: 'vp09.00.10.08', muxCodec: 'vp9', label: 'VP9' },
  ];
  const bitrate = width >= 1920 ? 5_600_000 : 3_000_000;
  for (const c of candidates) {
    try {
      const cfg: VideoEncoderConfig = {
        codec: c.webCodec,
        width,
        height,
        bitrate,
        framerate: fps,
      };
      const res = await VideoEncoder.isConfigSupported(cfg);
      if (res.supported) return { ...c, config: cfg };
    } catch {
      /* try next */
    }
  }
  return null;
}

async function pickSupportedAudioConfig() {
  const candidates = [
    { webCodec: 'mp4a.40.2', muxCodec: 'aac' as const, sampleRate: 44100, channels: 2, bitrate: 128_000, label: 'AAC-LC استریو' },
    { webCodec: 'mp4a.40.2', muxCodec: 'aac' as const, sampleRate: 44100, channels: 1, bitrate: 96_000, label: 'AAC-LC' },
    { webCodec: 'opus', muxCodec: 'opus' as const, sampleRate: 48000, channels: 2, bitrate: 128_000, label: 'Opus استریو' },
  ];
  for (const c of candidates) {
    try {
      const cfg: AudioEncoderConfig = {
        codec: c.webCodec,
        sampleRate: c.sampleRate,
        numberOfChannels: c.channels,
        bitrate: c.bitrate,
      };
      const res = await AudioEncoder.isConfigSupported(cfg);
      if (res.supported) return { ...c, config: cfg };
    } catch {
      /* try next */
    }
  }
  return null;
}

export function isWebCodecsSupported(): boolean {
  return (
    typeof VideoEncoder !== 'undefined' &&
    typeof AudioEncoder !== 'undefined' &&
    typeof VideoFrame !== 'undefined' &&
    typeof AudioData !== 'undefined'
  );
}

interface PreparedAudio {
  mixed: AudioBuffer;
  voice: AudioBuffer;
  totalDur: number;
}

/** Decode voice → render full mix (voice + music + SFX) at encoder sample-rate */
async function prepareMixedAudio(
  sampleRate: number,
  channels: number,
  mix: MixSettings,
  onStatus: (detail: string, percent: number) => void,
  signal?: AbortSignal,
): Promise<PreparedAudio> {
  onStatus('در حال دریافت و رمزگشایی صدای استاد…', 3);
  const bytes = await fetchVoiceArrayBuffer();
  const tempCtx = new AudioContext();
  let voice: AudioBuffer;
  try {
    voice = await tempCtx.decodeAudioData(bytes.slice(0));
  } finally {
    await tempCtx.close();
  }
  const totalDur = voice.duration > 0 ? voice.duration : FALLBACK_DURATION;

  onStatus('در حال ساخت موسیقی ملایم و افکت‌های صوتی (میکس آفلاین)…', 6);
  const mixed = await renderMixedAudioBuffer(voice, totalDur, sampleRate, channels, mix);
  if (signal?.aborted) throw new DOMException('عملیات لغو شد.', 'AbortError');
  return { mixed, voice, totalDur };
}

/** Encode an AudioBuffer via AudioEncoder into the muxer outputs */
async function encodeAudio(buffer: AudioBuffer, encoder: AudioEncoder, signal?: AbortSignal): Promise<void> {
  const chunkFrames = 1024;
  const totalSamples = buffer.length;
  const channels = buffer.numberOfChannels;
  const chanData: Float32Array[] = [];
  for (let ch = 0; ch < channels; ch++) chanData.push(buffer.getChannelData(ch));

  for (let offset = 0; offset < totalSamples; offset += chunkFrames) {
    if (signal?.aborted) throw new DOMException('تولید ویدیو توسط کاربر لغو شد.', 'AbortError');
    const count = Math.min(chunkFrames, totalSamples - offset);
    const planar = new Float32Array(count * channels);
    for (let ch = 0; ch < channels; ch++) {
      planar.set(chanData[ch].subarray(offset, offset + count), ch * count);
    }
    const audioData = new AudioData({
      format: 'f32-planar',
      sampleRate: buffer.sampleRate,
      numberOfFrames: count,
      numberOfChannels: channels,
      timestamp: Math.round((offset / buffer.sampleRate) * 1_000_000),
      data: planar,
    });
    encoder.encode(audioData);
    audioData.close();
    if (encoder.encodeQueueSize > 16) await sleep(2);
  }
  await encoder.flush();
}

/** ─────────── Main MP4 export: motion graphics + mixed audio ─────────── */
export async function exportMotionToMp4(opts: ExportOptions): Promise<ExportResult> {
  if (!isWebCodecsSupported()) {
    throw new Error(
      'مرورگر فعلی از WebCodecs پشتیبانی نمی‌کند. لطفاً از Chrome یا Edge نسخه جدید استفاده کنید.',
    );
  }
  const fps = opts.fps ?? 30;
  const width = opts.resolution === '1080p' ? 1920 : 1280;
  const height = opts.resolution === '1080p' ? 1080 : 720;
  const mix = opts.mix ?? DEFAULT_MIX;
  const startPerf = performance.now();

  const report = (phase: ExportProgress['phase'], percent: number, detail: string, frame = 0, total = 0) => {
    const elapsedSec = (performance.now() - startPerf) / 1000;
    opts.onProgress?.({
      phase,
      percent,
      currentFrame: frame,
      totalFrames: total,
      elapsedSec,
      etaSec:
        percent > 4 && percent < 99
          ? Math.round((elapsedSec / percent) * (100 - percent))
          : 0,
      detail,
    });
  };

  report('preparing', 1, 'در حال آماده‌سازی فونت‌ها و بررسی کدک‌ها…');
  await ensureCanvasFontsLoaded();

  const videoSupport = await pickSupportedVideoConfig(width, height, fps);
  if (!videoSupport) throw new Error('کدک ویدیویی سازگار برای ساخت MP4 در این مرورگر یافت نشد.');
  const audioSupport = await pickSupportedAudioConfig();
  if (!audioSupport) throw new Error('کدک صوتی سازگار (AAC/Opus) در این مرورگر یافت نشد.');

  const { mixed, voice, totalDur } = await prepareMixedAudio(
    audioSupport.sampleRate,
    audioSupport.channels,
    mix,
    (d, p) => report('preparing', p, d),
    opts.signal,
  );
  const totalFrames = Math.round(totalDur * fps);

  const muxer = new Muxer({
    target: new ArrayBufferTarget(),
    video: { codec: videoSupport.muxCodec, width, height, frameRate: fps },
    audio: {
      codec: audioSupport.muxCodec,
      numberOfChannels: audioSupport.channels,
      sampleRate: audioSupport.sampleRate,
    },
    fastStart: 'in-memory',
  });

  let encoderError: Error | null = null;
  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e) => {
      encoderError = e instanceof Error ? e : new Error(String(e));
    },
  });
  videoEncoder.configure(videoSupport.config);

  const audioEncoder = new AudioEncoder({
    output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
    error: (e) => {
      encoderError = e instanceof Error ? e : new Error(String(e));
    },
  });
  audioEncoder.configure(audioSupport.config);

  // 1) Audio first (fast)
  report('encoding_audio', 8, `رمزگذاری صدای میکس‌شده با ${audioSupport.label}…`);
  await encodeAudio(mixed, audioEncoder, opts.signal);
  audioEncoder.close();
  if (encoderError) throw encoderError;

  // 2) Video frames
  report('rendering_video', 12, 'در حال رندر فریم‌های موشن گرافیک…');
  const envelope = buildEnergyEnvelope(
    voice.getChannelData(0),
    voice.sampleRate,
    totalDur,
  );

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('ایجاد بوم گرافیکی ممکن نشد.');

  const videoWeight = 82; // percent reserved for video rendering
  for (let i = 0; i < totalFrames; i++) {
    if (opts.signal?.aborted) {
      videoEncoder.close();
      throw new DOMException('تولید ویدیو توسط کاربر لغو شد.', 'AbortError');
    }
    if (encoderError) throw encoderError;

    const timeSec = i / fps;
    const envIdx = Math.min(envelope.length - 1, Math.floor(timeSec * 10));
    const energy = envelope[envIdx] ?? 0.2;

    drawMotionFrame(ctx, timeSec, width, height, energy, {
      showSubtitles: opts.showSubtitles,
      showHud: opts.showHud,
    }, totalDur);

    const frame = new VideoFrame(canvas, {
      timestamp: Math.round((i * 1_000_000) / fps),
      duration: Math.round(1_000_000 / fps),
    });
    videoEncoder.encode(frame, { keyFrame: i % (fps * 2) === 0 });
    frame.close();

    while (videoEncoder.encodeQueueSize > 6) await sleep(4);
    if (i % 10 === 0) {
      opts.onPreviewCanvas?.(canvas);
      const vp = 12 + videoWeight * (i / totalFrames);
      const elapsedSec = (performance.now() - startPerf) / 1000;
      opts.onProgress?.({
        phase: 'rendering_video',
        percent: vp,
        currentFrame: i,
        totalFrames,
        elapsedSec,
        etaSec: i > 20 ? Math.round((elapsedSec / i) * (totalFrames - i)) : 0,
        detail: `رندر موشن گرافیک — فریم ${i.toLocaleString('fa-IR')} از ${totalFrames.toLocaleString('fa-IR')}`,
      });
    }
  }
  report('finalizing', 96, 'در حال نهایی‌سازی فایل MP4…');
  await videoEncoder.flush();
  videoEncoder.close();
  muxer.finalize();

  const blob = new Blob([muxer.target.buffer], { type: 'video/mp4' });
  return {
    blob,
    filename: `gamnasr-s1e5-motion-${opts.resolution}.mp4`,
    sizeBytes: blob.size,
    codecLabel: `${videoSupport.label} + ${audioSupport.label}`,
    mimeType: 'video/mp4',
  };
}

/** ─────────── Audio-only export: the full mix as an MP4/M4A file ─────────── */
export async function exportMixedAudioToMp4(
  mix: MixSettings,
  onProgress?: (p: ExportProgress) => void,
  signal?: AbortSignal,
): Promise<ExportResult> {
  if (typeof AudioEncoder === 'undefined') {
    throw new Error('مرورگر فعلی از AudioEncoder پشتیبانی نمی‌کند.');
  }
  const startPerf = performance.now();
  const report = (percent: number, detail: string) => {
    onProgress?.({
      phase: percent < 90 ? 'encoding_audio' : 'finalizing',
      percent,
      currentFrame: 0,
      totalFrames: 0,
      elapsedSec: (performance.now() - startPerf) / 1000,
      etaSec: 0,
      detail,
    });
  };

  const audioSupport = await pickSupportedAudioConfig();
  if (!audioSupport) throw new Error('کدک صوتی سازگار یافت نشد.');

  const { mixed } = await prepareMixedAudio(
    audioSupport.sampleRate,
    audioSupport.channels,
    mix,
    (d, p) => report(p, d),
    signal,
  );

  const muxer = new Muxer({
    target: new ArrayBufferTarget(),
    audio: {
      codec: audioSupport.muxCodec,
      numberOfChannels: audioSupport.channels,
      sampleRate: audioSupport.sampleRate,
    },
    fastStart: 'in-memory',
  });

  let encoderError: Error | null = null;
  const audioEncoder = new AudioEncoder({
    output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
    error: (e) => {
      encoderError = e instanceof Error ? e : new Error(String(e));
    },
  });
  audioEncoder.configure(audioSupport.config);

  report(90, 'رمزگذاری نهایی صدای میکس…');
  await encodeAudio(mixed, audioEncoder, signal);
  audioEncoder.close();
  if (encoderError) throw encoderError;
  muxer.finalize();

  const blob = new Blob([muxer.target.buffer], { type: 'audio/mp4' });
  return {
    blob,
    filename: `gamnasr-s1e5-mixed-audio.m4a`,
    sizeBytes: blob.size,
    codecLabel: audioSupport.label,
    mimeType: 'audio/mp4',
  };
}
