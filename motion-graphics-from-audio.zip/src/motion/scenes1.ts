import type { SceneContext } from './timeline';
import type { PillSpec } from './primitives';
import {
  clamp01,
  drawAudioAuraRing,
  drawCrescentMoon,
  drawGlowingText,
  drawNebula,
  drawPillCluster,
  drawSacredMandala,
  drawShootingStar,
  easeOutBack,
  easeOutCubic,
  lerp,
  seeded,
  withAlpha,
} from './primitives';

/** Convert pill fractions into absolute local-second pill specs */
export function pillsWithTimes(sc: SceneContext): PillSpec[] {
  return sc.chapter.pills.map((p) => ({
    x: p.x,
    y: p.y,
    label: p.label,
    icon: p.icon,
    at: p.atF * sc.localDur,
    color: p.color,
  }));
}

/* ════════════ SCENE 1: طلوعِ بسم‌الله — rising golden sun over dawn hills ════════════ */
export function drawSceneDawn(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;

  const sunRise = easeOutCubic(clamp01((t - 0.8) / 6.0));
  const sunY = lerp(520, 290, sunRise);
  const sunR = 78 + energy * 8;

  // Warm dawn glow behind hills
  const dawnGrad = ctx.createRadialGradient(cx, sunY, 10, cx, sunY, 380);
  dawnGrad.addColorStop(0, 'rgba(251, 191, 36, 0.34)');
  dawnGrad.addColorStop(0.5, 'rgba(251, 146, 60, 0.14)');
  dawnGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = dawnGrad;
  ctx.beginPath();
  ctx.arc(cx, sunY, 380, 0, Math.PI * 2);
  ctx.fill();

  // Rotating sunbeams
  ctx.save();
  ctx.translate(cx, sunY);
  ctx.rotate(globalT * 0.18);
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI * 2) / 16;
    ctx.save();
    ctx.rotate(a);
    const beamLen = 140 + Math.sin(globalT * 2 + i) * 18 + energy * 30;
    const g = ctx.createLinearGradient(sunR, 0, sunR + beamLen, 0);
    g.addColorStop(0, 'rgba(253, 224, 71, 0.48)');
    g.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(sunR * 0.85, -7);
    ctx.lineTo(sunR + beamLen, 0);
    ctx.lineTo(sunR * 0.85, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // Golden sun disc + audio aura
  drawAudioAuraRing(ctx, cx, sunY, sunR + 18, globalT, energy, chapter.accent);
  const orbGrad = ctx.createRadialGradient(cx - 18, sunY - 20, 8, cx, sunY, sunR);
  orbGrad.addColorStop(0, '#fef9c3');
  orbGrad.addColorStop(0.55, '#fbbf24');
  orbGrad.addColorStop(1, '#ea580c');
  ctx.fillStyle = orbGrad;
  ctx.beginPath();
  ctx.arc(cx, sunY, sunR, 0, Math.PI * 2);
  ctx.fill();

  // Verse inside sun halo
  const titlePop = easeOutBack(clamp01(t / 1.4));
  ctx.save();
  ctx.globalAlpha = clamp01(t / 1.0);
  drawGlowingText(
    ctx,
    'بِسْمِ اللَّهِ',
    cx,
    sunY - 6,
    `700 ${Math.round(30 * Math.min(1, titlePop + 0.2))}px "Amiri", serif`,
    '#1e1b4b',
    'rgba(255,255,255,0.6)',
    6,
  );
  ctx.restore();

  // Rolling dawn hills
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(120, 565);
  ctx.quadraticCurveTo(360, 460, 640, 520);
  ctx.quadraticCurveTo(920, 575, 1160, 480);
  ctx.lineTo(1160, 575);
  ctx.lineTo(120, 575);
  ctx.closePath();
  const hillGrad = ctx.createLinearGradient(0, 470, 0, 575);
  hillGrad.addColorStop(0, 'rgba(30, 41, 82, 0.92)');
  hillGrad.addColorStop(1, 'rgba(13, 18, 42, 0.96)');
  ctx.fillStyle = hillGrad;
  ctx.fill();
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Faint morning mandala on the sun axis
  drawSacredMandala(ctx, cx, sunY, 240, globalT * 0.05, chapter.accent, 0.07);

  drawPillCluster(ctx, cx, sunY, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 2: پرچمِ نصر — rising banner of divine victory ════════════ */
export function drawSceneNasr(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;

  // Radiant victory rays rotating slowly behind banner
  ctx.save();
  ctx.translate(cx, 300);
  ctx.rotate(globalT * 0.06);
  for (let i = 0; i < 20; i++) {
    const a = (i * Math.PI * 2) / 20;
    ctx.save();
    ctx.rotate(a);
    const len = 210 + Math.sin(globalT * 1.6 + i * 1.3) * 26 + energy * 40;
    const g = ctx.createLinearGradient(60, 0, len, 0);
    g.addColorStop(0, withAlpha(chapter.accent, 0.22));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(60, -16);
    ctx.lineTo(len, 0);
    ctx.lineTo(60, 16);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // Crescent moon
  const moonX = 270;
  const moonY = 150;
  drawCrescentMoon(ctx, moonX, moonY, 34, withAlpha(chapter.accent, 0.8), chapter.bgTop, chapter.bgBottom);

  // Floating lanterns rising
  for (let i = 0; i < 12; i++) {
    const seed = seeded(i * 13 + 5);
    const lx = 120 + seed * 1040;
    const ly = 600 - ((globalT * (12 + seed * 14) + seed * 700) % 620);
    const flick = 0.5 + 0.5 * Math.sin(globalT * 3 + i * 2.2);
    ctx.save();
    ctx.fillStyle = withAlpha(chapter.accent, 0.18 + flick * 0.22);
    ctx.shadowColor = withAlpha(chapter.accent, 0.9);
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(lx, ly, 2.6 + seed * 2.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Banner pole rising
  const poleRise = easeOutBack(clamp01(t / 1.8));
  const poleTop = lerp(600, 160, poleRise);
  const poleBot = 590;
  ctx.save();
  const poleGrad = ctx.createLinearGradient(cx - 6, 0, cx + 6, 0);
  poleGrad.addColorStop(0, '#78350f');
  poleGrad.addColorStop(0.5, '#fbbf24');
  poleGrad.addColorStop(1, '#92400e');
  ctx.strokeStyle = poleGrad;
  ctx.lineWidth = 8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(cx, poleBot);
  ctx.lineTo(cx, poleTop);
  ctx.stroke();
  // Ornament on top
  ctx.fillStyle = '#fde047';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 16;
  ctx.beginPath();
  ctx.arc(cx, poleTop - 10, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Waving banner cloth
  const clothW = 250;
  const clothH = 150;
  const clothTop = poleTop + 4;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx, clothTop);
  for (let i = 0; i <= 20; i++) {
    const fx = i / 20;
    const x = cx - fx * clothW; // flies to the left (RTL breeze)
    const y = clothTop + Math.sin(globalT * 3.2 + fx * 5) * 10 * fx;
    ctx.lineTo(x, y);
  }
  for (let i = 20; i >= 0; i--) {
    const fx = i / 20;
    const x = cx - fx * clothW;
    const y = clothTop + clothH * (1 - fx * 0.22) + Math.sin(globalT * 3.2 + fx * 5 + 1.2) * 12 * fx;
    ctx.lineTo(x, y);
  }
  ctx.closePath();
  const clothGrad = ctx.createLinearGradient(cx, clothTop, cx - clothW, clothTop + clothH);
  clothGrad.addColorStop(0, '#4c1d95');
  clothGrad.addColorStop(0.55, '#6d28d9');
  clothGrad.addColorStop(1, '#312e81');
  ctx.fillStyle = clothGrad;
  ctx.shadowColor = withAlpha(chapter.accent, 0.55);
  ctx.shadowBlur = 26;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha(chapter.accent, 0.7);
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Emblem on banner
  ctx.save();
  ctx.globalAlpha = clamp01((t - 1.2) / 1.0);
  drawGlowingText(
    ctx,
    'نَصْرٌ مِّنَ اللَّهِ',
    cx - clothW * 0.52,
    clothTop + clothH * 0.42 + Math.sin(globalT * 3.2 + 2) * 3,
    '700 26px "Amiri", serif',
    '#fde68a',
    withAlpha(chapter.accent, 0.9),
    14,
  );
  ctx.restore();

  // Ground silhouette
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(0, 590);
  ctx.lineTo(1280, 590);
  ctx.lineTo(1280, 640);
  ctx.lineTo(0, 640);
  ctx.closePath();
  ctx.fillStyle = 'rgba(10, 10, 30, 0.9)';
  ctx.fill();
  ctx.restore();

  drawSacredMandala(ctx, cx, 300, 250, -globalT * 0.04, chapter.accent, 0.06);

  drawPillCluster(ctx, cx, 300, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 3: تسبیحِ آفاق — ringed planet, tasbih beads & shooting stars ════════════ */
export function drawSceneCosmos(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const cy = 330;

  drawNebula(ctx, 240, 180, 260, chapter.accentSecondary, 0.08, 0.5);
  drawNebula(ctx, 1040, 480, 300, chapter.accent, 0.07, -0.8);

  // Shooting stars on a deterministic schedule
  for (let s = 0; s < 3; s++) {
    const cyc = (globalT * 0.14 + s * 0.37) % 1;
    if (cyc < 0.22) {
      const prog = cyc / 0.22;
      const sx = 200 + s * 380 + prog * 500;
      const sy = 90 + s * 70 + prog * 130;
      drawShootingStar(ctx, sx, sy, 90, 0.42, Math.sin(prog * Math.PI) * 0.9, s % 2 ? '#fcd34d' : '#a5f3fc');
    }
  }

  // Planet glow + audio aura
  drawAudioAuraRing(ctx, cx, cy, 132, globalT, energy, chapter.accent);

  // Planet body with banding
  ctx.save();
  const planetR = 104;
  const pg = ctx.createRadialGradient(cx - 30, cy - 34, 12, cx, cy, planetR);
  pg.addColorStop(0, '#a7f3d0');
  pg.addColorStop(0.45, '#34d399');
  pg.addColorStop(0.8, '#0f766e');
  pg.addColorStop(1, '#134e4a');
  ctx.fillStyle = pg;
  ctx.beginPath();
  ctx.arc(cx, cy, planetR, 0, Math.PI * 2);
  ctx.fill();
  // Rotating bands
  ctx.clip();
  for (let i = 0; i < 5; i++) {
    const bandY = cy - 60 + i * 30 + Math.sin(globalT * 0.6 + i) * 5;
    ctx.strokeStyle = `rgba(6, 78, 59, ${0.25 + 0.1 * Math.sin(i + globalT)})`;
    ctx.lineWidth = 5 + i;
    ctx.beginPath();
    ctx.ellipse(cx, bandY, planetR + 6, 9 + i * 2.4, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();

  // Elliptical ring
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-0.35);
  ctx.strokeStyle = withAlpha(chapter.accentSecondary, 0.55);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.ellipse(0, 0, 205, 58, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = withAlpha('#e2e8f0', 0.18);
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.ellipse(0, 0, 226, 66, 0, 0, Math.PI * 2);
  ctx.stroke();
  // Moon orbiting the ring
  const mAng = globalT * 0.9;
  const mx = Math.cos(mAng) * 205;
  const my = Math.sin(mAng) * 58;
  const front = Math.sin(mAng) > 0;
  if (front) {
    ctx.fillStyle = '#fcd34d';
    ctx.shadowColor = '#fcd34d';
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(mx, my, 7, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // Tasbih ring — 33 beads, active bead glows & advances with time
  const beads = 33;
  const rBead = 168;
  const active = Math.floor(globalT * 1.6) % beads;
  for (let i = 0; i < beads; i++) {
    const a = (i / beads) * Math.PI * 2 - Math.PI / 2 + globalT * 0.07;
    const bx = cx + Math.cos(a) * rBead;
    const by = cy + Math.sin(a) * rBead;
    const isActive = i === active;
    const bs = isActive ? 6.4 : 3.4;
    ctx.save();
    if (isActive) {
      ctx.shadowColor = chapter.accent;
      ctx.shadowBlur = 16;
    }
    ctx.fillStyle = isActive ? chapter.accent : withAlpha(chapter.accent, 0.35);
    ctx.beginPath();
    ctx.arc(bx, by, bs, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  // "سبحان الله" counter inside orbit
  ctx.save();
  ctx.globalAlpha = 0.9;
  drawGlowingText(ctx, 'سُبْحَانَهُ', cx, cy + planetR + 44, '700 24px "Amiri", serif', '#d1fae5', withAlpha(chapter.accent, 0.8), 10);
  ctx.restore();

  drawSacredMandala(ctx, cx, cy, 235, globalT * 0.045, chapter.accent, 0.05);

  drawPillCluster(ctx, cx, cy, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 4: انفس — beating heart of light with EKG pulse ════════════ */
export function drawSceneHeart(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const cy = 310;

  // Nebulae
  drawNebula(ctx, 300, 200, 280, chapter.accent, 0.1, 0.3);
  drawNebula(ctx, 980, 460, 260, chapter.accentSecondary, 0.08, -0.6);

  // Aura behind heart
  drawAudioAuraRing(ctx, cx, cy, 118, globalT, energy, chapter.accent);

  // Parametric heart
  const beat = 1 + 0.045 * Math.sin(globalT * Math.PI * 2.2) + energy * 0.09;
  const scale = 6.2 * beat;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  for (let i = 0; i <= 100; i++) {
    const th = (i / 100) * Math.PI * 2;
    const hx = 16 * Math.pow(Math.sin(th), 3);
    const hy = -(13 * Math.cos(th) - 5 * Math.cos(2 * th) - 2 * Math.cos(3 * th) - Math.cos(4 * th));
    const x = hx * scale;
    const y = hy * scale;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  const hg = ctx.createRadialGradient(-30, -40, 10, 0, 0, 110);
  hg.addColorStop(0, '#ffe4e6');
  hg.addColorStop(0.45, '#fb7185');
  hg.addColorStop(1, '#9f1239');
  ctx.fillStyle = hg;
  ctx.shadowColor = withAlpha(chapter.accent, 0.75);
  ctx.shadowBlur = 34;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha('#fecdd3', 0.8);
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Verse inside heart
  ctx.save();
  ctx.globalAlpha = clamp01((t - 0.8) / 1.2);
  drawGlowingText(ctx, 'ذِكْرُ اللَّهِ', cx, cy + 4, '700 27px "Amiri", serif', '#fff1f2', withAlpha(chapter.accent, 0.9), 12);
  ctx.restore();

  // EKG pulse line across the screen with a traveling spike
  const ekgY = 486;
  const spikeX = ((globalT * 190) % 1500) - 110;
  ctx.save();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.75);
  ctx.lineWidth = 2.4;
  ctx.shadowColor = withAlpha(chapter.accent, 0.8);
  ctx.shadowBlur = 8;
  ctx.beginPath();
  for (let x = 0; x <= 1280; x += 4) {
    const d = x - spikeX;
    let y = ekgY;
    if (d > -70 && d < -50) y -= 8 * Math.sin(((d + 70) / 20) * Math.PI); // p-wave
    else if (d >= -50 && d < -34) y += 14 * Math.sin(((d + 50) / 16) * Math.PI); // q
    else if (d >= -34 && d < -18) y -= 52 * Math.sin(((d + 34) / 16) * Math.PI); // R spike
    else if (d >= -18 && d < -4) y += 18 * Math.sin(((d + 18) / 14) * Math.PI); // s
    else if (d > 20 && d < 60) y -= 14 * Math.sin(((d - 20) / 40) * Math.PI); // t-wave
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  // Traveling bright dot
  if (spikeX > 0 && spikeX < 1280) {
    ctx.fillStyle = '#fff1f2';
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(spikeX, ekgY - 40, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // Rising light particles
  for (let i = 0; i < 16; i++) {
    const seed = seeded(i * 7 + 3);
    const px = 140 + seed * 1000;
    const py = 590 - ((globalT * (14 + seed * 20) + seed * 600) % 560);
    ctx.fillStyle = withAlpha(i % 3 === 0 ? chapter.accentSecondary : '#fecdd3', 0.14 + seed * 0.2);
    ctx.beginPath();
    ctx.arc(px, py, 1.6 + seed * 2.6, 0, Math.PI * 2);
    ctx.fill();
  }

  drawSacredMandala(ctx, cx, cy, 235, -globalT * 0.04, chapter.accent, 0.06);

  drawPillCluster(ctx, cx, cy, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}


