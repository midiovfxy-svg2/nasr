/* ── Motion graphics drawing primitives — element-based visual language ── */

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp01(t), 3);
export const easeInCubic = (t: number) => Math.pow(clamp01(t), 3);
export const easeInOutCubic = (t: number) => {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
export const easeOutBack = (t: number) => {
  const x = clamp01(t);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
export const easeOutElastic = (t: number) => {
  const x = clamp01(t);
  if (x === 0 || x === 1) return x;
  const c4 = (2 * Math.PI) / 3;
  return Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
};

export function toFaDigits(input: string | number): string {
  const map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(input).replace(/\d/g, (d) => map[Number(d)]);
}

export function formatTimeFa(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${toFaDigits(String(m).padStart(2, '0'))}:${toFaDigits(String(r).padStart(2, '0'))}`;
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const n = parseInt(clean, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function lerpColor(hexA: string, hexB: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(hexA);
  const [r2, g2, b2] = hexToRgb(hexB);
  const k = clamp01(t);
  return `rgb(${Math.round(lerp(r1, r2, k))}, ${Math.round(lerp(g1, g2, k))}, ${Math.round(lerp(b1, b2, k))})`;
}

export function withAlpha(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${clamp01(alpha)})`;
}

export function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

/** Deterministic pseudo-random generator for stable starfields & dust motes across frames */
export function seeded(i: number): number {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

/** Slowly rotating sacred 8-pointed & 12-pointed Islamic geometric mandala */
export function drawSacredMandala(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  rot: number,
  color: string,
  alpha: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = 1.4;

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.84, 0, Math.PI * 2);
  ctx.stroke();

  for (let s = 0; s < 2; s++) {
    ctx.save();
    ctx.rotate((s * Math.PI) / 4);
    const side = radius * 1.18;
    ctx.strokeRect(-side / 2, -side / 2, side, side);
    ctx.restore();
  }

  ctx.beginPath();
  for (let i = 0; i < 12; i++) {
    const a = (i * Math.PI * 2) / 12;
    ctx.moveTo(Math.cos(a) * radius * 0.42, Math.sin(a) * radius * 0.42);
    ctx.lineTo(Math.cos(a) * radius * 0.96, Math.sin(a) * radius * 0.96);
  }
  ctx.stroke();

  ctx.beginPath();
  for (let i = 0; i <= 16; i++) {
    const a = (i * Math.PI * 2) / 16;
    const r = i % 2 === 0 ? radius * 0.42 : radius * 0.24;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

export function drawCosmicParticles(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  timeSec: number,
  accent: string,
  energy: number,
) {
  for (let i = 0; i < 64; i++) {
    const px = seeded(i * 3 + 1) * w;
    const py = ((seeded(i * 3 + 2) * h - timeSec * (4 + seeded(i) * 8)) % h + h) % h;
    const sz = 0.8 + seeded(i * 5) * 2.1;
    const twinkle = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(timeSec * (1.2 + seeded(i * 7) * 2.5) + i));
    ctx.fillStyle =
      i % 5 === 0
        ? withAlpha(accent, twinkle * (0.7 + energy * 0.5))
        : `rgba(226, 232, 240, ${twinkle * 0.55})`;
    ctx.beginPath();
    ctx.arc(px, py, sz, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function drawAudioAuraRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  baseRadius: number,
  timeSec: number,
  energy: number,
  color: string,
) {
  ctx.save();
  const r = baseRadius + energy * 18;
  const grad = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.45);
  grad.addColorStop(0, withAlpha(color, 0.26 + energy * 0.16));
  grad.addColorStop(0.6, withAlpha(color, 0.08));
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.45, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = withAlpha(color, 0.45 + energy * 0.35);
  ctx.lineWidth = 2;
  ctx.beginPath();
  const pts = 64;
  for (let i = 0; i <= pts; i++) {
    const a = (i / pts) * Math.PI * 2;
    const wave =
      Math.sin(a * 6 + timeSec * 3.5) * (3 + energy * 11) +
      Math.cos(a * 10 - timeSec * 2.2) * (2 + energy * 7);
    const rr = r + wave;
    const x = cx + Math.cos(a) * rr;
    const y = cy + Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

/** Kinetic floating Persian element pill with smooth pop-in & icon */
export function drawKineticPill(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  label: string,
  progress: number,
  accent: string,
  iconText?: string,
  scaleMult = 1,
) {
  if (progress <= 0.01) return;
  const s = easeOutBack(clamp01(progress)) * scaleMult;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.globalAlpha = clamp01(progress * 1.5);

  ctx.font = '700 20px "Vazirmatn", sans-serif';
  const tw = ctx.measureText(label).width;
  const iconSpace = iconText ? 34 : 0;
  const padX = 22;
  const w = tw + padX * 2 + iconSpace;
  const h = 44;

  ctx.shadowColor = withAlpha(accent, 0.45);
  ctx.shadowBlur = 18;
  drawRoundedRect(ctx, -w / 2, -h / 2, w, h, 22);
  ctx.fillStyle = 'rgba(10, 16, 36, 0.84)';
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.lineWidth = 1.6;
  ctx.strokeStyle = withAlpha(accent, 0.78);
  ctx.stroke();

  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  if (iconText) {
    ctx.fillStyle = accent;
    ctx.font = '700 20px "Vazirmatn", sans-serif';
    ctx.fillText(iconText, w / 2 - 24, 1);
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(label, -14, 1);
  } else {
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(label, 0, 1);
  }
  ctx.restore();
}

export function drawGlowingText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  font: string,
  fill: string,
  glowColor: string,
  glowBlur = 18,
  align: CanvasTextAlign = 'center',
) {
  ctx.save();
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = glowBlur;
  ctx.fillStyle = fill;
  ctx.fillText(text, x, y);
  ctx.restore();
}

/** Radial vignette to focus the eye toward center */
export function drawVignette(ctx: CanvasRenderingContext2D, w: number, h: number, strength = 0.5) {
  const g = ctx.createRadialGradient(w / 2, h / 2, h * 0.42, w / 2, h / 2, h * 0.95);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, `rgba(2,4,12,${strength})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

export interface PillSpec {
  x: number;
  y: number;
  label: string;
  icon: string;
  at: number; // local seconds
  color?: string;
}

/** Cluster of kinetic pills orbiting a focal point, connected by dashed light filaments */
export function drawPillCluster(
  ctx: CanvasRenderingContext2D,
  focalX: number,
  focalY: number,
  pills: PillSpec[],
  t: number,
  globalT: number,
  accent: string,
  energy = 0,
) {
  // Filaments first (behind pills)
  for (const p of pills) {
    const prog = clamp01((t - p.at) / 0.8);
    if (prog <= 0) continue;
    const floatY = Math.sin(globalT * 2 + p.x * 0.01) * 5;
    ctx.save();
    ctx.strokeStyle = withAlpha(p.color ?? accent, 0.35 * prog);
    ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 6]);
    ctx.lineDashOffset = -globalT * 24;
    ctx.beginPath();
    ctx.moveTo(focalX, focalY);
    const mx = (focalX + p.x) / 2 + Math.sin(globalT + p.x) * 14;
    const my = (focalY + p.y + floatY) / 2;
    ctx.quadraticCurveTo(mx, my, p.x, p.y + floatY);
    ctx.stroke();
    ctx.restore();
  }
  // Glowing node at focal
  const nodePulse = 0.5 + 0.5 * Math.sin(globalT * 2.4);
  ctx.save();
  ctx.fillStyle = withAlpha(accent, 0.16 + energy * 0.12);
  ctx.beginPath();
  ctx.arc(focalX, focalY, 46 + nodePulse * 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  // Pills on top
  for (const p of pills) {
    const prog = clamp01((t - p.at) / 0.8);
    if (prog <= 0) continue;
    const floatY = Math.sin(globalT * 2 + p.x * 0.01) * 5;
    drawKineticPill(ctx, p.x, p.y + floatY, p.label, prog, p.color ?? accent, p.icon);
  }
}

/** A shooting star with fading trail */
export function drawShootingStar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  len: number,
  angle: number,
  alpha: number,
  color: string,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  const g = ctx.createLinearGradient(0, 0, len, 0);
  g.addColorStop(0, withAlpha(color, 0));
  g.addColorStop(0.7, withAlpha(color, alpha * 0.5));
  g.addColorStop(1, withAlpha(color, alpha));
  ctx.strokeStyle = g;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(len, 0);
  ctx.stroke();
  ctx.fillStyle = withAlpha(color, alpha);
  ctx.beginPath();
  ctx.arc(len, 0, 2.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** Crescent moon without destructive compositing (bite is patched with sky gradient) */
export function drawCrescentMoon(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  glowColor: string,
  bgTop: string,
  bgBottom: string,
) {
  const bx = x + r * 0.42;
  const by = y - r * 0.18;
  const br = r * 0.86;
  ctx.save();
  // Full disc with glow
  ctx.fillStyle = '#e2e8f0';
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = 26;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Sky patch (drawn as the bite) — approximates background so no hole is punched
  ctx.save();
  const g = ctx.createLinearGradient(0, 0, 0, 720);
  g.addColorStop(0, bgTop);
  g.addColorStop(1, bgBottom);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(bx, by, br, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** Soft ambient nebula blob */
export function drawNebula(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  color: string,
  alpha: number,
  rot: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  const g = ctx.createRadialGradient(0, 0, radius * 0.1, 0, 0, radius);
  g.addColorStop(0, withAlpha(color, alpha));
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(0, 0, radius, radius * 0.6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
