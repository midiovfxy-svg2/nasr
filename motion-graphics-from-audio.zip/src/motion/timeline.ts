/* ── Adaptive timeline: 12 element-based chapters stretched over the FULL audio ── */

export const AUDIO_SRC_LOCAL = 'audio/nasr-s1-e5.mp3';
export const AUDIO_SRC_REMOTE =
  'https://raw.githubusercontent.com/midiovfxy-svg2/gamnasr/main/nasr-s1-e5.mp3';

/** Actual duration of nasr-s1-e5.mp3 (10:22, 128kbps 44.1kHz). Refined at runtime from metadata. */
export const FALLBACK_DURATION = 622.26;

export type SceneKey =
  | 'dawn_bismillah'
  | 'nasr_banner'
  | 'cosmos_tasbih'
  | 'heart_anfus'
  | 'city_abundance'
  | 'sabr_mountains'
  | 'noor_lamp'
  | 'dua_hands'
  | 'path_milestones'
  | 'ocean_calm'
  | 'seed_tree'
  | 'finale_hamd';

export interface PillDef {
  x: number;
  y: number;
  label: string;
  icon: string;
  atF: number; // fraction of the chapter duration
  color?: string;
}

export interface ChapterDef {
  id: number;
  sceneKey: SceneKey;
  from: number; // 0..1 fraction of total audio duration
  to: number;
  title: string;
  subtitle: string;
  badge: string;
  shortName: string;
  bgTop: string;
  bgBottom: string;
  accent: string;
  accentSecondary: string;
  verseAr: string;
  verseRef: string;
  pills: PillDef[];
  captions: string[];
}

export const CHAPTERS: ChapterDef[] = [
  {
    id: 1,
    sceneKey: 'dawn_bismillah',
    from: 0.0,
    to: 0.075,
    title: 'آغازِ روز، آغازِ نور',
    subtitle: 'با نامِ خدا، روزی تازه و دل‌هایی روشن',
    badge: 'فصل ۱ • طلوعِ بسم‌الله',
    shortName: 'طلوع',
    bgTop: '#0d102b',
    bgBottom: '#2b193d',
    accent: '#fbbf24',
    accentSecondary: '#fb923c',
    verseAr: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    verseRef: 'مفتاحِ همه‌ی خوبی‌ها',
    pills: [
      { x: 290, y: 235, label: 'طلوعِ تصدیق', icon: '☀', atF: 0.08 },
      { x: 990, y: 235, label: 'صبحِ روشن', icon: '✦', atF: 0.3 },
      { x: 245, y: 365, label: 'شکرِ نخست', icon: '♥', atF: 0.5 },
      { x: 1035, y: 365, label: 'قلبِ بیدار', icon: '◈', atF: 0.68 },
      { x: 350, y: 470, label: 'امیدِ روز', icon: '☼', atF: 0.85 },
    ],
    captions: [
      'هر آغاز، به نامِ او روشن می‌شود',
      'آفتابِ تصدیق، از اولِ صبح طلوع می‌کند',
      'قلبِ بیدار، روز را با نور آغاز می‌کند',
    ],
  },
  {
    id: 2,
    sceneKey: 'nasr_banner',
    from: 0.075,
    to: 0.16,
    title: 'نصر و فتحِ نزدیک',
    subtitle: 'یاری از الله می‌آید؛ گام‌های استوار به سوی فتح',
    badge: 'فصل ۲ • پرچمِ نصر',
    shortName: 'نصر',
    bgTop: '#0a0f2e',
    bgBottom: '#1e1b4b',
    accent: '#a78bfa',
    accentSecondary: '#818cf8',
    verseAr: 'إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ',
    verseRef: 'سوره نصر • آیه ۱',
    pills: [
      { x: 300, y: 220, label: 'فتحِ نزدیک', icon: '✦', atF: 0.1 },
      { x: 980, y: 220, label: 'یاریِ الهی', icon: '☀', atF: 0.3 },
      { x: 250, y: 355, label: 'صبرِ پیشرو', icon: '◆', atF: 0.48 },
      { x: 1030, y: 355, label: 'شکرِ پیروزی', icon: '♥', atF: 0.66 },
      { x: 340, y: 470, label: 'گامِ استوار', icon: '❖', atF: 0.82 },
      { x: 940, y: 470, label: 'بشارتِ آسمان', icon: '☾', atF: 0.92 },
    ],
    captions: [
      'یاری از الله می‌آید و فتحی نزدیک',
      'صبر و شکر، پیش‌قراولِ نصر است',
      'هر گامِ استوار، گامی به سوی فتح است',
    ],
  },
  {
    id: 3,
    sceneKey: 'cosmos_tasbih',
    from: 0.16,
    to: 0.25,
    title: 'تسبیحِ آسمان‌ها',
    subtitle: 'کهکشان‌ها، ماه‌ها و ستارگان؛ همه در حالِ ذکرند',
    badge: 'فصل ۳ • آفاقِ تسبیح',
    shortName: 'آفاق',
    bgTop: '#05152b',
    bgBottom: '#0b3536',
    accent: '#34d399',
    accentSecondary: '#fcd34d',
    verseAr: 'وَإِن مِّن شَيْءٍ إِلَّا يُسَبِّحُ بِحَمْدِهِ',
    verseRef: 'سوره اسراء • آیه ۴۴',
    pills: [
      { x: 285, y: 225, label: 'تسبیحِ ستارگان', icon: '✦', atF: 0.08 },
      { x: 995, y: 225, label: 'نظمِ کهکشان', icon: '◈', atF: 0.28 },
      { x: 240, y: 360, label: 'ماهِ نورانی', icon: '☾', atF: 0.46 },
      { x: 1040, y: 360, label: 'سیاره‌ی آرام', icon: '◉', atF: 0.64 },
      { x: 350, y: 475, label: 'ذکرِ بی‌پایان', icon: '∞', atF: 0.82 },
    ],
    captions: [
      'آسمان‌ها و زمین، مشغولِ تسبیح‌اند',
      'هر ستاره، نغمه‌ای از یادِ اوست',
      'نظمِ هستی، آرامشِ دلِ مؤمن است',
    ],
  },
  {
    id: 4,
    sceneKey: 'heart_anfus',
    from: 0.25,
    to: 0.33,
    title: 'انفس؛ دنیای درون',
    subtitle: 'قلبِ آرام با ذکر؛ تپشی برای یقین',
    badge: 'فصل ۴ • تپشِ قلب',
    shortName: 'انفس',
    bgTop: '#2a0f22',
    bgBottom: '#170f3a',
    accent: '#fb7185',
    accentSecondary: '#f472b6',
    verseAr: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
    verseRef: 'سوره رعد • آیه ۲۸',
    pills: [
      { x: 295, y: 225, label: 'ذکرِ دل', icon: '♥', atF: 0.1 },
      { x: 985, y: 225, label: 'آرامشِ یقین', icon: '✧', atF: 0.3 },
      { x: 250, y: 360, label: 'تپشِ ایمان', icon: '◉', atF: 0.48 },
      { x: 1035, y: 360, label: 'قلبِ سلیم', icon: '◈', atF: 0.66 },
      { x: 345, y: 472, label: 'نورِ درون', icon: '☀', atF: 0.84 },
    ],
    captions: [
      'آرامشِ واقعی، در ذکرِ دل لنگر می‌اندازد',
      'قلبِ سلیم، آینه‌ی نور است',
      'با هر تپش، فرصتی تازه برای یقین',
    ],
  },
  {
    id: 5,
    sceneKey: 'city_abundance',
    from: 0.33,
    to: 0.41,
    title: 'شهرِ فراوانی',
    subtitle: 'دیدنِ جریانِ نعمت‌ها و فیلترِ تصدیق در ورودیِ ذهن',
    badge: 'فصل ۵ • مدارِ شهر',
    shortName: 'فراوانی',
    bgTop: '#08182e',
    bgBottom: '#102d4a',
    accent: '#38bdf8',
    accentSecondary: '#fbbf24',
    verseAr: 'وَإِن تَعُدُّوا نِعْمَتَ اللَّهِ لَا تُحْصُوهَا',
    verseRef: 'سوره ابراهیم • آیه ۳۴',
    pills: [
      { x: 290, y: 220, label: 'فراوانیِ شهر', icon: '✦', atF: 0.1 },
      { x: 990, y: 220, label: 'فیلترِ تصدیق', icon: '◈', atF: 0.3 },
      { x: 245, y: 360, label: 'نعمتِ بی‌شمار', icon: '∞', atF: 0.48 },
      { x: 1035, y: 360, label: 'جریانِ خوبی', icon: '✧', atF: 0.66 },
      { x: 350, y: 472, label: 'شکرِ روزانه', icon: '♥', atF: 0.84 },
    ],
    captions: [
      'فراوانی، از دیدنِ نعمت آغاز می‌شود',
      'ذهنِ بیدار، ورودی‌هایش را تصدیق می‌کند',
      'شکر، آستانه‌ی ریزشِ نعمت‌هاست',
    ],
  },
  {
    id: 6,
    sceneKey: 'sabr_mountains',
    from: 0.41,
    to: 0.5,
    title: 'کوه‌های صبر',
    subtitle: 'با هر عُسری، یُسری؛ قدم‌های بلند با یقین',
    badge: 'فصل ۶ • قله‌ی صبر',
    shortName: 'صبر',
    bgTop: '#0b1226',
    bgBottom: '#1f2937',
    accent: '#a5b4fc',
    accentSecondary: '#e2e8f0',
    verseAr: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    verseRef: 'سوره شرح • آیه ۶',
    pills: [
      { x: 295, y: 215, label: 'کوهِ صبر', icon: '▲', atF: 0.1 },
      { x: 985, y: 215, label: 'قدمِ استوار', icon: '❖', atF: 0.3 },
      { x: 250, y: 350, label: 'یقینِ بلند', icon: '✦', atF: 0.48 },
      { x: 1035, y: 350, label: 'آسانیِ همراه', icon: '☀', atF: 0.66 },
      { x: 350, y: 468, label: 'قله‌ی رستگاری', icon: '★', atF: 0.84 },
    ],
    captions: [
      'با هر سخت، آسانی همراه است',
      'کوه‌ها با صبر، قله می‌سازند',
      'یقین، تکیه‌گاهِ قدم‌های بلند است',
    ],
  },
  {
    id: 7,
    sceneKey: 'noor_lamp',
    from: 0.5,
    to: 0.585,
    title: 'نورِ آسمان‌ها',
    subtitle: 'مشکاةِ دل؛ شعله‌ای که هدایت می‌دهد',
    badge: 'فصل ۷ • چراغِ نور',
    shortName: 'نور',
    bgTop: '#1a1206',
    bgBottom: '#3b2708',
    accent: '#fcd34d',
    accentSecondary: '#fb923c',
    verseAr: 'اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ',
    verseRef: 'سوره نور • آیه ۳۵',
    pills: [
      { x: 290, y: 220, label: 'چراغِ دل', icon: '✦', atF: 0.1 },
      { x: 990, y: 220, label: 'شعله‌ی ایمان', icon: '✧', atF: 0.3 },
      { x: 248, y: 360, label: 'مشکاةِ نور', icon: '◉', atF: 0.48 },
      { x: 1032, y: 360, label: 'زیتونِ روشنایی', icon: '◈', atF: 0.66 },
      { x: 350, y: 472, label: 'تابشِ هدایت', icon: '☀', atF: 0.84 },
    ],
    captions: [
      'نورِ او بر آسمان‌ها و زمین می‌تابد',
      'چراغِ دل، روشنایی‌اش از ایمان است',
      'در تاریکی، یک شعله برای هزار راه کافی است',
    ],
  },
  {
    id: 8,
    sceneKey: 'dua_hands',
    from: 0.585,
    to: 0.67,
    title: 'دعا؛ بالِ آرزوها',
    subtitle: 'صدای دل به آسمان می‌رسد و درها باز می‌شوند',
    badge: 'فصل ۸ • دست‌های به آسمان',
    shortName: 'دعا',
    bgTop: '#170b2e',
    bgBottom: '#2a1245',
    accent: '#c084fc',
    accentSecondary: '#f0abfc',
    verseAr: 'ادْعُونِي أَسْتَجِبْ لَكُمْ',
    verseRef: 'سوره غافر • آیه ۶۰',
    pills: [
      { x: 295, y: 220, label: 'صدای دل', icon: '✧', atF: 0.1 },
      { x: 985, y: 220, label: 'باز شدنِ درها', icon: '◈', atF: 0.3 },
      { x: 250, y: 358, label: 'اجابتِ نزدیک', icon: '✦', atF: 0.48 },
      { x: 1035, y: 358, label: 'امیدِ دعا', icon: '♥', atF: 0.66 },
      { x: 350, y: 470, label: 'آرامشِ نیاز', icon: '☾', atF: 0.84 },
    ],
    captions: [
      'بخوانید مرا تا شما را پاسخ دهم',
      'دعا، بالِ پروازِ آرزوهاست',
      'دست‌های به آسمان، خالی برنمی‌گردند',
    ],
  },
  {
    id: 9,
    sceneKey: 'path_milestones',
    from: 0.67,
    to: 0.75,
    title: 'مسیرِ نشانه‌ها',
    subtitle: 'صراطِ مستقیم؛ هر قدم یک نشانه، هر ایستگاه یک فصل',
    badge: 'فصل ۹ • جاده‌ی نور',
    shortName: 'مسیر',
    bgTop: '#061a24',
    bgBottom: '#0b3550',
    accent: '#22d3ee',
    accentSecondary: '#67e8f9',
    verseAr: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
    verseRef: 'سوره حمد • آیه ۶',
    pills: [
      { x: 290, y: 218, label: 'صراطِ مستقیم', icon: '❯', atF: 0.1 },
      { x: 990, y: 218, label: 'نشانه‌های راه', icon: '❖', atF: 0.3 },
      { x: 248, y: 358, label: 'ایستگاهِ نور', icon: '◈', atF: 0.48 },
      { x: 1035, y: 358, label: 'قدمِ امروز', icon: '✦', atF: 0.66 },
      { x: 350, y: 470, label: 'هدفِ بلند', icon: '★', atF: 0.84 },
    ],
    captions: [
      'راهِ راست، روشن و استوار است',
      'هر قدم، یک نشانه؛ هر ایستگاه، یک فصل',
      'مسیرِ خوبی‌ها، خودش مقصد می‌شود',
    ],
  },
  {
    id: 10,
    sceneKey: 'ocean_calm',
    from: 0.75,
    to: 0.83,
    title: 'آرامشِ دریا',
    subtitle: 'امواج می‌آیند و می‌روند؛ لنگرگاه ثابت است',
    badge: 'فصل ۱۰ • موج‌های آرام',
    shortName: 'دریا',
    bgTop: '#020a1c',
    bgBottom: '#0a2547',
    accent: '#60a5fa',
    accentSecondary: '#a5f3fc',
    verseAr: 'وَهُوَ الَّذِي سَخَّرَ الْبَحْرَ',
    verseRef: 'سوره نحل • آیه ۱۴',
    pills: [
      { x: 290, y: 220, label: 'دریای آرام', icon: '≈', atF: 0.1 },
      { x: 990, y: 220, label: 'موج‌های شکر', icon: '✧', atF: 0.3 },
      { x: 248, y: 360, label: 'کشتیِ امید', icon: '⚓', atF: 0.48 },
      { x: 1035, y: 360, label: 'لنگرگاهِ دل', icon: '◈', atF: 0.66 },
      { x: 350, y: 472, label: 'گذرِ توفان', icon: '☾', atF: 0.84 },
    ],
    captions: [
      'دریا را مسخّر کرد تا آرام بگیریم',
      'امواج می‌آیند؛ آرامش می‌ماند',
      'توفان همیشه می‌گذرد؛ لنگرگاه ثابت است',
    ],
  },
  {
    id: 11,
    sceneKey: 'seed_tree',
    from: 0.83,
    to: 0.915,
    title: 'نهالِ امید',
    subtitle: 'ریشه‌ی استوار، شاخه‌های بلند می‌روید',
    badge: 'فصل ۱۱ • باغِ فردا',
    shortName: 'نهال',
    bgTop: '#071a12',
    bgBottom: '#14361f',
    accent: '#4ade80',
    accentSecondary: '#bbf7d0',
    verseAr: 'كَزَرْعٍ أَخْرَجَ شَطْأَهُ فَآزَرَهُ',
    verseRef: 'سوره فتح • آیه ۲۹',
    pills: [
      { x: 290, y: 218, label: 'ریشه‌ی یقین', icon: '❖', atF: 0.1 },
      { x: 990, y: 218, label: 'نهالِ امید', icon: '✿', atF: 0.3 },
      { x: 248, y: 356, label: 'شاخه‌های نور', icon: '✧', atF: 0.48 },
      { x: 1035, y: 356, label: 'برگ‌های شکر', icon: '☘', atF: 0.66 },
      { x: 350, y: 470, label: 'سایه‌بانِ فردا', icon: '☀', atF: 0.84 },
    ],
    captions: [
      'نهالِ امروز، سایه‌بانِ فرداست',
      'ریشه‌ی استوار، شاخه‌های بلند می‌روید',
      'هر دانه‌ی نیکی، درختِ امید می‌شود',
    ],
  },
  {
    id: 12,
    sceneKey: 'finale_hamd',
    from: 0.915,
    to: 1.0,
    title: 'الحمدلله؛ پایانِ روشن',
    subtitle: 'پایانِ هر خوبی، آغازِ حمد است — تا قسمتِ بعد',
    badge: 'فصل ۱۲ • حمدِ پایانی',
    shortName: 'حمد',
    bgTop: '#1a1206',
    bgBottom: '#422006',
    accent: '#fde047',
    accentSecondary: '#fbbf24',
    verseAr: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
    verseRef: 'سوره حمد • آیه ۲',
    pills: [],
    captions: [
      'الحمدلله بر همه‌ی نعمت‌ها',
      'پایانِ هر خوبی، آغازِ حمد است',
      'تا قسمتِ بعد؛ همراهِ گامِ نصر بمانید',
    ],
  },
];

export function chapterIndexAtProgress(p: number): number {
  const c = clamp(p, 0, 0.999999);
  for (let i = 0; i < CHAPTERS.length; i++) {
    if (c >= CHAPTERS[i].from && c < CHAPTERS[i].to) return i;
  }
  return CHAPTERS.length - 1;
}

export function chapterAtTime(timeSec: number, totalDur: number): ChapterDef {
  return CHAPTERS[chapterIndexAtProgress(totalDur > 0 ? timeSec / totalDur : 0)];
}

export function chapterStartTime(ch: ChapterDef, totalDur: number): number {
  return ch.from * totalDur;
}

export function chapterEndTime(ch: ChapterDef, totalDur: number): number {
  return ch.to * totalDur;
}

/** Which caption phrase is active (captions split evenly across chapter) */
export function captionForChapter(ch: ChapterDef, localT: number, localDur: number): string {
  if (ch.captions.length === 0) return '';
  const idx = Math.min(ch.captions.length - 1, Math.floor((localT / Math.max(0.001, localDur)) * ch.captions.length));
  return ch.captions[Math.max(0, idx)];
}

export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

/** Everything a scene needs to draw one frame */
export interface SceneContext {
  ctx: CanvasRenderingContext2D;
  t: number; // local time within chapter (seconds)
  localDur: number; // chapter duration in seconds
  globalT: number; // absolute audio time (seconds)
  energy: number; // smoothed audio energy 0..1
  chapter: ChapterDef;
  progress: number; // 0..1 within chapter
}
