import type { SceneContext } from './timeline';
import { CHAPTERS } from './timeline';
import { pillsWithTimes } from './scenes1';
import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawPillCluster,
  drawRoundedRect,
  drawSacredMandala,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from './primitives';

/* ════════════ SCENE 9: مسیرِ نشانه‌ها — perspective road of milestones ════════════ */
export function drawScenePath(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const horizonY = 400;

  // Sun at the vanishing point
  const sunR = 58 + energy * 6;
  ctx.save();
  const sg = ctx.createRadialGradient(cx, horizonY - 40, 8, cx, horizonY - 40, 300);
  sg.addColorStop(0, withAlpha(chapter.accent, 0.5));
  sg.addColorStop(0.5, withAlpha(chapter.accent, 0.14));
  sg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = sg;
  ctx.fillRect(0, 0, 1280, 720);
  ctx.restore();
  ctx.save();
  ctx.fillStyle = '#e0f2fe';
  ctx.shadowColor = chapter.accent;
  ctx.shadowBlur = 34;
  ctx.beginPath();
  ctx.arc(cx, horizonY - 40, sunR, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Sky grid receding
  ctx.save();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.1);
  ctx.lineWidth = 1;
  for (let i = 1; i <= 7; i++) {
    const gy = horizonY - i * i * 9 - 8;
    ctx.beginPath();
    ctx.moveTo(0, gy);
    ctx.lineTo(1280, gy);
    ctx.stroke();
  }
  ctx.restore();

  // Ground plane
  ctx.save();
  const gg = ctx.createLinearGradient(0, horizonY, 0, 720);
  gg.addColorStop(0, 'rgba(8, 47, 73, 0.9)');
  gg.addColorStop(1, 'rgba(2, 12, 27, 0.98)');
  ctx.fillStyle = gg;
  ctx.fillRect(0, horizonY, 1280, 320);
  ctx.restore();

  // Perspective road
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx - 330, 720);
  ctx.lineTo(cx - 36, horizonY + 4);
  ctx.lineTo(cx + 36, horizonY + 4);
  ctx.lineTo(cx + 330, 720);
  ctx.closePath();
  const rg = ctx.createLinearGradient(0, horizonY, 0, 720);
  rg.addColorStop(0, withAlpha(chapter.accent, 0.34));
  rg.addColorStop(1, 'rgba(3, 18, 34, 0.9)');
  ctx.fillStyle = rg;
  ctx.fill();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.75);
  ctx.lineWidth = 2.4;
  ctx.stroke();
  // Animated center dashes rushing toward viewer
  const dashOffset = (globalT * 0.9) % 1;
  for (let i = 0; i < 9; i++) {
    const f = (i + dashOffset) / 9;
    const df = Math.pow(f, 1.8);
    const y = horizonY + df * 320;
    const halfW = lerp(4, 26, df);
    const dh = lerp(8, 52, df);
    ctx.fillStyle = withAlpha('#e0f2fe', 0.28 + df * 0.6);
    drawRoundedRect(ctx, cx - halfW / 2, y, halfW, dh, halfW / 2);
    ctx.fill();
  }
  ctx.restore();

  // Milestone stones with chapter numbers along the roadside
  const stones = [
    { f: 0.18, side: -1, num: 1 },
    { f: 0.34, side: 1, num: 2 },
    { f: 0.5, side: -1, num: 3 },
    { f: 0.66, side: 1, num: 4 },
    { f: 0.82, side: -1, num: 5 },
  ];
  for (let i = 0; i < stones.length; i++) {
    const st = stones[i];
    const prog = clamp01((t - 1.2 - i * 1.6) / 0.7);
    if (prog <= 0) continue;
    const df = st.f;
    const y = horizonY + df * 300;
    const scale = lerp(0.35, 1.15, df);
    const roadHalfW = lerp(40, 320, df);
    const x = cx + st.side * (roadHalfW + lerp(30, 90, df));
    const s = easeOutBack(prog);
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(s, s);
    ctx.globalAlpha = prog;
    // Stone slab
    drawRoundedRect(ctx, -20 * scale, -58 * scale, 40 * scale, 60 * scale, 8 * scale);
    ctx.fillStyle = 'rgba(15, 40, 62, 0.94)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(chapter.accent, 0.8);
    ctx.lineWidth = 2;
    ctx.stroke();
    drawGlowingText(
      ctx,
      toFaDigits(st.num),
      0,
      -28 * scale,
      `800 ${Math.round(20 * scale)}px "Vazirmatn", sans-serif`,
      '#e0f2fe',
      chapter.accent,
      8,
    );
    ctx.restore();
  }

  // Gentle dust motes drifting on the road
  for (let i = 0; i < 12; i++) {
    const seed = seeded(i * 5 + 9);
    const px = cx + (seeded(i * 3 + 1) - 0.5) * 560;
    const py = horizonY + ((globalT * (18 + seed * 30) + seed * 400) % 300);
    ctx.fillStyle = withAlpha(chapter.accent, 0.12 + seed * 0.16);
    ctx.beginPath();
    ctx.arc(px, py, 1.2 + seed * 2, 0, Math.PI * 2);
    ctx.fill();
  }

  drawSacredMandala(ctx, cx, horizonY - 40, 210, globalT * 0.05, chapter.accent, 0.07);

  drawPillCluster(ctx, cx, horizonY - 40, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 10: آرامشِ دریا — layered waves & the boat of hope ════════════ */
export function drawSceneOcean(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;

  // Moon & reflected path on water
  const moonX = 980;
  const moonY = 120;
  ctx.save();
  ctx.fillStyle = '#e0f2fe';
  ctx.shadowColor = withAlpha(chapter.accent, 0.9);
  ctx.shadowBlur = 28;
  ctx.beginPath();
  ctx.arc(moonX, moonY, 34, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = 0.35;
  ctx.strokeStyle = withAlpha(chapter.accent, 0.5);
  ctx.lineWidth = 2;
  for (let i = 0; i < 12; i++) {
    const wy = 350 + i * 22;
    const wob = Math.sin(globalT * 1.6 + i) * 26;
    ctx.beginPath();
    ctx.moveTo(moonX - 34 - i * 2 + wob, wy);
    ctx.lineTo(moonX + 34 + i * 2 - wob, wy);
    ctx.stroke();
  }
  ctx.restore();

  // ── Layered waves (back to front)
  const layers = [
    { y: 400, amp: 14, speed: 0.9, color: 'rgba(30, 64, 120, 0.55)', step: 190 },
    { y: 470, amp: 18, speed: -1.2, color: 'rgba(23, 52, 101, 0.75)', step: 150 },
    { y: 545, amp: 22, speed: 1.5, color: 'rgba(14, 36, 77, 0.9)', step: 120 },
    { y: 625, amp: 26, speed: -1.8, color: 'rgba(7, 22, 52, 0.97)', step: 100 },
  ];
  for (let l = 0; l < layers.length; l++) {
    const L = layers[l];
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, 720);
    for (let x = 0; x <= 1280; x += 16) {
      const y =
        L.y +
        Math.sin(x / L.step + globalT * L.speed + l * 1.7) * L.amp +
        Math.sin(x / (L.step * 0.4) - globalT * L.speed * 0.6) * L.amp * 0.4;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(1280, 720);
    ctx.closePath();
    ctx.fillStyle = L.color;
    ctx.fill();
    // Foam crest
    ctx.strokeStyle = withAlpha(chapter.accent, 0.3 + energy * 0.15);
    ctx.lineWidth = 1.8;
    ctx.stroke();
    ctx.restore();
  }

  // ── Boat of hope sailing gently
  const sail = easeOutBack(clamp01((t - 1.2) / 1.6));
  const boatX = lerp(1080, 380, easeInOutCubic(clamp01((t - 2) / Math.max(8, sc.localDur - 4))));
  const bobY = Math.sin(globalT * 1.1) * 7;
  const boatY = 486 + bobY;
  ctx.save();
  ctx.translate(boatX, boatY);
  ctx.rotate(Math.sin(globalT * 1.1 + 0.6) * 0.045);
  ctx.scale(sail, sail);
  // Hull
  ctx.beginPath();
  ctx.moveTo(-74, 0);
  ctx.quadraticCurveTo(0, 30, 74, 0);
  ctx.quadraticCurveTo(40, 12, 0, 13);
  ctx.quadraticCurveTo(-40, 12, -74, 0);
  ctx.closePath();
  const hullG = ctx.createLinearGradient(0, -2, 0, 24);
  hullG.addColorStop(0, '#b45309');
  hullG.addColorStop(1, '#5b2408');
  ctx.fillStyle = hullG;
  ctx.fill();
  // Mast
  ctx.strokeStyle = '#d97706';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -108);
  ctx.stroke();
  // Sails (two curved triangles)
  ctx.beginPath();
  ctx.moveTo(2, -104);
  ctx.quadraticCurveTo(58, -74, 4, -34);
  ctx.closePath();
  ctx.fillStyle = 'rgba(241, 245, 249, 0.94)';
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-2, -96);
  ctx.quadraticCurveTo(-50, -66, -3, -34);
  ctx.closePath();
  ctx.fillStyle = 'rgba(224, 242, 254, 0.8)';
  ctx.fill();
  // Lantern glow at mast top
  ctx.fillStyle = '#fde047';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 14;
  ctx.beginPath();
  ctx.arc(0, -110, 3.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Reflection shimmer under boat
  ctx.save();
  ctx.globalAlpha = 0.3;
  ctx.strokeStyle = withAlpha(chapter.accentSecondary, 0.6);
  ctx.lineWidth = 1.6;
  for (let i = 0; i < 5; i++) {
    const ry = boatY + 16 + i * 9;
    const wob = Math.sin(globalT * 2 + i * 2) * 14;
    ctx.beginPath();
    ctx.moveTo(boatX - 44 + wob, ry);
    ctx.lineTo(boatX + 44 - wob, ry);
    ctx.stroke();
  }
  ctx.restore();

  drawSacredMandala(ctx, cx, 330, 240, globalT * 0.035, chapter.accent, 0.05);

  drawPillCluster(ctx, cx, 330, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 11: نهالِ امید — the seed growing into a tree of light ════════════ */
export function drawSceneTree(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const groundY = 560;
  const growth = easeOutCubic(clamp01(t / Math.max(6, sc.localDur * 0.65)));

  // Sun & morning rays
  ctx.save();
  const sg = ctx.createRadialGradient(300, 130, 10, 300, 130, 260);
  sg.addColorStop(0, 'rgba(190, 242, 100, 0.28)');
  sg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = sg;
  ctx.fillRect(0, 0, 700, 400);
  ctx.restore();

  // Ground
  ctx.save();
  const gg = ctx.createLinearGradient(0, groundY, 0, 720);
  gg.addColorStop(0, '#1a3a26');
  gg.addColorStop(1, '#0a1f12');
  ctx.fillStyle = gg;
  ctx.beginPath();
  ctx.moveTo(0, groundY + 8);
  ctx.quadraticCurveTo(320, groundY - 16, 640, groundY + 4);
  ctx.quadraticCurveTo(960, groundY + 22, 1280, groundY - 6);
  ctx.lineTo(1280, 720);
  ctx.lineTo(0, 720);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.3);
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // Roots below ground
  ctx.save();
  ctx.strokeStyle = 'rgba(74, 110, 60, 0.55)';
  ctx.lineWidth = 2;
  drawRoot(ctx, cx, groundY + 6, Math.PI / 2, 70 * growth, 0, growth);
  drawRoot(ctx, cx, groundY + 6, Math.PI / 2 + 0.5, 52 * growth, 1, growth);
  drawRoot(ctx, cx, groundY + 6, Math.PI / 2 - 0.5, 52 * growth, 2, growth);
  ctx.restore();

  // Trunk & recursive branches
  ctx.save();
  ctx.strokeStyle = '#7c4a1e';
  ctx.lineCap = 'round';
  drawBranch(ctx, cx, groundY, -Math.PI / 2, 120, growth, 0, globalT, energy);
  ctx.restore();

  // Leaves: deterministic scattered foliage around branch region
  const leafCount = 26;
  for (let i = 0; i < leafCount; i++) {
    const seed = seeded(i * 19 + 3);
    const ang = seeded(i * 7 + 1) * Math.PI * 2;
    const dist = 40 + seeded(i * 13 + 5) * 130;
    const lx = cx + Math.cos(ang) * dist * 0.9;
    const ly = 400 + Math.sin(ang) * dist * 0.55;
    const leafProg = clamp01((growth - 0.35 - seed * 0.3) / 0.4);
    if (leafProg <= 0) continue;
    const sway = Math.sin(globalT * 1.4 + i) * 4;
    const lr = (5 + seed * 9) * easeOutBack(leafProg);
    ctx.fillStyle = withAlpha(i % 3 === 0 ? chapter.accentSecondary : chapter.accent, 0.5 + seed * 0.35);
    ctx.beginPath();
    ctx.ellipse(lx + sway, ly, lr, lr * 0.62, seed * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  // Birds gliding
  for (let b = 0; b < 3; b++) {
    const bt = globalT * 0.5 + b * 2.4;
    const bx = ((bt * 90 + b * 300) % 1500) - 110;
    const by = 150 + b * 55 + Math.sin(bt * 2) * 16;
    const flap = Math.sin(globalT * 6 + b * 2) * 6;
    ctx.save();
    ctx.strokeStyle = 'rgba(203, 235, 210, 0.7)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(bx - 12, by + flap);
    ctx.quadraticCurveTo(bx - 6, by - 5, bx, by);
    ctx.quadraticCurveTo(bx + 6, by - 5, bx + 12, by + flap);
    ctx.stroke();
    ctx.restore();
  }

  // Seed label at start
  ctx.save();
  ctx.globalAlpha = clamp01(1.2 - t / 5);
  if (ctx.globalAlpha > 0) {
    drawGlowingText(ctx, 'دانه‌ی نیکی', cx - 250, groundY - 30, '700 24px "Vazirmatn", sans-serif', '#d9f99d', chapter.accent, 10);
  }
  ctx.restore();

  drawSacredMandala(ctx, cx, 380, 245, globalT * 0.04, chapter.accent, 0.05);

  drawPillCluster(ctx, cx, 380, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

function drawRoot(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  ang: number,
  len: number,
  depth: number,
  growth: number,
) {
  if (depth > 2 || len < 6) return;
  const x2 = x + Math.cos(ang) * len;
  const y2 = y + Math.sin(ang) * len;
  ctx.lineWidth = Math.max(1, 4 - depth * 1.2);
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  drawRoot(ctx, x2, y2, ang + 0.4, len * 0.6, depth + 1, growth);
  drawRoot(ctx, x2, y2, ang - 0.35, len * 0.66, depth + 1, growth);
}

function drawBranch(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  ang: number,
  len: number,
  growth: number,
  depth: number,
  globalT: number,
  energy: number,
) {
  if (depth > 4 || len < 8) return;
  const g = clamp01(growth * (1 + depth * 0.28) - depth * 0.16);
  if (g <= 0) return;
  const l = len * easeOutCubic(g);
  const sway = Math.sin(globalT * 0.8 + depth) * (0.03 + energy * 0.02);
  const x2 = x + Math.cos(ang + sway) * l;
  const y2 = y + Math.sin(ang + sway) * l;
  ctx.lineWidth = Math.max(1.4, 14 - depth * 3);
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  const spread = 0.42 + seeded(depth * 31 + x) * 0.2;
  drawBranch(ctx, x2, y2, ang - spread, l * 0.72, growth, depth + 1, globalT, energy);
  drawBranch(ctx, x2, y2, ang + spread, l * 0.72, growth, depth + 1, globalT, energy);
  if (depth >= 2 && seeded(x + depth * 7) > 0.5) {
    drawBranch(ctx, x2, y2, ang + spread * 0.15, l * 0.5, growth, depth + 1, globalT, energy);
  }
}

/* ════════════ SCENE 12: حمدِ پایانی — golden mandala, fireworks & recap orbit ════════════ */
export function drawSceneFinale(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const cy = 320;

  // Fireworks bursts (deterministic schedule)
  for (let b = 0; b < 6; b++) {
    const burstAt = 1.2 + b * 2.6;
    const age = t - burstAt;
    if (age < 0 || age > 2.2) continue;
    const bx = 220 + seeded(b * 37 + 1) * 840;
    const by = 130 + seeded(b * 53 + 2) * 180;
    const color = b % 2 === 0 ? chapter.accent : chapter.accentSecondary;
    const fade = 1 - age / 2.2;
    for (let p = 0; p < 26; p++) {
      const a = (p / 26) * Math.PI * 2 + b;
      const speed = 60 + seeded(p * 11 + b) * 90;
      const px = bx + Math.cos(a) * speed * age;
      const py = by + Math.sin(a) * speed * age + 26 * age * age;
      ctx.fillStyle = withAlpha(color, fade * (0.5 + seeded(p * 3 + b) * 0.5));
      ctx.beginPath();
      ctx.arc(px, py, 2.2 * fade + 0.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Central golden mandala of praise
  drawAudioAuraRing(ctx, cx, cy, 120, globalT, energy, chapter.accent);
  drawSacredMandala(ctx, cx, cy, 170, globalT * 0.1, chapter.accent, 0.5);
  drawSacredMandala(ctx, cx, cy, 120, -globalT * 0.14, chapter.accentSecondary, 0.45);

  // Glowing core
  ctx.save();
  const cg = ctx.createRadialGradient(cx, cy, 8, cx, cy, 110);
  cg.addColorStop(0, '#fffbeb');
  cg.addColorStop(0.5, '#fde047');
  cg.addColorStop(1, 'rgba(251, 191, 36, 0)');
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.arc(cx, cy, 110, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  const corePop = easeOutBack(clamp01(t / 1.6));
  ctx.save();
  ctx.globalAlpha = clamp01(t / 1.2);
  drawGlowingText(
    ctx,
    'الْحَمْدُ لِلَّهِ',
    cx,
    cy - 4,
    `700 ${Math.round(52 * Math.min(1, corePop + 0.15))}px "Amiri", serif`,
    '#78350f',
    'rgba(255, 251, 235, 0.9)',
    10,
  );
  ctx.restore();

  // Orbiting recap of all 12 chapter names
  const orbitR = 258;
  for (let i = 0; i < CHAPTERS.length; i++) {
    const ch = CHAPTERS[i];
    const prog = clamp01((t - 1.6 - i * 0.22) / 0.7);
    if (prog <= 0) continue;
    const a = (i / CHAPTERS.length) * Math.PI * 2 - Math.PI / 2 + globalT * 0.12;
    const ox = cx + Math.cos(a) * orbitR;
    const oy = cy + Math.sin(a) * orbitR * 0.72;
    drawKineticPill(ctx, ox, oy, ch.shortName, prog, ch.accent, '', 0.92);
  }

  // Closing caption at the very end
  const endFade = clamp01((sc.progress - 0.86) / 0.1);
  if (endFade > 0) {
    ctx.save();
    ctx.globalAlpha = endFade;
    drawGlowingText(
      ctx,
      'گامِ نصر • فصل ۱ — قسمت ۵',
      cx,
      596,
      '800 30px "Vazirmatn", sans-serif',
      '#fef3c7',
      withAlpha(chapter.accent, 0.9),
      16,
    );
    drawGlowingText(
      ctx,
      'تا قسمتِ بعد، همراهِ ما بمانید',
      cx,
      640,
      '500 20px "Vazirmatn", sans-serif',
      'rgba(254, 243, 199, 0.85)',
      withAlpha(chapter.accent, 0.7),
      8,
    );
    ctx.restore();
  }
}
