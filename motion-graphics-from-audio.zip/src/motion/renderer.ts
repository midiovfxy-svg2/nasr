import {
  clamp01,
  drawCosmicParticles,
  drawGlowingText,
  drawRoundedRect,
  easeInOutCubic,
  lerpColor,
  withAlpha,
} from './primitives';
import {
  CHAPTERS,
  FALLBACK_DURATION,
  chapterIndexAtProgress,
  captionForChapter,
  type SceneContext,
} from './timeline';
import { drawSceneDawn, drawSceneNasr, drawSceneCosmos, drawSceneHeart } from './scenes1';
import { drawSceneCity, drawSceneSabr, drawSceneNoor, drawSceneDua } from './scenes2';
import { drawScenePath, drawSceneOcean, drawSceneTree, drawSceneFinale } from './scenes3';

export const VIRTUAL_W = 1280;
export const VIRTUAL_H = 720;

export interface RenderOptions {
  showSubtitles: boolean;
  showHud: boolean;
}

function renderSceneByKey(sc: SceneContext) {
  switch (sc.chapter.sceneKey) {
    case 'dawn_bismillah':
      return drawSceneDawn(sc);
    case 'nasr_banner':
      return drawSceneNasr(sc);
    case 'cosmos_tasbih':
      return drawSceneCosmos(sc);
    case 'heart_anfus':
      return drawSceneHeart(sc);
    case 'city_abundance':
      return drawSceneCity(sc);
    case 'sabr_mountains':
      return drawSceneSabr(sc);
    case 'noor_lamp':
      return drawSceneNoor(sc);
    case 'dua_hands':
      return drawSceneDua(sc);
    case 'path_milestones':
      return drawScenePath(sc);
    case 'ocean_calm':
      return drawSceneOcean(sc);
    case 'seed_tree':
      return drawSceneTree(sc);
    case 'finale_hamd':
      return drawSceneFinale(sc);
  }
}

/** Word-wrap RTL Persian text cleanly into <= 2 lines */
function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const test = cur ? `${cur} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) {
      cur = test;
    } else {
      if (cur) lines.push(cur);
      cur = word;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 2);
}

export function drawMotionFrame(
  ctx: CanvasRenderingContext2D,
  timeSec: number,
  pixelWidth: number,
  pixelHeight: number,
  audioEnergy: number,
  options: RenderOptions,
  totalDuration: number,
) {
  const dur = totalDuration > 0 ? totalDuration : FALLBACK_DURATION;
  const t = Math.max(0, Math.min(dur, timeSec));
  const progress = clamp01(t / dur);

  const chIdx = chapterIndexAtProgress(progress);
  const chapter = CHAPTERS[chIdx];
  const nextChapter = CHAPTERS[Math.min(CHAPTERS.length - 1, chIdx + 1)];
  const localDur = Math.max(0.001, (chapter.to - chapter.from) * dur);
  const localT = Math.max(0, t - chapter.from * dur);

  // Scale to virtual stage
  ctx.save();
  const scaleX = pixelWidth / VIRTUAL_W;
  const scaleY = pixelHeight / VIRTUAL_H;
  ctx.scale(scaleX, scaleY);

  // Blend background colors in the last 1.5s of each chapter
  const timeToEnd = chapter.to * dur - t;
  const blend =
    timeToEnd < 1.5 && nextChapter.id !== chapter.id ? easeInOutCubic(1 - timeToEnd / 1.5) : 0;
  const bgTop = lerpColor(chapter.bgTop, nextChapter.bgTop, blend);
  const bgBottom = lerpColor(chapter.bgBottom, nextChapter.bgBottom, blend);

  const bgGrad = ctx.createLinearGradient(0, 0, 0, VIRTUAL_H);
  bgGrad.addColorStop(0, bgTop);
  bgGrad.addColorStop(1, bgBottom);
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);

  // Ambient starfield & dust
  drawCosmicParticles(ctx, VIRTUAL_W, VIRTUAL_H, t, chapter.accent, audioEnergy);

  // ── Scene content
  const sc: SceneContext = {
    ctx,
    t: localT,
    localDur,
    globalT: t,
    energy: audioEnergy,
    chapter,
    progress: localT / localDur,
  };
  renderSceneByKey(sc);

  // ── Chapter intro block (badge + title + subtitle) — fades out after 45% of chapter
  const introAlpha = 1 - easeInOutCubic(clamp01((localT / localDur - 0.32) / 0.14));
  if (introAlpha > 0.01) {
    ctx.save();
    ctx.globalAlpha = introAlpha;
    // Badge pill (top-right)
    ctx.font = '600 17px "Vazirmatn", sans-serif';
    const badgeText = chapter.badge;
    const bw = ctx.measureText(badgeText).width + 46;
    const bx = VIRTUAL_W - 36 - bw;
    drawRoundedRect(ctx, bx, 26, bw, 38, 19);
    ctx.fillStyle = 'rgba(8, 12, 30, 0.78)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(chapter.accent, 0.75);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    // Small dot
    ctx.fillStyle = chapter.accent;
    ctx.beginPath();
    ctx.arc(bx + 20, 45, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f1f5f9';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillText(badgeText, VIRTUAL_W - 46, 46);

    // Title
    drawGlowingText(
      ctx,
      chapter.title,
      VIRTUAL_W - 36,
      92,
      '800 36px "Vazirmatn", sans-serif',
      '#f8fafc',
      withAlpha(chapter.accent, 0.65),
      16,
      'right',
    );
    // Subtitle
    drawGlowingText(
      ctx,
      chapter.subtitle,
      VIRTUAL_W - 36,
      130,
      '500 19px "Vazirmatn", sans-serif',
      'rgba(203, 213, 225, 0.92)',
      withAlpha(chapter.accent, 0.4),
      6,
      'right',
    );
    ctx.restore();
  }

  // ── Floating Arabic verse (bottom area, above subtitle capsule)
  if (chapter.sceneKey !== 'finale_hamd') {
    ctx.save();
    const vAlpha = 0.55 + 0.2 * Math.sin(t * 1.1);
    ctx.globalAlpha = introAlpha * 0.4 + vAlpha * 0.6;
    drawGlowingText(
      ctx,
      chapter.verseAr,
      640,
      568,
      '700 29px "Amiri", serif',
      '#f8fafc',
      withAlpha(chapter.accent, 0.8),
      14,
    );
    drawGlowingText(
      ctx,
      chapter.verseRef,
      640,
      598,
      '500 15px "Vazirmatn", sans-serif',
      withAlpha(chapter.accent, 0.95),
      withAlpha(chapter.accent, 0.5),
      4,
    );
    ctx.restore();
  }

  // ── Subtitle capsule with rotating chapter affirmations
  if (options.showSubtitles) {
    const caption = captionForChapter(chapter, localT, localDur);
    if (caption) {
      // Fade at caption boundaries
      const capIdx = Math.min(
        chapter.captions.length - 1,
        Math.floor((localT / localDur) * chapter.captions.length),
      );
      const capStart = (capIdx / chapter.captions.length) * localDur;
      const capEnd = ((capIdx + 1) / chapter.captions.length) * localDur;
      const fadeIn = clamp01((localT - capStart) / 0.5);
      const fadeOut = clamp01((capEnd - localT) / 0.5);
      const a = Math.min(fadeIn, fadeOut);
      if (a > 0.01) {
        ctx.save();
        ctx.globalAlpha = a;
        ctx.font = '600 23px "Vazirmatn", sans-serif';
        const lines = wrapText(ctx, caption, 760);
        const tw = Math.max(...lines.map((l) => ctx.measureText(l).width));
        const capH = lines.length === 2 ? 84 : 52;
        const capW = tw + 72;
        const ccy = 662 - capH / 2;
        drawRoundedRect(ctx, 640 - capW / 2, ccy, capW, capH, 26);
        ctx.fillStyle = 'rgba(6, 10, 26, 0.86)';
        ctx.shadowColor = withAlpha(chapter.accent, 0.4);
        ctx.shadowBlur = 18;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.strokeStyle = withAlpha(chapter.accent, 0.6);
        ctx.lineWidth = 1.4;
        ctx.stroke();
        // Accent dot
        ctx.fillStyle = chapter.accent;
        ctx.beginPath();
        ctx.arc(640 - capW / 2 + 26, ccy + capH / 2, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        lines.forEach((line, li) => {
          const ly = ccy + capH / 2 + (li - (lines.length - 1) / 2) * 30;
          ctx.fillStyle = '#f8fafc';
          ctx.fillText(line, 640 + 12, ly);
        });
        ctx.restore();
      }
    }
  }

  // ── Brand watermark (top-left)
  ctx.save();
  ctx.globalAlpha = 0.85;
  ctx.font = '800 22px "Vazirmatn", sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = withAlpha(chapter.accent, 0.95);
  ctx.shadowColor = withAlpha(chapter.accent, 0.6);
  ctx.shadowBlur = 10;
  ctx.fillText('✦ گامِ نصر', 38, 48);
  ctx.shadowBlur = 0;
  ctx.font = '500 15px "Vazirmatn", sans-serif';
  ctx.fillStyle = 'rgba(148, 163, 184, 0.9)';
  ctx.fillText('فصل ۱ • قسمت ۵', 40, 74);
  ctx.restore();

  // ── HUD progress bar with chapter ticks
  if (options.showHud) {
    const barY = 706;
    const barX = 60;
    const barW = VIRTUAL_W - 120;
    // Track
    drawRoundedRect(ctx, barX, barY, barW, 5, 3);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
    ctx.fill();
    // Fill
    drawRoundedRect(ctx, barX + barW * (1 - progress), barY, barW * progress, 5, 3);
    const fg = ctx.createLinearGradient(barX, 0, barX + barW, 0);
    fg.addColorStop(0, withAlpha(chapter.accentSecondary, 0.9));
    fg.addColorStop(1, chapter.accent);
    ctx.fillStyle = fg;
    ctx.fill();
    // Chapter ticks
    for (const ch of CHAPTERS) {
      const tx = barX + barW * (1 - ch.from);
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.fillRect(tx - 1, barY - 4, 2, 13);
    }
    // Playhead
    const phx = barX + barW * (1 - progress);
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = chapter.accent;
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(phx, barY + 2.5, 5, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();

  // ── Cinematic fade from/to black
  const fadeIn = clamp01(t / 1.2);
  const fadeOut = clamp01((dur - t) / 1.8);
  const cinematic = Math.min(fadeIn, fadeOut);
  if (cinematic < 1) {
    ctx.save();
    ctx.fillStyle = `rgba(0,0,0,${1 - cinematic})`;
    ctx.fillRect(0, 0, pixelWidth, pixelHeight);
    ctx.restore();
  }
}
