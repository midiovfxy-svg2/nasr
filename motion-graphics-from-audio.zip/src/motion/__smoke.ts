/* Headless smoke test — runs renderer & audio scheduler over the full timeline */
import { drawMotionFrame } from './renderer';
import { buildMixEvents, scheduleEvent, type MixEvent } from './audioEngine';
import { CHAPTERS, FALLBACK_DURATION } from './timeline';

const gradient = { addColorStop: (_o: number, _c: string) => {} };
const noop = () => {};

function makeCtx(): CanvasRenderingContext2D {
  return new Proxy(
    {},
    {
      get(_t, prop) {
        if (prop === 'canvas') return { width: 1280, height: 720 };
        if (prop === 'measureText') return () => ({ width: 120 });
        if (prop === 'createLinearGradient' || prop === 'createRadialGradient' || prop === 'createPattern')
          return () => gradient;
        if (prop === 'getImageData') return () => ({ data: new Uint8ClampedArray(4) });
        return noop;
      },
      set() {
        return true;
      },
    },
  ) as unknown as CanvasRenderingContext2D;
}

/* ── Renderer smoke: coarse + fine around chapter boundaries, two resolutions ── */
const dur = FALLBACK_DURATION;
const times: number[] = [];
for (let t = 0; t < dur; t += 1.7) times.push(t);
for (const ch of CHAPTERS) {
  const s = ch.from * dur;
  for (let d = -1; d <= 1.6; d += 0.1) times.push(Math.max(0, s + d));
}
times.push(dur - 0.01, dur, dur + 5);

let frames = 0;
for (const [w, h] of [
  [1280, 720],
  [1920, 1080],
]) {
  const ctx = makeCtx();
  for (const t of times) {
    for (const subs of [true, false]) {
      drawMotionFrame(ctx, t, w, h, Math.abs(Math.sin(t)), { showSubtitles: subs, showHud: true }, dur);
      frames++;
    }
  }
}
console.log('renderer OK — frames:', frames, 'at 720p & 1080p');

/* ── Audio scheduler smoke ── */
const events: MixEvent[] = buildMixEvents(dur);
console.log('mix events:', events.length, 'types:', [...new Set(events.map((e) => e.type))].join(','));

function makeAudioStub() {
  const gainNode = {
    gain: { value: 0, setValueAtTime: noop, linearRampToValueAtTime: noop, exponentialRampToValueAtTime: noop, setTargetAtTime: noop },
    connect: noop,
  };
  return {
    ctx: {
      currentTime: 0,
      sampleRate: 44100,
      createGain: () => gainNode,
      createOscillator: () => ({
        type: '',
        frequency: { value: 0 },
        connect: noop,
        start: noop,
        stop: noop,
      }),
      createBufferSource: () => ({
        buffer: null,
        loop: false,
        connect: noop,
        start: noop,
        stop: noop,
      }),
      createBiquadFilter: () => ({
        type: '',
        frequency: { value: 0, setValueAtTime: noop, exponentialRampToValueAtTime: noop, linearRampToValueAtTime: noop },
        Q: { value: 0 },
        connect: noop,
      }),
      createDelay: () => ({ delayTime: { value: 0 }, connect: noop }),
      createBuffer: () => ({ getChannelData: () => new Float32Array(100) }),
    } as unknown as BaseAudioContext,
    buses: {
      music: gainNode,
      sfx: gainNode,
      pluckBus: gainNode,
      delaySend: gainNode,
      noiseBuffer: { getChannelData: () => new Float32Array(100) },
    },
  };
}

const { ctx: audioStub, buses } = makeAudioStub();
const busesAsBuses = buses as unknown as Parameters<typeof scheduleEvent>[1];
for (const ev of events) scheduleEvent(audioStub, busesAsBuses, ev, ev.time + 0.02);
console.log('audio scheduler OK — all', events.length, 'events scheduled');

console.log('SMOKE PASSED');
