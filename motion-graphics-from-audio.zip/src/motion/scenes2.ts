import type { SceneContext } from './timeline';
import { pillsWithTimes } from './scenes1';
import {
  clamp01,
  drawAudioAuraRing,
  drawCrescentMoon,
  drawGlowingText,
  drawNebula,
  drawPillCluster,
  drawRoundedRect,
  drawSacredMandala,
  easeOutBack,
  easeOutCubic,
  lerp,
  seeded,
  withAlpha,
} from './primitives';

/* ════════════ SCENE 5: شهرِ فراوانی — skyline, golden rain & the tasdiq funnel ════════════ */
export function drawSceneCity(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;

  // ── Skyline rising from the ground, windows lighting up over time
  const buildings = [
    { x: 90, w: 96, h: 150 },
    { x: 205, w: 78, h: 105 },
    { x: 300, w: 110, h: 210 },
    { x: 428, w: 84, h: 130 },
    { x: 760, w: 96, h: 175 },
    { x: 872, w: 110, h: 235 },
    { x: 998, w: 80, h: 120 },
    { x: 1094, w: 96, h: 165 },
  ];
  for (let b = 0; b < buildings.length; b++) {
    const bd = buildings[b];
    const rise = easeOutCubic(clamp01((t - 0.4 - b * 0.35) / 1.4));
    const bh = bd.h * rise;
    const by = 588 - bh;
    ctx.save();
    const bg = ctx.createLinearGradient(0, by, 0, 588);
    bg.addColorStop(0, 'rgba(30, 58, 95, 0.95)');
    bg.addColorStop(1, 'rgba(8, 20, 40, 0.98)');
    ctx.fillStyle = bg;
    ctx.fillRect(bd.x, by, bd.w, bh);
    ctx.strokeStyle = withAlpha(chapter.accent, 0.28);
    ctx.lineWidth = 1.4;
    ctx.strokeRect(bd.x, by, bd.w, bh);
    // Windows lighting up one by one
    const rows = Math.floor(bh / 26);
    const cols = Math.floor(bd.w / 24);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const winIdx = b * 40 + r * cols + c;
        const lit = clamp01((t - 1.6 - winIdx * 0.22) / 0.5);
        if (lit <= 0) continue;
        const flick = 0.75 + 0.25 * Math.sin(globalT * 2 + winIdx * 1.7);
        ctx.fillStyle = withAlpha(winIdx % 7 === 0 ? chapter.accentSecondary : '#fde68a', 0.75 * lit * flick);
        ctx.fillRect(bd.x + 8 + c * 24, by + 10 + r * 26, 10, 12);
      }
    }
    ctx.restore();
  }

  // ── Golden rain of abundance (particles falling from sky)
  for (let i = 0; i < 46; i++) {
    const seed = seeded(i * 11 + 2);
    const px = 60 + seed * 1160;
    const py = ((globalT * (40 + seed * 60) + seed * 900) % 640);
    const sway = Math.sin(globalT * 1.6 + i) * 16;
    ctx.save();
    ctx.translate(px + sway, py);
    ctx.rotate(globalT * 1.4 + i);
    ctx.fillStyle = withAlpha(chapter.accentSecondary, 0.24 + seed * 0.4);
    ctx.fillRect(-2.4, -4.8, 4.8, 9.6);
    ctx.restore();
  }

  // ── The tasdiq funnel/filter at top-center
  const funnelCy = 250;
  const pop = easeOutBack(clamp01(t / 1.4));
  ctx.save();
  ctx.translate(cx, funnelCy);
  ctx.scale(pop, pop);
  ctx.globalAlpha = clamp01(t / 0.9);
  // Funnel body (two wings)
  ctx.beginPath();
  ctx.moveTo(-150, -55);
  ctx.lineTo(-34, 30);
  ctx.lineTo(-34, 55);
  ctx.lineTo(-130, 14);
  ctx.closePath();
  ctx.moveTo(150, -55);
  ctx.lineTo(34, 30);
  ctx.lineTo(34, 55);
  ctx.lineTo(130, 14);
  ctx.closePath();
  ctx.fillStyle = 'rgba(15, 30, 60, 0.88)';
  ctx.fill();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.85);
  ctx.lineWidth = 2.4;
  ctx.stroke();
  // Central channel
  drawRoundedRect(ctx, -30, -18, 60, 76, 10);
  ctx.stroke();
  // Label above funnel
  drawGlowingText(ctx, 'فیلترِ تصدیق', 0, -96, '800 26px "Vazirmatn", sans-serif', '#f0f9ff', withAlpha(chapter.accent, 0.85), 12);
  ctx.restore();

  // Particles being pulled through the funnel & turning gold
  for (let i = 0; i < 10; i++) {
    const cyc = ((globalT * 0.5 + i * 0.1) % 1);
    const fx = cx + Math.sin(cyc * Math.PI) * (1 - cyc) * 120 * (cyc < 0.5 ? -1 : 1);
    const fy = funnelCy - 60 + cyc * 150;
    const inFunnel = Math.abs(fx - cx) < 60 && fy > funnelCy - 10;
    ctx.fillStyle = withAlpha(inFunnel ? chapter.accentSecondary : '#94a3b8', 0.5 + 0.3 * Math.sin(i + globalT * 4));
    ctx.beginPath();
    ctx.arc(fx, fy, inFunnel ? 3.4 : 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  drawAudioAuraRing(ctx, cx, funnelCy, 96, globalT, energy, chapter.accent);
  drawSacredMandala(ctx, cx, funnelCy, 230, globalT * 0.05, chapter.accent, 0.055);

  drawPillCluster(ctx, cx, funnelCy, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 6: کوه‌های صبر — moonlit ranges & the winding path of patience ════════════ */
export function drawSceneSabr(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;

  // Moon
  const moonX = 1010;
  const moonY = 130;
  drawCrescentMoon(ctx, moonX, moonY, 40, withAlpha(chapter.accent, 0.9), chapter.bgTop, chapter.bgBottom);
  // Halo
  ctx.save();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.25);
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(moonX, moonY, 62 + Math.sin(globalT * 1.4) * 5, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // Verse floating in the sky
  ctx.save();
  ctx.globalAlpha = clamp01((t - 1) / 1.4);
  drawGlowingText(
    ctx,
    'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    420,
    170,
    '700 40px "Amiri", serif',
    '#e0e7ff',
    withAlpha(chapter.accent, 0.85),
    18,
  );
  ctx.restore();

  // ── Layered mountain ranges (3 parallax layers)
  const layers = [
    { yBase: 470, amp: 130, color: 'rgba(15, 23, 42, 0.85)', drift: 6, seedOff: 0 },
    { yBase: 540, amp: 90, color: 'rgba(15, 23, 42, 0.94)', drift: 12, seedOff: 40 },
    { yBase: 600, amp: 55, color: 'rgba(2, 6, 23, 0.98)', drift: 20, seedOff: 80 },
  ];
  for (let l = 0; l < layers.length; l++) {
    const L = layers[l];
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-40, 720);
    for (let x = -40; x <= 1320; x += 40) {
      const n =
        Math.sin((x + l * 130) * 0.004 + L.seedOff) * L.amp * 0.6 +
        Math.sin((x + l * 60) * 0.011 + L.seedOff * 2) * L.amp * 0.4;
      const peak = L.yBase - Math.abs(n);
      ctx.lineTo(x + Math.sin(globalT * 0.14 + l) * L.drift * 0.3, peak);
    }
    ctx.lineTo(1320, 720);
    ctx.closePath();
    ctx.fillStyle = L.color;
    ctx.fill();
    // Snow-light ridge line
    ctx.strokeStyle = withAlpha(chapter.accent, 0.16 + energy * 0.08);
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.restore();
  }

  // ── Winding path with milestone flags up the great peak
  const peakX = 940;
  const peakY = 355;
  const pathPts: Array<[number, number]> = [
    [180, 640],
    [300, 585],
    [255, 528],
    [430, 512],
    [520, 462],
    [470, 420],
    [640, 428],
    [730, 402],
    [700, 372],
    [peakX, peakY],
  ];
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(pathPts[0][0], pathPts[0][1]);
  for (let i = 1; i < pathPts.length; i++) {
    const [x0, y0] = pathPts[i - 1];
    const [x1, y1] = pathPts[i];
    ctx.quadraticCurveTo(x0 + (x1 - x0) * 0.5, y0 - 26, x1, y1);
  }
  ctx.strokeStyle = withAlpha(chapter.accent, 0.5);
  ctx.lineWidth = 3.4;
  ctx.setLineDash([10, 8]);
  ctx.lineDashOffset = -globalT * 22;
  ctx.shadowColor = withAlpha(chapter.accent, 0.6);
  ctx.shadowBlur = 8;
  ctx.stroke();
  ctx.restore();

  // Milestone flags popping along the path
  const milestones = [0.16, 0.38, 0.6, 0.8];
  for (let m = 0; m < milestones.length; m++) {
    const mp = pathPointAt(pathPts, milestones[m]);
    const prog = clamp01((t - 1.5 - m * 1.9) / 0.7);
    if (prog <= 0) continue;
    const s = easeOutBack(prog);
    ctx.save();
    ctx.translate(mp[0], mp[1]);
    ctx.scale(s, s);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -30);
    ctx.stroke();
    ctx.fillStyle = withAlpha(chapter.accent, 0.95);
    ctx.beginPath();
    ctx.moveTo(0, -30);
    ctx.lineTo(22, -24);
    ctx.lineTo(0, -18);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // Walker: glowing orb traveling the path with progress
  const walkP = clamp01((t - 2.2) / Math.max(6, sc.localDur * 0.78));
  const wp = pathPointAt(pathPts, easeOutCubic(walkP));
  ctx.save();
  ctx.fillStyle = '#fef9c3';
  ctx.shadowColor = chapter.accent;
  ctx.shadowBlur = 20;
  ctx.beginPath();
  ctx.arc(wp[0], wp[1] - 7, 6.5 + energy * 3, 0, Math.PI * 2);
  ctx.fill();
  // Soft trail
  for (let k = 1; k <= 4; k++) {
    const tp = pathPointAt(pathPts, Math.max(0, easeOutCubic(walkP) - k * 0.018));
    ctx.fillStyle = withAlpha(chapter.accent, 0.32 - k * 0.07);
    ctx.beginPath();
    ctx.arc(tp[0], tp[1] - 7, 5 - k, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  drawSacredMandala(ctx, cx, 320, 240, globalT * 0.03, chapter.accent, 0.045);

  drawPillCluster(ctx, cx, 330, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/** Interpolate a point along a quadratic-smoothed polyline at fraction f (0..1) */
function pathPointAt(pts: Array<[number, number]>, f: number): [number, number] {
  const ff = clamp01(f);
  const segCount = (pts.length - 1) * 2; // two quadratic segments per pair
  const total = segCount;
  const seg = Math.min(total - 1, Math.floor(ff * total));
  const local = ff * total - seg;
  const pairIdx = Math.floor(seg / 2);
  const [x0, y0] = pts[pairIdx];
  const [x1, y1] = pts[pairIdx + 1];
  const cxq = x0 + (x1 - x0) * 0.5;
  const cyq = y0 - 26;
  const t2 = seg % 2 === 0 ? local * 0.5 : 0.5 + local * 0.5;
  const x = (1 - t2) * (1 - t2) * x0 + 2 * (1 - t2) * t2 * cxq + t2 * t2 * x1;
  const y = (1 - t2) * (1 - t2) * y0 + 2 * (1 - t2) * t2 * cyq + t2 * t2 * y1;
  return [x, y];
}

/* ════════════ SCENE 7: چراغِ نور — the mishkah lamp inside a glowing niche ════════════ */
export function drawSceneNoor(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const cy = 330;

  // ── Niche arch (pointed Islamic arch) behind the lamp
  const archPop = easeOutCubic(clamp01(t / 1.5));
  ctx.save();
  ctx.translate(cx, cy + 60);
  ctx.scale(archPop, archPop);
  ctx.beginPath();
  ctx.moveTo(-190, 240);
  ctx.lineTo(-190, 10);
  ctx.quadraticCurveTo(-190, -120, 0, -235);
  ctx.quadraticCurveTo(190, -120, 190, 10);
  ctx.lineTo(190, 240);
  ctx.closePath();
  const archG = ctx.createLinearGradient(0, -235, 0, 240);
  archG.addColorStop(0, 'rgba(120, 53, 15, 0.42)');
  archG.addColorStop(1, 'rgba(41, 18, 4, 0.72)');
  ctx.fillStyle = archG;
  ctx.fill();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.65);
  ctx.lineWidth = 3;
  ctx.stroke();
  // Inner arch line
  ctx.beginPath();
  ctx.moveTo(-150, 240);
  ctx.lineTo(-150, 16);
  ctx.quadraticCurveTo(-150, -96, 0, -198);
  ctx.quadraticCurveTo(150, -96, 150, 16);
  ctx.lineTo(150, 240);
  ctx.strokeStyle = withAlpha(chapter.accent, 0.3);
  ctx.lineWidth = 1.6;
  ctx.stroke();
  ctx.restore();

  // Radiant light rays from the lamp
  ctx.save();
  ctx.translate(cx, cy - 8);
  ctx.rotate(globalT * 0.12);
  for (let i = 0; i < 14; i++) {
    const a = (i * Math.PI * 2) / 14;
    ctx.save();
    ctx.rotate(a);
    const len = 130 + Math.sin(globalT * 2.4 + i * 1.9) * 26 + energy * 42;
    const g = ctx.createLinearGradient(50, 0, len, 0);
    g.addColorStop(0, withAlpha(chapter.accent, 0.34));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(50, -10);
    ctx.lineTo(len, 0);
    ctx.lineTo(50, 10);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  drawAudioAuraRing(ctx, cx, cy - 8, 100, globalT, energy, chapter.accent);

  // ── The lamp (mishkah): base, stem, glass & flame
  ctx.save();
  ctx.translate(cx, cy + 118);
  const lampPop = easeOutBack(clamp01((t - 0.5) / 1.4));
  ctx.scale(lampPop, lampPop);
  // Base
  ctx.beginPath();
  ctx.ellipse(0, 10, 58, 12, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#78350f';
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-34, 8);
  ctx.lineTo(-22, -30);
  ctx.lineTo(22, -30);
  ctx.lineTo(34, 8);
  ctx.closePath();
  const baseG = ctx.createLinearGradient(0, -30, 0, 10);
  baseG.addColorStop(0, '#b45309');
  baseG.addColorStop(1, '#78350f');
  ctx.fillStyle = baseG;
  ctx.fill();
  // Stem
  ctx.fillStyle = '#92400e';
  ctx.fillRect(-6, -66, 12, 38);
  // Glass bulb
  ctx.beginPath();
  ctx.moveTo(-42, -66);
  ctx.quadraticCurveTo(-46, -128, 0, -152);
  ctx.quadraticCurveTo(46, -128, 42, -66);
  ctx.closePath();
  const glassG = ctx.createLinearGradient(0, -152, 0, -66);
  glassG.addColorStop(0, 'rgba(254, 243, 199, 0.34)');
  glassG.addColorStop(1, 'rgba(254, 243, 199, 0.12)');
  ctx.fillStyle = glassG;
  ctx.fill();
  ctx.strokeStyle = withAlpha(chapter.accent, 0.75);
  ctx.lineWidth = 2.2;
  ctx.stroke();
  ctx.restore();

  // Flame with living flicker
  const flick = Math.sin(globalT * 9) * 2.4 + Math.sin(globalT * 23) * 1.4 + energy * 5;
  ctx.save();
  ctx.translate(cx, cy - 30 + flick * 0.4);
  const flameG = ctx.createRadialGradient(0, -16, 3, 0, -16, 60);
  flameG.addColorStop(0, '#fffbeb');
  flameG.addColorStop(0.35, '#fde047');
  flameG.addColorStop(0.7, '#fb923c');
  flameG.addColorStop(1, 'rgba(251, 146, 60, 0)');
  ctx.fillStyle = flameG;
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 40;
  ctx.beginPath();
  ctx.moveTo(0, -58 - flick);
  ctx.quadraticCurveTo(20 + flick, -26, 10, -6);
  ctx.quadraticCurveTo(0, 6, -10, -6);
  ctx.quadraticCurveTo(-20 - flick, -26, 0, -58 - flick);
  ctx.fill();
  ctx.restore();

  // Light motes floating upward
  for (let i = 0; i < 18; i++) {
    const seed = seeded(i * 9 + 4);
    const px = cx + (seeded(i) - 0.5) * 460;
    const py = 600 - ((globalT * (10 + seed * 22) + seed * 640) % 580);
    const tw = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(globalT * 3 + i));
    ctx.fillStyle = withAlpha(chapter.accent, 0.16 + tw * 0.24);
    ctx.beginPath();
    ctx.arc(px, py, 1.4 + seed * 2.6, 0, Math.PI * 2);
    ctx.fill();
  }

  drawSacredMandala(ctx, cx, cy, 250, globalT * 0.04, chapter.accent, 0.06);

  drawPillCluster(ctx, cx, cy - 8, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}

/* ════════════ SCENE 8: دعا — cupped hands of light & the opening sky gate ════════════ */
export function drawSceneDua(sc: SceneContext) {
  const { ctx, t, globalT, energy, chapter } = sc;
  const cx = 640;
  const cy = 330;

  drawNebula(ctx, 340, 190, 300, chapter.accent, 0.1, 0.4);
  drawNebula(ctx, 950, 430, 280, chapter.accentSecondary, 0.08, -0.7);

  // ── Sky gate: radiant arch opening above
  const gateOpen = easeOutCubic(clamp01((t - 0.6) / 2.0));
  ctx.save();
  ctx.translate(cx, 208);
  ctx.globalAlpha = clamp01(t / 1.2);
  ctx.beginPath();
  ctx.moveTo(-150 * gateOpen, 90);
  ctx.lineTo(-150 * gateOpen, 10);
  ctx.quadraticCurveTo(-150 * gateOpen, -78 * gateOpen, 0, -96 * gateOpen);
  ctx.quadraticCurveTo(150 * gateOpen, -78 * gateOpen, 150 * gateOpen, 10);
  ctx.lineTo(150 * gateOpen, 90);
  ctx.closePath();
  const gateG = ctx.createLinearGradient(0, -96, 0, 90);
  gateG.addColorStop(0, withAlpha(chapter.accent, 0.55));
  gateG.addColorStop(1, withAlpha(chapter.accentSecondary, 0.06));
  ctx.fillStyle = gateG;
  ctx.shadowColor = withAlpha(chapter.accent, 0.8);
  ctx.shadowBlur = 30;
  ctx.fill();
  ctx.restore();

  // Light raining down from the gate
  for (let i = 0; i < 14; i++) {
    const seed = seeded(i * 17 + 7);
    const gx = cx + (seed - 0.5) * 240 * gateOpen;
    const gy = 130 + ((globalT * (26 + seed * 30) + seed * 500) % 380);
    ctx.strokeStyle = withAlpha(chapter.accent, 0.1 + seed * 0.14);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(gx, gy);
    ctx.lineTo(gx, gy + 18);
    ctx.stroke();
  }

  // ── Cupped hands silhouette receiving the light
  const handsRise = easeOutBack(clamp01(t / 1.8));
  ctx.save();
  ctx.translate(cx, lerp(720, 470, handsRise));
  ctx.scale(handsRise, handsRise);
  ctx.beginPath();
  // Left hand
  ctx.moveTo(-190, 60);
  ctx.quadraticCurveTo(-230, -10, -180, -40);
  ctx.quadraticCurveTo(-130, -64, -95, -30);
  ctx.quadraticCurveTo(-70, -52, -46, -30);
  ctx.quadraticCurveTo(-30, -48, -12, -28);
  ctx.quadraticCurveTo(-2, -40, 6, -22);
  // Right hand (mirror)
  ctx.quadraticCurveTo(30, -48, 46, -30);
  ctx.quadraticCurveTo(70, -52, 95, -30);
  ctx.quadraticCurveTo(130, -64, 180, -40);
  ctx.quadraticCurveTo(230, -10, 190, 60);
  ctx.closePath();
  const handG = ctx.createLinearGradient(0, -64, 0, 60);
  handG.addColorStop(0, withAlpha(chapter.accentSecondary, 0.9));
  handG.addColorStop(1, 'rgba(66, 32, 110, 0.92)');
  ctx.fillStyle = handG;
  ctx.shadowColor = withAlpha(chapter.accent, 0.7);
  ctx.shadowBlur = 26;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha('#f5d0fe', 0.5);
  ctx.lineWidth = 1.6;
  ctx.stroke();
  ctx.restore();

  // Prayer particles rising from hands to gate
  for (let i = 0; i < 20; i++) {
    const seed = seeded(i * 13 + 11);
    const px = cx + (seeded(i * 3) - 0.5) * 300;
    const py = 470 - ((globalT * (20 + seed * 26) + seed * 480) % 330);
    const a = Math.sin(Math.min(1, (470 - py) / 330) * Math.PI) * 0.7;
    ctx.fillStyle = withAlpha(i % 4 === 0 ? chapter.accentSecondary : '#e9d5ff', a);
    ctx.beginPath();
    ctx.arc(px, py, 1.8 + seed * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  // Rising ripple rings from the hands
  for (let i = 0; i < 3; i++) {
    const cyc = ((globalT * 0.32 + i * 0.33) % 1);
    const rr = 40 + cyc * 150;
    ctx.strokeStyle = withAlpha(chapter.accent, 0.35 * (1 - cyc));
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.ellipse(cx, 440 - cyc * 120, rr, rr * 0.32, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  drawAudioAuraRing(ctx, cx, cy, 104, globalT, energy, chapter.accent);
  drawSacredMandala(ctx, cx, cy, 245, -globalT * 0.04, chapter.accent, 0.055);

  drawPillCluster(ctx, cx, cy, pillsWithTimes(sc), t, globalT, chapter.accent, energy);
}
