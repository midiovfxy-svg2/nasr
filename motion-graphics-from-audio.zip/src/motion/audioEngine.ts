/* ── Audio engine: voice + synthesized ambient music + SFX, realtime & offline ── */

import { CHAPTERS, FALLBACK_DURATION } from './timeline';
import { seeded } from './primitives';

export interface MixSettings {
  musicVol: number; // 0..1.4
  sfxVol: number; // 0..1.4
  voiceVol: number; // 0..1.4
}

export const DEFAULT_MIX: MixSettings = { musicVol: 0.5, sfxVol: 0.6, voiceVol: 1 };

export type MixEventType = 'chord' | 'pluck' | 'whoosh' | 'chime' | 'riser';

export interface MixEvent {
  time: number;
  type: MixEventType;
  freqs?: number[];
  freq?: number;
  gain?: number;
}

/** Serene chord progression (D minor family) — root / fifth / octave triads in Hz */
const CHORD_PROGRESSION: number[][] = [
  [146.83, 220.0, 293.66], // D
  [116.54, 174.61, 233.08], // Bb
  [174.61, 261.63, 349.23], // F
  [130.81, 196.0, 261.63], // C
  [98.0, 146.83, 196.0], // Gm
  [110.0, 164.81, 220.0], // Am
];

const PENTATONE = [0, 2, 4, 7, 9]; // major-pentatonic semitone offsets

function freqAt(rootHz: number, semis: number): number {
  return rootHz * Math.pow(2, semis / 12);
}

/** Deterministic event list shared by realtime playback and offline render */
export function buildMixEvents(totalDur: number): MixEvent[] {
  const dur = totalDur > 0 ? totalDur : FALLBACK_DURATION;
  const events: MixEvent[] = [];

  // ── Pad chords every 16s with 2s overlap
  const chordEvery = 16;
  for (let t = 0, ci = 0; t < dur; t += chordEvery, ci++) {
    const chord = CHORD_PROGRESSION[ci % CHORD_PROGRESSION.length];
    events.push({ time: t, type: 'chord', freqs: chord });
  }

  // ── Gentle plucked arpeggio, ~ every 2.4s, pentatonic around current chord root
  const chordCount = Math.ceil(dur / chordEvery);
  let pi = 0;
  for (let t = 3.2; t < dur - 2; t += 2.2 + seeded(pi * 3 + 1) * 0.7, pi++) {
    const ci = Math.min(chordCount - 1, Math.floor(t / chordEvery));
    const root = CHORD_PROGRESSION[ci % CHORD_PROGRESSION.length][0] * 4; // two octaves up
    const step = PENTATONE[Math.floor(seeded(pi * 7 + 3) * PENTATONE.length)];
    const oct = seeded(pi * 13 + 5) > 0.72 ? 12 : 0;
    events.push({ time: t, type: 'pluck', freq: freqAt(root, step + oct), gain: 0.05 });
  }

  // ── Whoosh at every chapter transition (lead-in)
  for (const ch of CHAPTERS) {
    const at = Math.max(0.05, ch.from * dur - 0.65);
    if (at < dur - 1.2) events.push({ time: at, type: 'whoosh' });
  }

  // ── Soft chimes at pill pop-ins
  for (const ch of CHAPTERS) {
    const chStart = ch.from * dur;
    const chDur = (ch.to - ch.from) * dur;
    for (const pill of ch.pills) {
      const at = chStart + pill.atF * chDur;
      if (at < dur - 1.5) {
        const root = 784 + Math.floor(seeded(pill.x + pill.atF * 100) * 3) * 261.6;
        events.push({ time: at, type: 'chime', freq: root, gain: 0.045 });
      }
    }
  }

  // ── Final riser at the finale chapter
  const finale = CHAPTERS[CHAPTERS.length - 1];
  events.push({ time: finale.from * dur, type: 'riser' });

  events.sort((a, b) => a.time - b.time);
  return events;
}

/* ────────────────────────── Scheduling (shared) ────────────────────────── */

interface Buses {
  music: GainNode;
  sfx: GainNode;
  pluckBus: GainNode;
  delaySend: GainNode;
  noiseBuffer: AudioBuffer;
}

function makeNoiseBuffer(ctx: BaseAudioContext): AudioBuffer {
  const len = Math.floor(ctx.sampleRate * 1.4);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  let last = 0;
  for (let i = 0; i < len; i++) {
    const white = Math.random() * 2 - 1;
    last = 0.96 * last + 0.04 * white; // slightly pink
    data[i] = last * 3;
  }
  return buf;
}

function buildBuses(ctx: BaseAudioContext, settings: MixSettings): Buses {
  const music = ctx.createGain();
  music.gain.value = settings.musicVol * 0.9;
  const sfx = ctx.createGain();
  sfx.gain.value = settings.sfxVol;

  // Gentle echo bus for plucks
  const pluckBus = ctx.createGain();
  pluckBus.gain.value = 1;
  const delay = ctx.createDelay(1.2);
  delay.delayTime.value = 0.42;
  const feedback = ctx.createGain();
  feedback.gain.value = 0.32;
  const wet = ctx.createGain();
  wet.gain.value = 0.24;
  pluckBus.connect(music);
  pluckBus.connect(delay);
  delay.connect(feedback);
  feedback.connect(delay);
  delay.connect(wet);
  wet.connect(music);

  return { music, sfx, pluckBus, delaySend: wet, noiseBuffer: makeNoiseBuffer(ctx) };
}

/** Schedule one event at absolute context time `when` (seconds on ctx.currentTime clock) */
export function scheduleEvent(ctx: BaseAudioContext, buses: Buses, ev: MixEvent, when: number): void {
  if (when < ctx.currentTime - 0.05) return;

  if (ev.type === 'chord' && ev.freqs) {
    const group = ctx.createGain();
    group.gain.value = 1;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 540;
    lp.Q.value = 0.4;
    group.connect(lp);
    lp.connect(buses.music);

    const start = when;
    const hold = 14;
    const total = 18;
    const g = group.gain;
    g.setValueAtTime(0.0001, start);
    g.linearRampToValueAtTime(1, start + 3.6);
    g.setValueAtTime(1, start + hold);
    g.linearRampToValueAtTime(0.0001, start + total);

    const oscs: OscillatorNode[] = [];
    for (let n = 0; n < ev.freqs.length; n++) {
      const f = ev.freqs[n];
      const o1 = ctx.createOscillator();
      o1.type = 'triangle';
      o1.frequency.value = f;
      const o2 = ctx.createOscillator();
      o2.type = 'sawtooth';
      o2.frequency.value = f * 1.004;
      const gn = ctx.createGain();
      gn.gain.value = 0.016;
      o1.connect(gn);
      o2.connect(gn);
      gn.connect(group);
      o1.start(start);
      o2.start(start);
      o1.stop(start + total);
      o2.stop(start + total);
      oscs.push(o1, o2);
    }
    // Sub drone
    const sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.value = ev.freqs[0] / 2;
    const subG = ctx.createGain();
    subG.gain.value = 0.024;
    sub.connect(subG);
    subG.connect(buses.music);
    sub.start(start);
    sub.stop(start + total);
    oscs.push(sub);
    return;
  }

  if (ev.type === 'pluck' && ev.freq) {
    const o = ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.value = ev.freq;
    const g = ctx.createGain();
    const peak = ev.gain ?? 0.05;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(peak, when + 0.014);
    g.gain.setTargetAtTime(0.0001, when + 0.014, 0.3);
    o.connect(g);
    g.connect(buses.pluckBus);
    o.start(when);
    o.stop(when + 1.8);
    return;
  }

  if (ev.type === 'whoosh') {
    const src = ctx.createBufferSource();
    src.buffer = buses.noiseBuffer;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 1.1;
    bp.frequency.setValueAtTime(240, when);
    bp.frequency.exponentialRampToValueAtTime(2100, when + 0.85);
    bp.frequency.exponentialRampToValueAtTime(320, when + 1.05);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(0.34, when + 0.32);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 1.1);
    src.connect(bp);
    bp.connect(g);
    g.connect(buses.sfx);
    src.start(when);
    src.stop(when + 1.15);
    return;
  }

  if (ev.type === 'chime' && ev.freq) {
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(ev.gain ?? 0.045, when + 0.012);
    g.gain.setTargetAtTime(0.0001, when + 0.012, 0.4);
    g.connect(buses.sfx);
    for (const mult of [1, 1.5, 2.02]) {
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = ev.freq * mult;
      const og = ctx.createGain();
      og.gain.value = mult === 1 ? 1 : 0.4;
      o.connect(og);
      og.connect(g);
      o.start(when);
      o.stop(when + 1.6);
    }
    return;
  }

  if (ev.type === 'riser') {
    const src = ctx.createBufferSource();
    src.buffer = buses.noiseBuffer;
    src.loop = true;
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(300, when);
    hp.frequency.exponentialRampToValueAtTime(4200, when + 2.6);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(0.16, when + 2.4);
    g.gain.linearRampToValueAtTime(0.0001, when + 3.4);
    src.connect(hp);
    hp.connect(g);
    g.connect(buses.sfx);
    src.start(when);
    src.stop(when + 3.5);
    return;
  }
}

/* ────────────────────────── Realtime engine ────────────────────────── */

export class RealtimeMixEngine {
  private ctx: AudioContext;
  private master: GainNode;
  private analyser: AnalyserNode;
  private voiceGain: GainNode;
  private buses: Buses;
  private events: MixEvent[] = [];
  private pointer = 0;
  private timer: number | null = null;
  private timeData: Uint8Array<ArrayBuffer>;
  private energySmoothed = 0;
  private hasVoice = false;

  readonly audioEl: HTMLAudioElement;

  constructor(audioUrl: string, settings: MixSettings) {
    this.ctx = new AudioContext();
    this.master = this.ctx.createGain();
    this.master.gain.value = 1;
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 512;
    this.analyser.smoothingTimeConstant = 0.55;
    this.timeData = new Uint8Array(new ArrayBuffer(this.analyser.fftSize));
    this.master.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);

    this.voiceGain = this.ctx.createGain();
    this.voiceGain.gain.value = settings.voiceVol;
    this.voiceGain.connect(this.master);

    this.buses = buildBuses(this.ctx, settings);
    this.buses.music.connect(this.master);
    this.buses.sfx.connect(this.master);

    // Voice element
    this.audioEl = new Audio();
    this.audioEl.crossOrigin = 'anonymous';
    this.audioEl.preload = 'auto';
    this.audioEl.src = audioUrl;
    const src = this.ctx.createMediaElementSource(this.audioEl);
    src.connect(this.voiceGain);
  }

  setVolumes(settings: MixSettings) {
    this.voiceGain.gain.value = settings.voiceVol;
    this.buses.music.gain.value = settings.musicVol * 0.9;
    this.buses.sfx.gain.value = settings.sfxVol;
  }

  /** Begin (or continue) playing at current position; builds event list for duration */
  async play(totalDur: number, fromTime = this.audioEl.currentTime) {
    await this.ctx.resume();
    if (this.events.length === 0 || this.lastDur !== totalDur) {
      this.events = buildMixEvents(totalDur);
      this.lastDur = totalDur;
    }
    this.seekPointer(fromTime);
    this.audioEl.play().catch(() => undefined);
    if (this.timer === null) {
      this.timer = window.setInterval(() => this.tick(), 180);
    }
    this.tick();
  }

  private lastDur = 0;

  pause() {
    this.audioEl.pause();
    this.ctx.suspend();
  }

  async resume() {
    await this.ctx.resume();
    this.audioEl.play().catch(() => undefined);
  }

  seek(time: number, totalDur: number) {
    this.audioEl.currentTime = Math.max(0, Math.min(totalDur - 0.05, time));
    if (this.events.length === 0 || this.lastDur !== totalDur) {
      this.events = buildMixEvents(totalDur);
      this.lastDur = totalDur;
    }
    this.seekPointer(this.audioEl.currentTime);
  }

  private seekPointer(time: number) {
    // Skip past events; chord near current time is re-fired so pads keep sounding
    this.pointer = this.events.findIndex((e) => e.time >= time - 0.1);
    if (this.pointer < 0) this.pointer = this.events.length;
    // Re-trigger the last chord that started before seek point (pads should sustain)
    for (let i = this.pointer - 1; i >= 0; i--) {
      const ev = this.events[i];
      if (ev.type === 'chord') {
        const chordDur = 18;
        const elapsed = time - ev.time;
        if (elapsed < chordDur) {
          const when = this.ctx.currentTime + 0.02;
          const group = this.reScheduleChordPartial(ev, elapsed, when);
          if (group) this.pending.push(group);
        }
        break;
      }
    }
  }

  private reScheduleChordPartial(ev: MixEvent, elapsed: number, when: number): OscillatorNode[] | null {
    // Schedule chord with envelope mid-way through its life
    const ctx = this.ctx;
    if (!ev.freqs) return null;
    const group = ctx.createGain();
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 540;
    group.connect(lp);
    lp.connect(this.buses.music);
    const total = 18;
    const remain = Math.max(0.5, total - elapsed);
    const g = group.gain;
    const alreadyUp = elapsed > 3.6;
    g.setValueAtTime(alreadyUp ? 1 : 0.0001, when);
    if (!alreadyUp) g.linearRampToValueAtTime(1, when + Math.max(0.5, 3.6 - elapsed));
    g.setValueAtTime(1, when + Math.max(0.2, remain - 4));
    g.linearRampToValueAtTime(0.0001, when + remain);
    const nodes: OscillatorNode[] = [];
    for (const f of ev.freqs) {
      const o1 = ctx.createOscillator();
      o1.type = 'triangle';
      o1.frequency.value = f;
      const o2 = ctx.createOscillator();
      o2.type = 'sawtooth';
      o2.frequency.value = f * 1.004;
      const gn = ctx.createGain();
      gn.gain.value = 0.016;
      o1.connect(gn);
      o2.connect(gn);
      gn.connect(group);
      o1.start(when);
      o2.start(when);
      o1.stop(when + remain);
      o2.stop(when + remain);
      nodes.push(o1, o2);
    }
    return nodes;
  }

  private pending: OscillatorNode[][] = [];

  private tick() {
    if (this.audioEl.paused) return;
    const audioTime = this.audioEl.currentTime;
    const horizon = audioTime + 0.85;
    while (this.pointer < this.events.length && this.events[this.pointer].time <= horizon) {
      const ev = this.events[this.pointer];
      const when = this.ctx.currentTime + Math.max(0.02, ev.time - audioTime);
      scheduleEvent(this.ctx, this.buses, ev, when);
      this.pointer++;
    }
  }

  /** Smoothed audio energy 0..1 (voice-driven) */
  getEnergy(): number {
    this.analyser.getByteTimeDomainData(this.timeData);
    let sum = 0;
    for (let i = 0; i < this.timeData.length; i++) {
      const v = (this.timeData[i] - 128) / 128;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / this.timeData.length);
    const target = Math.min(1, rms * 2.6);
    this.energySmoothed += (target - this.energySmoothed) * 0.18;
    return this.energySmoothed;
  }

  get currentTime(): number {
    return this.audioEl.currentTime;
  }

  get duration(): number {
    const d = this.audioEl.duration;
    return Number.isFinite(d) && d > 0 ? d : 0;
  }

  markVoiceReady() {
    this.hasVoice = true;
  }
  get voiceReady() {
    return this.hasVoice;
  }

  destroy() {
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = null;
    try {
      this.audioEl.pause();
    } catch {
      /* noop */
    }
    try {
      this.audioEl.src = '';
    } catch {
      /* noop */
    }
    this.ctx.close().catch(() => undefined);
  }
}

/* ────────────────────────── Offline render (for export) ────────────────────────── */

export async function renderMixedAudioBuffer(
  voiceBuffer: AudioBuffer,
  totalDur: number,
  sampleRate: number,
  channels: number,
  settings: MixSettings,
): Promise<AudioBuffer> {
  const frames = Math.ceil(totalDur * sampleRate);
  const off = new OfflineAudioContext(channels, frames, sampleRate);

  const master = off.createGain();
  master.gain.value = 0.92;
  master.connect(off.destination);

  const buses = buildBuses(off, settings);
  buses.music.connect(master);
  buses.sfx.connect(master);

  // Voice
  const voiceGain = off.createGain();
  voiceGain.gain.value = settings.voiceVol;
  voiceGain.connect(master);
  const voice = off.createBufferSource();
  voice.buffer = voiceBuffer;
  voice.connect(voiceGain);
  voice.start(0);

  // Music + SFX events
  const events = buildMixEvents(totalDur);
  for (const ev of events) {
    scheduleEvent(off, buses, ev, ev.time + 0.02);
  }

  return off.startRendering();
}

/** 10Hz smoothed RMS energy envelope from voice PCM (for export reactivity) */
export function buildEnergyEnvelope(channelData: Float32Array, sampleRate: number, durationSec: number): Float32Array {
  const buckets = Math.ceil(durationSec * 10) + 2;
  const out = new Float32Array(buckets);
  const step = Math.floor(sampleRate / 10);
  for (let b = 0; b < buckets; b++) {
    const start = b * step;
    const end = Math.min(channelData.length, start + step);
    if (end <= start) break;
    let sum = 0;
    for (let i = start; i < end; i++) {
      const s = channelData[i];
      sum += s * s;
    }
    const rms = Math.sqrt(sum / (end - start));
    out[b] = Math.min(1, rms * 3.4);
  }
  return out;
}
