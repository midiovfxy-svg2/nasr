import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AudioLines,
  Clapperboard,
  Download,
  Film,
  Loader2,
  Maximize2,
  Mic2,
  Music4,
  Pause,
  Play,
  RotateCcw,
  Settings2,
  Sparkles,
  Square,
  Subtitles,
  Volume2,
  VolumeX,
  Wand2,
} from 'lucide-react';
import {
  AUDIO_SRC_LOCAL,
  AUDIO_SRC_REMOTE,
  CHAPTERS,
  FALLBACK_DURATION,
  chapterIndexAtProgress,
} from './motion/timeline';
import { drawMotionFrame } from './motion/renderer';
import { RealtimeMixEngine, DEFAULT_MIX, type MixSettings } from './motion/audioEngine';
import {
  ensureCanvasFontsLoaded,
  exportMixedAudioToMp4,
  exportMotionToMp4,
  isWebCodecsSupported,
  type ExportProgress,
  type ExportResult,
} from './motion/exporter';
import { formatTimeFa, toFaDigits } from './motion/primitives';

/* ── Server-rendered deliverables (rendered for the full 10:22 audio) ── */
const DELIVERED = {
  videoPage: 'https://gofile.io/d/KmGcMR95',
  audioPage: 'https://gofile.io/d/37A6ACg2',
  mirrorBin: 'https://filebin.net/gamnasr-s1e5-motion-1405',
  videoFile: 'gamnasr-s1e5-720p.mp4',
  audioFile: 'gamnasr-s1e5-mixed-audio.mp3',
  durationFa: '۱۰:۲۲',
  videoSizeFa: '۶۴ مگابایت',
  audioSizeFa: '۱۵ مگابایت',
};

function formatBytes(bytes: number): string {
  if (bytes > 1024 * 1024) return `${toFaDigits((bytes / (1024 * 1024)).toFixed(1))} مگابایت`;
  return `${toFaDigits(Math.round(bytes / 1024))} کیلوبایت`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<RealtimeMixEngine | null>(null);
  const rafRef = useRef<number>(0);
  const timeRef = useRef(4); // preview frame past the opening fade
  const energyRef = useRef(0);
  const stageWrapRef = useRef<HTMLDivElement | null>(null);
  const swappedSrcRef = useRef(false);

  const [audioReady, setAudioReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [duration, setDuration] = useState(FALLBACK_DURATION);
  const [currentTime, setCurrentTime] = useState(0);
  const [mix, setMix] = useState<MixSettings>(DEFAULT_MIX);
  const [showSubs, setShowSubs] = useState(true);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [webCodecs, setWebCodecs] = useState(true);

  const [expRes, setExpRes] = useState<'720p' | '1080p'>('720p');
  const [expSubs, setExpSubs] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [exportKind, setExportKind] = useState<'video' | 'audio' | null>(null);
  const [progress, setProgress] = useState<ExportProgress | null>(null);
  const [videoResult, setVideoResult] = useState<{ result: ExportResult; url: string } | null>(null);
  const [audioResult, setAudioResult] = useState<{ result: ExportResult; url: string } | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);

  const activeChapterIdx = useMemo(
    () => chapterIndexAtProgress(duration > 0 ? timeRef.current / duration : 0),
    [currentTime, duration],
  );

  /* ── Engine bootstrap (AudioContext is suspended until user gesture) ── */
  const ensureEngine = useCallback((): RealtimeMixEngine => {
    if (engineRef.current) return engineRef.current;
    const eng = new RealtimeMixEngine(AUDIO_SRC_LOCAL, DEFAULT_MIX);
    eng.audioEl.addEventListener('loadedmetadata', () => {
      const d = eng.duration;
      if (d > 0) setDuration(d);
      setAudioReady(true);
    });
    eng.audioEl.addEventListener('error', () => {
      if (!swappedSrcRef.current) {
        swappedSrcRef.current = true;
        eng.audioEl.src = AUDIO_SRC_REMOTE;
        eng.audioEl.load();
      } else {
        setAudioError('بارگذاری فایل صوتی ناموفق بود — اتصال اینترنت را بررسی کنید.');
      }
    });
    eng.audioEl.addEventListener('ended', () => {
      eng.pause();
      setPlaying(false);
    });
    engineRef.current = eng;
    return eng;
  }, []);

  /* ── Render loop (always running; draws preview & live frames) ── */
  useEffect(() => {
    const eng = ensureEngine();
    const canvas = canvasRef.current!;
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d', { alpha: false })!;

    const loop = () => {
      const t = playing ? eng.currentTime : timeRef.current;
      timeRef.current = t;
      const energy = playing ? eng.getEnergy() : energyRef.current * 0.94;
      energyRef.current = energy;
      drawMotionFrame(ctx, t, 1280, 720, energy, { showSubtitles: showSubs, showHud: true }, duration);
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [ensureEngine, playing, showSubs, duration]);

  /* Throttled clock for the UI */
  useEffect(() => {
    if (!playing) return;
    const iv = window.setInterval(() => setCurrentTime(engineRef.current?.currentTime ?? 0), 250);
    return () => window.clearInterval(iv);
  }, [playing]);

  useEffect(() => {
    setWebCodecs(isWebCodecsSupported());
    ensureCanvasFontsLoaded();
    return () => {
      engineRef.current?.destroy();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    engineRef.current?.setVolumes(mix);
  }, [mix]);

  /* ── Playback controls ── */
  const togglePlay = useCallback(async () => {
    const eng = ensureEngine();
    if (playing) {
      eng.pause();
      setPlaying(false);
    } else {
      // Restart from the top if we reached the end
      if (duration > 0 && eng.currentTime >= duration - 0.4) {
        eng.seek(0, duration);
        timeRef.current = 0;
        setCurrentTime(0);
      }
      await eng.play(duration, eng.currentTime);
      setPlaying(true);
    }
  }, [ensureEngine, playing, duration]);

  const seek = useCallback(
    (t: number) => {
      const eng = ensureEngine();
      const clamped = Math.max(0, Math.min(duration - 0.1, t));
      eng.seek(clamped, duration);
      timeRef.current = clamped;
      setCurrentTime(clamped);
    },
    [ensureEngine, duration],
  );

  const restart = useCallback(() => seek(0), [seek]);

  const toggleFullscreen = useCallback(() => {
    const el = stageWrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen().catch(() => undefined);
  }, []);

  /* ── Exports ── */
  const abortRef = useRef<AbortController | null>(null);

  const cancelExport = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const runVideoExport = useCallback(async () => {
    setExporting(true);
    setExportKind('video');
    setExportError(null);
    setProgress(null);
    if (videoResult) URL.revokeObjectURL(videoResult.url);
    setVideoResult(null);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const result = await exportMotionToMp4({
        resolution: expRes,
        showSubtitles: expSubs,
        showHud: false,
        mix,
        signal: ctrl.signal,
        onProgress: setProgress,
        onPreviewCanvas: (c) => {
          const pc = previewCanvasRef.current;
          if (pc) {
            pc.width = 640;
            pc.height = 360;
            const pctx = pc.getContext('2d');
            pctx?.drawImage(c, 0, 0, 640, 360);
          }
        },
      });
      setVideoResult({ result, url: URL.createObjectURL(result.blob) });
    } catch (e) {
      setExportError(e instanceof Error ? e.message : String(e));
    } finally {
      setExporting(false);
      setExportKind(null);
      setProgress(null);
    }
  }, [expRes, expSubs, mix, videoResult]);

  const runAudioExport = useCallback(async () => {
    setExporting(true);
    setExportKind('audio');
    setExportError(null);
    setProgress(null);
    if (audioResult) URL.revokeObjectURL(audioResult.url);
    setAudioResult(null);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const result = await exportMixedAudioToMp4(mix, setProgress, ctrl.signal);
      setAudioResult({ result, url: URL.createObjectURL(result.blob) });
    } catch (e) {
      setExportError(e instanceof Error ? e.message : String(e));
    } finally {
      setExporting(false);
      setExportKind(null);
      setProgress(null);
    }
  }, [mix, audioResult]);

  const download = (url: string, filename: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="min-h-screen bg-[#060914] text-slate-100">
      {/* ── Header ── */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-[#060914]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/30">
              <Clapperboard className="h-6 w-6 text-slate-950" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight">
                استودیو موشن گرافیک <span className="text-amber-400">گامِ نصر</span>
              </h1>
              <p className="text-xs text-slate-400">فصل ۱ • قسمت ۵ — انیمیشن المان‌محور همگام با صدا، با موسیقی و افکت</p>
            </div>
          </div>
          <div className="hidden items-center gap-2 md:flex">
            <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-300">
              ۱۲ فصلِ زنده
            </span>
            <span className="rounded-full border border-sky-400/30 bg-sky-400/10 px-3 py-1 text-xs font-semibold text-sky-300">
              {formatTimeFa(duration)}
            </span>
            <a
              href="#delivered"
              className="flex items-center gap-1.5 rounded-full bg-gradient-to-l from-emerald-400 to-teal-500 px-3.5 py-1.5 text-xs font-black text-slate-950 shadow-lg shadow-emerald-500/25 transition hover:brightness-110"
            >
              <Download className="h-3.5 w-3.5" />
              دانلود نسخهٔ آماده
            </a>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-16">
        {/* ── Stage ── */}
        <section className="pt-6">
          <div
            ref={stageWrapRef}
            className="group relative overflow-hidden rounded-3xl border border-white/10 bg-black shadow-2xl shadow-black/60"
          >
            <canvas ref={canvasRef} className="block w-full aspect-video" />

            {/* Center play button */}
            {!playing && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 flex items-center justify-center bg-black/25 transition-colors hover:bg-black/15"
                aria-label="پخش"
              >
                <span className="flex h-24 w-24 items-center justify-center rounded-full bg-amber-400 shadow-2xl shadow-amber-400/50 transition-transform hover:scale-110">
                  <Play className="mr-1 h-12 w-12 fill-slate-950 text-slate-950" />
                </span>
              </button>
            )}

            {/* Bottom control bar */}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent px-4 pb-3 pt-10 opacity-100 transition-opacity md:px-6">
              <div className="mb-2 flex items-center gap-3 text-xs text-slate-300">
                <button
                  onClick={togglePlay}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/40 transition hover:scale-105"
                  aria-label={playing ? 'توقف' : 'پخش'}
                >
                  {playing ? <Pause className="h-5 w-5" /> : <Play className="mr-0.5 h-5 w-5" />}
                </button>
                <button
                  onClick={restart}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20"
                  aria-label="از ابتدا"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
                <span className="font-bold tabular-nums" dir="ltr">
                  {formatTimeFa(currentTime)}
                </span>
                <input
                  type="range"
                  min={0}
                  max={duration}
                  step={0.1}
                  value={currentTime}
                  onChange={(e) => seek(Number(e.target.value))}
                  className="studio-slider h-4 flex-1"
                  aria-label="خط زمانی"
                />
                <span className="font-bold tabular-nums text-slate-400" dir="ltr">
                  {formatTimeFa(duration)}
                </span>
                <button
                  onClick={() => setShowSubs((s) => !s)}
                  className={`flex h-9 w-9 items-center justify-center rounded-full transition ${
                    showSubs ? 'bg-amber-400/20 text-amber-300' : 'bg-white/10 text-slate-400'
                  }`}
                  aria-label="زیرنویس"
                >
                  <Subtitles className="h-4 w-4" />
                </button>
                <button
                  onClick={toggleFullscreen}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20"
                  aria-label="تمام‌صفحه"
                >
                  <Maximize2 className="h-4 w-4" />
                </button>
              </div>

              {/* Chapter ticks under the scrubber */}
              <div className="pointer-events-none relative hidden h-3 md:block">
                {CHAPTERS.map((ch, i) => (
                  <button
                    key={ch.id}
                    onClick={() => seek(ch.from * duration + 0.05)}
                    className="pointer-events-auto absolute -top-1 h-4 w-1.5 rounded-full transition-all hover:scale-y-150"
                    style={{
                      right: `${ch.from * 100}%`,
                      background: i === activeChapterIdx ? ch.accent : 'rgba(255,255,255,0.28)',
                      boxShadow: i === activeChapterIdx ? `0 0 10px ${ch.accent}` : undefined,
                    }}
                    title={ch.title}
                    aria-label={ch.title}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* ── Chapter rail ── */}
          <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
            {CHAPTERS.map((ch, i) => (
              <button
                key={ch.id}
                onClick={() => seek(ch.from * duration + 0.05)}
                className={`group flex shrink-0 items-center gap-2 rounded-2xl border px-4 py-2.5 text-right transition-all ${
                  i === activeChapterIdx
                    ? 'border-amber-400/60 bg-amber-400/10 shadow-lg shadow-amber-500/10'
                    : 'border-white/8 bg-white/[0.03] hover:border-white/20 hover:bg-white/[0.06]'
                }`}
              >
                <span
                  className="flex h-8 w-8 items-center justify-center rounded-xl text-sm font-black"
                  style={{ background: `${ch.accent}22`, color: ch.accent }}
                >
                  {toFaDigits(ch.id)}
                </span>
                <span>
                  <span className={`block text-sm font-bold ${i === activeChapterIdx ? 'text-amber-200' : 'text-slate-200'}`}>
                    {ch.shortName}
                  </span>
                  <span className="block text-[11px] text-slate-500">{ch.badge}</span>
                </span>
              </button>
            ))}
          </div>

          {audioError && (
            <div className="mt-3 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
              {audioError}
            </div>
          )}

          {/* ── Audio mixers ── */}
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {(
              [
                { key: 'voiceVol', label: 'صدای استاد', icon: Mic2, color: '#fbbf24' },
                { key: 'musicVol', label: 'موسیقی زمینه', icon: Music4, color: '#a78bfa' },
                { key: 'sfxVol', label: 'افکت‌های صوتی', icon: Sparkles, color: '#34d399' },
              ] as const
            ).map((m) => (
              <div key={m.key} className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3">
                <m.icon className="h-5 w-5 shrink-0" style={{ color: m.color }} />
                <div className="flex-1">
                  <div className="mb-1.5 flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-300">{m.label}</span>
                    <span className="tabular-nums text-slate-500">{toFaDigits(Math.round(mix[m.key] * 100))}٪</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1.4}
                    step={0.05}
                    value={mix[m.key]}
                    onChange={(e) => setMix((s) => ({ ...s, [m.key]: Number(e.target.value) }))}
                    className="mix-slider w-full"
                    aria-label={m.label}
                  />
                </div>
                <button
                  onClick={() => setMix((s) => ({ ...s, [m.key]: s[m.key] > 0 ? 0 : DEFAULT_MIX[m.key] }))}
                  className="text-slate-500 transition hover:text-amber-300"
                  aria-label="بی‌صدا"
                >
                  {mix[m.key] > 0 ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* ── Ready server-rendered deliverables ── */}
        <section
          id="delivered"
          className="mt-8 overflow-hidden rounded-3xl border border-emerald-400/30 bg-gradient-to-l from-emerald-500/12 via-teal-500/6 to-sky-500/8 p-5 sm:p-6"
        >
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 shadow-lg shadow-emerald-500/30">
                <Download className="h-6 w-6 text-slate-950" />
              </span>
              <div>
                <h2 className="text-xl font-black text-emerald-100">نسخهٔ آماده و رندر‌شده — دانلود مستقیم</h2>
                <p className="mt-0.5 text-xs text-emerald-200/70">
                  رندر کامل روی سرور انجام شد؛ کل فایل صوتی پوشش داده شده — بدون نیاز به رندر در مرورگر
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 text-[11px] font-bold">
              <span className="rounded-full border border-emerald-300/30 bg-emerald-400/10 px-3 py-1 text-emerald-200">
                مدت: {DELIVERED.durationFa}
              </span>
              <span className="rounded-full border border-sky-300/30 bg-sky-400/10 px-3 py-1 text-sky-200">
                ۷۲۰p • ۳۰fps • H.264
              </span>
              <span className="rounded-full border border-violet-300/30 bg-violet-400/10 px-3 py-1 text-violet-200">
                ۱۲ فصل المان‌محور
              </span>
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-2">
            <a
              href={DELIVERED.videoPage}
              target="_blank"
              rel="noreferrer noopener"
              className="group flex items-center gap-3 rounded-2xl bg-gradient-to-l from-emerald-400 to-teal-500 px-4 py-3.5 font-black text-slate-950 shadow-xl shadow-emerald-500/20 transition hover:brightness-110"
            >
              <Film className="h-6 w-6" />
              <span className="flex-1">
                دانلود ویدیوی کامل MP4
                <span className="block text-[11px] font-semibold text-slate-900/70">
                  {DELIVERED.videoFile} • {DELIVERED.videoSizeFa} • گوفایل
                </span>
              </span>
              <Download className="h-5 w-5 transition-transform group-hover:translate-y-0.5" />
            </a>
            <a
              href={DELIVERED.audioPage}
              target="_blank"
              rel="noreferrer noopener"
              className="group flex items-center gap-3 rounded-2xl border border-violet-300/40 bg-violet-400/15 px-4 py-3.5 font-black text-violet-100 transition hover:bg-violet-400/25"
            >
              <Music4 className="h-6 w-6" />
              <span className="flex-1">
                دانلود صدای میکس‌شده (جداگانه)
                <span className="block text-[11px] font-semibold text-violet-200/70">
                  {DELIVERED.audioFile} • {DELIVERED.audioSizeFa} • گوفایل
                </span>
              </span>
              <Download className="h-5 w-5 transition-transform group-hover:translate-y-0.5" />
            </a>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-black/25 px-4 py-3 text-[11px] text-slate-300">
            <span>
              صدای استاد + موسیقی ملایم زمینه + افکت‌های صوتی، میکس‌شده در یک فایل — زیرنویس فارسی و ۱۲ فصل روی تصویر
            </span>
            <a
              href={DELIVERED.mirrorBin}
              target="_blank"
              rel="noreferrer noopener"
              className="shrink-0 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 font-bold text-slate-200 transition hover:border-emerald-300/50 hover:text-emerald-200"
            >
              آینهٔ دانلود (Filebin) ↗
            </a>
          </div>
          <p className="mt-2 text-[11px] leading-5 text-slate-400">
            اگر لینک گوفایل باز نشد، از آینهٔ فایلبین استفاده کنید. همچنین می‌توانید با کارت پایین، نسخهٔ سفارشی (کیفیت یا
            بدون زیرنویس) را همین‌جا در مرورگر بسازید.
          </p>
        </section>

        {/* ── Export studio ── */}
        <section className="mt-10" id="export">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-400 to-indigo-500 shadow-lg shadow-sky-500/25">
              <Download className="h-5 w-5 text-slate-950" />
            </div>
            <div>
              <h2 className="text-xl font-black">ساخت و دانلود خروجی</h2>
              <p className="text-xs text-slate-400">
                ویدیوی MP4 با کیفیت بالا + موسیقی و افکت‌های صوتی میکس‌شده — دانلود مستقیم از همین مرورگر
              </p>
            </div>
          </div>

          {!webCodecs && (
            <div className="mb-4 rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
              مرورگر شما از WebCodecs پشتیبانی نمی‌کند. برای ساخت MP4 لطفاً از Chrome یا Edge نسخه جدید استفاده کنید.
            </div>
          )}

          <div className="grid gap-4 lg:grid-cols-2">
            {/* Video export card */}
            <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
              <div className="mb-4 flex items-center gap-3">
                <Film className="h-6 w-6 text-sky-300" />
                <div>
                  <h3 className="font-black text-slate-100">ویدیوی کامل MP4</h3>
                  <p className="text-xs text-slate-500">موشن گرافیک + صدای استاد + موسیقی + افکت — یک فایل واحد</p>
                </div>
              </div>

              <div className="mb-4 flex flex-wrap items-center gap-2">
                {(['720p', '1080p'] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setExpRes(r)}
                    disabled={exporting}
                    className={`rounded-xl px-4 py-2 text-sm font-bold transition ${
                      expRes === r
                        ? 'bg-sky-400 text-slate-950 shadow-lg shadow-sky-400/30'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    {toFaDigits(r === '720p' ? '720' : '1080')}p
                  </button>
                ))}
                <button
                  onClick={() => setExpSubs((s) => !s)}
                  disabled={exporting}
                  className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-bold transition ${
                    expSubs ? 'bg-emerald-400/15 text-emerald-300' : 'bg-white/5 text-slate-400 hover:bg-white/10'
                  }`}
                >
                  <Subtitles className="h-4 w-4" />
                  زیرنویس‌ها
                </button>
                <span className="mr-auto rounded-lg bg-white/5 px-2.5 py-1 text-[11px] text-slate-500">۳۰ فریم بر ثانیه</span>
              </div>

              <button
                onClick={runVideoExport}
                disabled={exporting || !webCodecs || !audioReady}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-sky-400 to-indigo-500 px-5 py-3.5 font-black text-slate-950 shadow-xl shadow-sky-500/25 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {exporting && exportKind === 'video' ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    در حال ساخت… {toFaDigits(Math.round(progress?.percent ?? 0))}٪
                  </>
                ) : (
                  <>
                    <Wand2 className="h-5 w-5" />
                    ساخت MP4 و دانلود
                  </>
                )}
              </button>
              <p className="mt-2 text-center text-[11px] text-slate-500">
                رندر آفلاین (سریع‌تر از پخش زنده) — برای ویدیوی کامل چند دقیقه صبر کنید
              </p>

              {videoResult && (
                <div className="mt-4 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4">
                  <div className="mb-2 flex items-center gap-2 text-sm font-bold text-emerald-300">
                    <Sparkles className="h-4 w-4" /> فایل ویدیو آماده است!
                  </div>
                  <p className="text-xs text-slate-400">
                    {videoResult.result.filename} • {formatBytes(videoResult.result.sizeBytes)} • {videoResult.result.codecLabel}
                  </p>
                  <button
                    onClick={() => download(videoResult.url, videoResult.result.filename)}
                    className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-2.5 font-black text-slate-950 transition hover:brightness-110"
                  >
                    <Download className="h-4 w-4" />
                    دانلود مستقیم MP4
                  </button>
                </div>
              )}
            </div>

            {/* Audio export card */}
            <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
              <div className="mb-4 flex items-center gap-3">
                <AudioLines className="h-6 w-6 text-violet-300" />
                <div>
                  <h3 className="font-black text-slate-100">صدای میکس‌شده (جداگانه)</h3>
                  <p className="text-xs text-slate-500">صدای استاد + موسیقی ملایم + افکت‌ها — بدون ویدیو</p>
                </div>
              </div>
              <p className="mb-4 rounded-2xl bg-white/[0.04] px-4 py-3 text-xs leading-6 text-slate-400">
                همین میکس صدایی که در ویدیو می‌شنوید، به‌صورت فایل صوتی جداگانه هم قابل دانلود است؛ مناسب برای انتشار در
                پلتفرم‌های صوتی.
              </p>
              <button
                onClick={runAudioExport}
                disabled={exporting || !webCodecs || !audioReady}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-violet-400 to-fuchsia-500 px-5 py-3.5 font-black text-slate-950 shadow-xl shadow-violet-500/25 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {exporting && exportKind === 'audio' ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" /> در حال ساخت…
                  </>
                ) : (
                  <>
                    <Music4 className="h-5 w-5" />
                    ساخت و دانلود صدا
                  </>
                )}
              </button>

              {audioResult && (
                <div className="mt-4 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4">
                  <div className="mb-2 flex items-center gap-2 text-sm font-bold text-emerald-300">
                    <Sparkles className="h-4 w-4" /> فایل صوتی آماده است!
                  </div>
                  <p className="text-xs text-slate-400">
                    {audioResult.result.filename} • {formatBytes(audioResult.result.sizeBytes)} • {audioResult.result.codecLabel}
                  </p>
                  <button
                    onClick={() => download(audioResult.url, audioResult.result.filename)}
                    className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-2.5 font-black text-slate-950 transition hover:brightness-110"
                  >
                    <Download className="h-4 w-4" />
                    دانلود صدا
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Progress panel */}
          {(exporting || exportError) && (
            <div className="mt-4 rounded-3xl border border-white/10 bg-white/[0.03] p-5">
              {exportError ? (
                <div className="flex items-center gap-2 text-sm text-rose-300">
                  <Square className="h-4 w-4" /> خطا در ساخت خروجی: {exportError}
                </div>
              ) : (
                <>
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="font-bold text-slate-200">{progress?.detail ?? 'آماده‌سازی…'}</span>
                    <span className="tabular-nums font-black text-amber-300">{toFaDigits(Math.round(progress?.percent ?? 0))}٪</span>
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-gradient-to-l from-amber-400 to-orange-500 transition-all"
                      style={{ width: `${progress?.percent ?? 0}%` }}
                    />
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                    <span>
                      {progress && progress.totalFrames > 0
                        ? `فریم ${toFaDigits(progress.currentFrame)} از ${toFaDigits(progress.totalFrames)}`
                        : ''}
                    </span>
                    <button
                      onClick={cancelExport}
                      className="flex items-center gap-1 rounded-lg bg-rose-500/15 px-2.5 py-1 font-bold text-rose-300 transition hover:bg-rose-500/25"
                    >
                      <Square className="h-3 w-3" /> لغو
                    </button>
                  </div>
                  <canvas ref={previewCanvasRef} className="mt-4 w-full rounded-xl border border-white/10" />
                </>
              )}
            </div>
          )}
        </section>

        {/* ── How it works ── */}
        <section className="mt-10 grid gap-4 md:grid-cols-3">
          {[
            {
              icon: Film,
              title: '۱۲ فصل المان‌محور',
              desc: 'از طلوعِ بسم‌الله تا حمدِ پایانی؛ هر فصل با ماندالا، المان‌های شناور، آیه و زیرنویسِ همگام با صدا.',
            },
            {
              icon: Music4,
              title: 'میکس حرفه‌ای صدا',
              desc: 'موسیقی پدِ آرامش‌بخش، آرپژِ ملایم، ووشِ گذارِ فصل‌ها و زنگِ ظریف المان‌ها — همه با Web Audio سنتز می‌شوند.',
            },
            {
              icon: Settings2,
              title: 'خروجی MP4 مستقیم',
              desc: 'رندر آفلاین با WebCodecs — فایل نهایی همین‌جا در مرورگر شما ساخته و مستقیم دانلود می‌شود؛ بدون آپلود.',
            },
          ].map((f) => (
            <div key={f.title} className="rounded-3xl border border-white/8 bg-white/[0.03] p-5">
              <f.icon className="mb-3 h-7 w-7 text-amber-300" />
              <h3 className="mb-1.5 font-black text-slate-100">{f.title}</h3>
              <p className="text-sm leading-7 text-slate-400">{f.desc}</p>
            </div>
          ))}
        </section>

        <footer className="mt-12 border-t border-white/5 pt-6 text-center text-xs text-slate-500">
          گامِ نصر — فصل ۱، قسمت ۵ • موشن گرافیک المان‌محور با خروجی MP4 • ساخته‌شده با React، Canvas و WebCodecs
        </footer>
      </main>
    </div>
  );
}
