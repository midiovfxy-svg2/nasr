import { SKY } from './sky';
import { EARTH } from './earth';
import { SEA } from './sea';
import { BODY } from './body';
import { MADE } from './made';
import type { AGroup, AItem, ARealm } from './kit';

export type { AGroup, AItem, ARealm } from './kit';

// سه بخش اصلی: آسمان، زمین، دریا؛ و دو بخش ویژه: جسم انسان و دست‌ساخته‌های بشر
export const REALMS: ARealm[] = [SKY, EARTH, SEA, BODY, MADE];
export const MAIN_REALMS = 3;

export const itemKey = (group: AGroup, item: AItem) => `${group.id}:${item[1]}`;

export interface Entry {
  realm: ARealm;
  group: AGroup;
  item: AItem;
  key: string;
}

export const ALL_ENTRIES: Entry[] = REALMS.flatMap((realm) =>
  realm.groups.flatMap((group) => group.items.map((item) => ({ realm, group, item, key: itemKey(group, item) }))),
);

export const TOTAL_ITEMS = ALL_ENTRIES.length;

export function findRealm(id?: string | null) {
  return REALMS.find((r) => r.id === id) || null;
}

export function findGroup(realm: ARealm | null, id?: string | null) {
  return realm?.groups.find((g) => g.id === id) || null;
}

export const entriesOf = (realm: ARealm, group: AGroup): Entry[] => group.items.map((item) => ({ realm, group, item, key: itemKey(group, item) }));

// برای جستجو: یکسان‌سازی ی/ک عربی و نیم‌فاصله
export const norm = (s: string) =>
  s
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u200c\u064b-\u065f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
