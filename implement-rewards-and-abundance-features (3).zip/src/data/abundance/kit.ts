// ساختار گنجینهٔ فراوانی‌ها: بخش (آسمان/زمین/…) ← گروه (سنگ‌ها/درختان/…) ← نعمت‌ها
// هر نعمت: [تصویر، نام، مشخصات]

export type AItem = readonly [art: string, name: string, spec: string];

export interface Verse {
  ar: string;
  ref: string;
}

export interface AGroup {
  id: string;
  name: string;
  icon: string;
  blurb: string;
  verse?: Verse;
  items: AItem[];
}

export interface ARealm {
  id: string;
  name: string;
  icon: string;
  tagline: string;
  from: string;
  to: string;
  verse?: Verse;
  groups: AGroup[];
}

// ————— سازنده‌های تصویر (نگاه کنید به components/Art.tsx) —————
export const rock = (c1: string, c2: string, pattern = 'plain') => `~rock:${c1}:${c2}:${pattern}`;
export const gem = (c1: string, c2: string, cut = 'brilliant') => `~gem:${c1}:${c2}:${cut}`;
export const ingot = (c1: string, c2: string) => `~ingot:${c1}:${c2}`;
export const planet = (c1: string, c2: string, feat = 'none') => `~planet:${c1}:${c2}:${feat}`;
export const tree = (shape: string, leaf: string, trunk = '#6b4423', fruit = '') => `~tree:${shape}:${leaf}:${trunk}${fruit ? ':' + fruit : ''}`;
export const fruit = (c1: string, c2: string, shape = 'round', leaf = '#3f9a46') => `~fruit:${c1}:${c2}:${shape}:${leaf}`;
export const veg = (c1: string, c2: string, shape = 'leaf') => `~veg:${c1}:${c2}:${shape}`;
export const seeds = (c1: string, c2: string, shape = 'round') => `~seeds:${c1}:${c2}:${shape}`;
export const flower = (petal: string, center: string, shape = 'five') => `~flower:${petal}:${center}:${shape}`;
export const cloud = (type: string) => `~cloud:${type}`;
export const fish = (c1: string, c2: string, pattern = 'plain', shape = 'normal') => `~fish:${c1}:${c2}:${pattern}:${shape}`;
export const shell = (c1: string, c2: string, kind = 'fan') => `~shell:${c1}:${c2}:${kind}`;
export const bird = (c1: string, c2: string, feat = 'none') => `~bird:${c1}:${c2}:${feat}`;
export const coral = (c: string) => `~coral:${c}`;
export const jelly = (c1: string, c2: string) => `~jelly:${c1}:${c2}`;
export const organ = (c1: string, c2: string, shape: string) => `~organ:${c1}:${c2}:${shape}`;
