import { useMemo } from 'react';
import qrcode from 'qrcode-generator';

// QR واقعی و قابل اسکن با دوربین گوشی؛ به‌صورت SVG برداری رسم می‌شود (برای چاپ هم شفاف می‌ماند)
export function QrCode({ value, size = 160, quiet = 2, fg = '#0f172a', bg = '#ffffff', rounded = true, className }: { value: string; size?: number; quiet?: number; fg?: string; bg?: string; rounded?: boolean; className?: string }) {
  const { n, path } = useMemo(() => {
    const qr = qrcode(0, 'M');
    qr.addData(value);
    qr.make();
    const count = qr.getModuleCount();
    let d = '';
    for (let r = 0; r < count; r++) {
      for (let c = 0; c < count; c++) {
        if (qr.isDark(r, c)) d += `M${c + quiet} ${r + quiet}h1v1h-1z`;
      }
    }
    return { n: count, path: d };
  }, [value, quiet]);
  const total = n + quiet * 2;
  return (
    <svg viewBox={`0 0 ${total} ${total}`} width={size} height={size} className={className} role="img" aria-label="کد QR" shapeRendering="crispEdges" style={{ display: 'block' }}>
      <rect width={total} height={total} fill={bg} rx={rounded ? total * 0.05 : 0} />
      <path d={path} fill={fg} />
    </svg>
  );
}
