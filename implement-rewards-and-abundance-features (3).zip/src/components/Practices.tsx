import { useEffect, useMemo, useRef, useState, type MouseEvent } from 'react';
import { Trash2 } from 'lucide-react';
import { ALL_ENTRIES } from '../data/abundance';
import { reducedMotion, type Point } from '../lib/coins';
import { faNum, shuffle, todayKey, type Profile } from '../lib/storage';
import { cn } from '../utils/cn';
import { Art } from './Art';
import { Btn, SourceTag } from './ui';

// ————— تمرین‌های هم‌راستا با آموزه‌های استاد —————
// دفتر شکر، تمرین صلات، چرخهٔ هفت‌مرحله‌ای تحقق خواسته و دوازده مانع ذهنی

interface PracticeProps {
  kids?: boolean;
  profile: Profile;
  onReward: (amount: number, origin?: Point) => void;
  onBoost: (delta: number) => void;
  onAnswer?: (ok: boolean) => void;
}

// ذخیرهٔ خصوصی روی همین دستگاه (برای هر حساب جدا)
function useStored<T>(key: string, init: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : init;
    } catch {
      return init;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* ذخیره‌سازی اختیاری است */
    }
  }, [key, value]);
  return [value, setValue] as const;
}

function Chip({ children, kids }: { children: string; kids?: boolean }) {
  return <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium', kids ? 'bg-amber-100 text-amber-800' : 'bg-white/5 text-amber-200/70')}>📜 {children}</span>;
}

function Note({ children, src, kids, big }: { children: string; src?: string; kids?: boolean; big?: boolean }) {
  return (
    <div className={cn('rounded-2xl border px-4 py-3.5 animate-pop', kids ? 'border-sky-200 bg-white text-slate-800 shadow-sm' : 'border-white/10 bg-white/[0.04] text-slate-100')}>
      <p className={cn('whitespace-pre-line leading-8', big ? 'text-lg' : 'text-[15px]')}>{children}</p>
      {src && (
        <div className="mt-2 flex justify-end">
          <Chip kids={kids}>{src}</Chip>
        </div>
      )}
    </div>
  );
}

function Arabic({ ar, refText, kids }: { ar: string; refText: string; kids?: boolean }) {
  return (
    <div className={cn('rounded-2xl border px-4 py-3 text-center', kids ? 'border-emerald-300 bg-emerald-50' : 'border-amber-300/30 bg-gradient-to-b from-amber-200/10 to-transparent')}>
      <p dir="rtl" className={cn('quran text-xl', kids ? 'text-emerald-800' : 'text-amber-100')}>{ar}</p>
      <span className={cn('mt-1 inline-flex rounded-full px-2 py-0.5 text-[10px] font-medium', kids ? 'bg-amber-100 text-amber-800' : 'bg-white/5 text-amber-200/70')}>📖 {refText}</span>
    </div>
  );
}

const pt = (e: MouseEvent): Point => ({ x: e.clientX, y: e.clientY });

// ═════════════════ ۱) دفتر شکر: بنویس، ببین، نسبت بده ═════════════════
interface JournalEntry {
  id: string;
  day: string;
  ts: number;
  text: string;
  hand: string;
}

const HANDS = ['خورشید و آسمان', 'باران و باد', 'انسانی مهربان', 'سلامتی و جسم', 'رزق و روزی', 'هدایت و پیام', 'خانواده', 'طبیعت'];

export function GratitudeJournal({ kids, profile, onReward, onBoost }: PracticeProps) {
  const [entries, setEntries] = useStored<JournalEntry[]>(`nasr-journal-v1:${profile.id}`, []);
  const [text, setText] = useState('');
  const [hand, setHand] = useState('');
  const [just, setJust] = useState(false);
  const today = todayKey();
  const todays = entries.filter((e) => e.day === today);
  const days = new Set(entries.map((e) => e.day));
  let streak = 0;
  const d = new Date();
  if (!days.has(todayKey(d))) d.setDate(d.getDate() - 1);
  while (days.has(todayKey(d))) {
    streak++;
    d.setDate(d.getDate() - 1);
  }
  const muted = kids ? 'text-slate-500' : 'text-slate-400';

  const save = (e: MouseEvent) => {
    const clean = text.trim();
    if (clean.length < 3) return;
    const entry: JournalEntry = { id: crypto.randomUUID(), day: today, ts: Date.now(), text: clean.slice(0, 280), hand };
    setEntries((list) => [entry, ...list].slice(0, 400));
    if (todays.length < 3) onReward(3, pt(e));
    onBoost(1);
    setText('');
    setHand('');
    setJust(true);
    setTimeout(() => setJust(false), 2600);
  };

  const grouped = useMemo(() => {
    const map = new Map<string, JournalEntry[]>();
    entries.slice(0, 60).forEach((e) => map.set(e.day, [...(map.get(e.day) || []), e]));
    return [...map.entries()];
  }, [entries]);

  return (
    <div className="space-y-4">
      <Note kids={kids} src="کتابچهٔ جلسهٔ دوازدهم ۱۴۰۴">{'یک گل را که می‌بینی، لذت ببر. یک مورچه را که می‌بینی، شگفت‌زده شو. همین که به هر چه می‌رسی شکر کنی، فراوانی‌ها آرام‌آرام در زندگی‌ات تغییر می‌کنند.'}</Note>

      <div className={cn('grid grid-cols-3 gap-2 text-center text-xs font-black')}>
        {[
          ['✍️', 'بنویس', 'نعمتی که دیدی'],
          ['👁️', 'ببین', 'دست خدا را در آن'],
          ['🤲', 'نسبت بده', 'هذا من فضل ربي'],
        ].map(([e, t, s]) => (
          <div key={t} className={cn('rounded-2xl border p-2.5', kids ? 'border-sky-200 bg-white' : 'border-white/10 bg-white/5')}>
            <div className="text-2xl">{e}</div>
            <div>{t}</div>
            <div className={cn('text-[10px] font-medium', muted)}>{s}</div>
          </div>
        ))}
      </div>

      <div className={cn('flex items-center justify-between rounded-2xl px-4 py-2.5 text-sm font-black', kids ? 'bg-amber-100 text-amber-800' : 'bg-amber-300/10 text-amber-200')}>
        <span className="flex items-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <span key={i} className={cn('text-xl transition', i < todays.length ? '' : 'opacity-25 grayscale')}>🤲</span>
          ))}
          <span className="mr-1 text-xs">{faNum(Math.min(todays.length, 3))} از ۳ دست خدا امروز</span>
        </span>
        <span className="text-xs">🔥 {faNum(streak)} روز پیاپی</span>
      </div>

      <div className={cn('space-y-3 rounded-3xl border p-4', kids ? 'border-sky-200 bg-white' : 'border-white/10 bg-white/[0.04]')}>
        <label className="block text-sm font-black" htmlFor="journal-text">امروز چه نعمتی دیدی؟</label>
        <textarea
          id="journal-text"
          value={text}
          maxLength={280}
          rows={3}
          onChange={(e) => setText(e.target.value)}
          placeholder="مثلاً: امروز بوی نان تازه را حس کردم و از خدا ممنون شدم…"
          className={cn('w-full resize-none rounded-2xl border px-4 py-3 text-[15px] leading-7 outline-none', kids ? 'border-sky-200 bg-sky-50 text-slate-800 focus:border-orange-300' : 'border-white/10 bg-black/20 text-white placeholder:text-slate-500 focus:border-amber-300/60')}
        />
        <div>
          <div className={cn('mb-1.5 text-xs font-bold', muted)}>دست خدا کدام بود؟ (اختیاری)</div>
          <div className="flex flex-wrap gap-1.5">
            {HANDS.map((h) => (
              <button key={h} onClick={() => setHand(hand === h ? '' : h)} className={cn('rounded-full border px-3 py-1 text-xs font-bold transition active:scale-95', hand === h ? (kids ? 'border-orange-400 bg-orange-400 text-white' : 'border-amber-300 bg-amber-300 text-slate-900') : kids ? 'border-sky-200 bg-white' : 'border-white/15 bg-white/5')}>
                {h}
              </button>
            ))}
          </div>
        </div>
        <Btn variant={kids ? 'kids' : 'gold'} className="w-full py-3" disabled={text.trim().length < 3} onClick={save}>
          ثبت و شکر کردن 🤲
        </Btn>
        {just && <div className={cn('text-center text-sm font-black animate-pop', kids ? 'text-emerald-600' : 'text-emerald-300')}>هذا من فضل ربي؛ الحمدلله رب العالمین ✨</div>}
        <div className={cn('text-center text-[10px] leading-5', muted)}>🔒 دفتر شکر فقط روی همین دستگاه ذخیره می‌شود و برای کسی ارسال نمی‌شود.</div>
      </div>

      {grouped.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-sm font-black">دفتر شکر من</h4>
          {grouped.map(([day, list]) => (
            <div key={day} className="space-y-1.5">
              <div className={cn('text-[11px] font-bold', muted)}>{day === today ? 'امروز' : new Date(list[0].ts).toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
              {list.map((en) => (
                <div key={en.id} className={cn('flex items-start gap-2 rounded-2xl border p-3', kids ? 'border-sky-200 bg-white' : 'border-white/10 bg-white/[0.04]')}>
                  <span className="mt-0.5 text-lg">🌱</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm leading-7">{en.text}</p>
                    {en.hand && <span className={cn('mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-bold', kids ? 'bg-amber-100 text-amber-800' : 'bg-amber-300/10 text-amber-200')}>دست خدا: {en.hand}</span>}
                  </div>
                  <button onClick={() => setEntries((l) => l.filter((x) => x.id !== en.id))} className={cn('grid h-8 w-8 shrink-0 place-items-center rounded-full', muted)} aria-label="حذف این یادداشت">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═════════════════ ۲) تمرین صلات: توجه و تمرکز صددرصدی ═════════════════
export function SalatFocus({ kids, profile, onReward, onBoost }: PracticeProps) {
  const [dur, setDur] = useState(60);
  const [phase, setPhase] = useState<'idle' | 'run' | 'done' | 'lost'>('idle');
  const [left, setLeft] = useState(60);
  const [target, setTarget] = useState(() => ALL_ENTRIES[Math.floor(Math.random() * ALL_ENTRIES.length)]);
  const [limit, setLimit] = useStored<{ day: string; n: number }>(`nasr-salat-v1:${profile.id}`, { day: '', n: 0 });
  const startedAt = useRef(0);
  const reduce = reducedMotion();
  const reward = { 30: 3, 60: 5, 90: 8 }[dur] || 5;
  const today = todayKey();
  const usedToday = limit.day === today ? limit.n : 0;
  const muted = kids ? 'text-slate-500' : 'text-slate-400';

  const start = () => {
    setTarget(ALL_ENTRIES[Math.floor(Math.random() * ALL_ENTRIES.length)]);
    startedAt.current = Date.now();
    setLeft(dur);
    setPhase('run');
  };

  useEffect(() => {
    if (phase !== 'run') return;
    const timer = setInterval(() => {
      const remain = dur - (Date.now() - startedAt.current) / 1000;
      if (remain <= 0) {
        setLeft(0);
        setPhase('done');
      } else setLeft(remain);
    }, 200);
    // اگر توجه از صفحه پرید (برگه عوض شد)، تمرین از اول شروع می‌شود
    const hidden = () => document.hidden && setPhase('lost');
    document.addEventListener('visibilitychange', hidden);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', hidden);
    };
  }, [phase, dur]);

  const rewarded = useRef(false);
  useEffect(() => {
    if (phase !== 'done') {
      rewarded.current = false;
      return;
    }
    if (rewarded.current) return;
    rewarded.current = true;
    onBoost(3);
    if (usedToday < 3) {
      onReward(reward, { x: window.innerWidth / 2, y: window.innerHeight * 0.4 });
      setLimit({ day: today, n: usedToday + 1 });
    }
    // فقط یک بار هنگام پایان تمرین
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const R = 92;
  const C = 2 * Math.PI * R;
  const progress = phase === 'run' ? 1 - left / dur : phase === 'done' ? 1 : 0;

  return (
    <div className="space-y-4">
      <Note kids={kids} big>{'صلات یعنی توجه و تمرکز ۱۰۰ درصدی بر هدف؛ نه تکرار حرکت‌ها، بلکه حضور کامل.'}</Note>
      <div className="flex justify-end"><SourceTag s="bl" kids={kids} /></div>

      <div className={cn('rounded-3xl border p-5 text-center', kids ? 'border-sky-200 bg-white' : 'border-white/10 bg-white/[0.04]')}>
        <div className="relative mx-auto grid h-64 w-64 place-items-center">
          <svg viewBox="0 0 200 200" className="absolute inset-0 -rotate-90" aria-hidden="true">
            <circle cx="100" cy="100" r={R} fill="none" stroke={kids ? '#e0f2fe' : 'rgba(255,255,255,.1)'} strokeWidth="7" />
            <circle cx="100" cy="100" r={R} fill="none" stroke="url(#salatGrad)" strokeWidth="7" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - progress)} style={{ transition: 'stroke-dashoffset .25s linear' }} />
            <defs>
              <linearGradient id="salatGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#fcd34d" />
                <stop offset="1" stopColor="#34d399" />
              </linearGradient>
            </defs>
          </svg>
          <div
            className="absolute h-48 w-48 rounded-full bg-[radial-gradient(circle,rgba(252,211,77,.35),rgba(52,211,153,.12)_60%,transparent_72%)]"
            style={phase === 'run' && !reduce ? { animation: 'breathe 6s ease-in-out infinite' } : { opacity: 0.6 }}
          />
          <div className="relative">
            {phase === 'idle' || phase === 'lost' ? <div className="text-6xl">🧘</div> : <Art a={target.item[0]} size={phase === 'done' ? 70 : 96} />}
          </div>
        </div>

        {phase === 'idle' && (
          <div className="space-y-3">
            <p className={cn('text-sm leading-7', muted)}>یک نعمت می‌آید. فقط به آن نگاه کن، نفس عمیق بکش و در دلت شکر کن. اگر از صفحه بیرون بروی، توجه پریده و تمرین از اول شروع می‌شود.</p>
            <div className="flex justify-center gap-2">
              {[30, 60, 90].map((s) => (
                <button key={s} onClick={() => setDur(s)} className={cn('rounded-full px-4 py-1.5 text-xs font-black transition', dur === s ? (kids ? 'bg-orange-400 text-white' : 'bg-amber-300 text-slate-900') : kids ? 'bg-sky-100 text-slate-600' : 'bg-white/10 text-slate-300')}>
                  {faNum(s)} ثانیه
                </button>
              ))}
            </div>
            <Btn variant={kids ? 'kids' : 'gold'} className="w-full py-3.5 text-base" onClick={start}>
              شروع تمرکز ({faNum(reward)} سکه)
            </Btn>
            <div className={cn('text-[11px]', muted)}>سکهٔ این تمرین، روزی حداکثر ۳ بار داده می‌شود · امروز {faNum(usedToday)} از ۳</div>
          </div>
        )}
        {phase === 'run' && (
          <div className="space-y-2">
            <div className="text-4xl font-black tabular-nums">{faNum(Math.ceil(left))}</div>
            <div className="text-lg font-black">{target.item[1]}</div>
            <p className={cn('text-sm leading-7', muted)}>{target.item[2]}</p>
            <div className={cn('text-xs font-bold', kids ? 'text-emerald-600' : 'text-emerald-300')}>فقط نگاه کن و شکر کن… الحمدلله</div>
            <Btn variant={kids ? 'kidsGhost' : 'ghost'} className="mt-1" onClick={() => setPhase('idle')}>
              انصراف
            </Btn>
          </div>
        )}
        {phase === 'done' && (
          <div className="space-y-3 animate-pop">
            <div className="text-xl font-black">ماشاءالله؛ صددرصد حاضر بودی ✨</div>
            <p className={cn('text-sm leading-7', muted)}>{usedToday <= 3 ? `${faNum(reward)} سکه گرفتی.` : 'امروز سکهٔ این تمرین کامل شد؛ ولی حضورت ارزشمند است.'}</p>
            <Btn variant={kids ? 'kids' : 'gold'} className="w-full" onClick={() => setPhase('idle')}>
              یک بار دیگر
            </Btn>
          </div>
        )}
        {phase === 'lost' && (
          <div className="space-y-3 animate-pop">
            <div className="text-lg font-black">توجه‌ات پرید؛ اشکالی ندارد 🌱</div>
            <p className={cn('text-sm leading-7', muted)}>لا جناح علیکم؛ دوباره برگرد و از اول شروع کن. مهم، بازگشت است.</p>
            <Btn variant={kids ? 'kids' : 'gold'} className="w-full" onClick={() => setPhase('idle')}>
              دوباره شروع می‌کنم
            </Btn>
          </div>
        )}
      </div>
    </div>
  );
}

// ═════════════════ ۳) چرخهٔ هفت‌مرحله‌ای تحقق خواسته ═════════════════
const STAGES = [
  { icon: '⚖️', title: 'مسئولیت فردی', text: 'مسئولیت صددرصد خلق زندگی با خود ماست. آدم گفت «ظلمنا أنفسنا» (به خودمان ستم کردیم)؛ نه مثل ابلیس که گفت «بما أغویتنی» (تو مرا گمراه کردی).', ar: 'إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ', ref: 'رعد ۱۱', todo: 'یک ماجرای ناخوشایند را بدون سرزنش دیگران بنویس: سهم من در آن چه بود و از کجا می‌توانم شروع کنم؟' },
  { icon: '👁️', title: 'ورودی‌های ذهن', text: 'نگهبانی از گوش و چشم و دل. چهار اصل: صبر (فاصلهٔ زمانی تا رسیدن)، صلات (توجه و تمرکز صددرصدی)، سیر تکاملی و تصاعدی، و رفع موانع ذهنی.', ar: 'إِنَّ السَّمْعَ وَالْبَصَرَ وَالْفُؤَادَ كُلُّ أُولَٰئِكَ كَانَ عَنْهُ مَسْئُولًا', ref: 'اسراء ۳۶', todo: 'امروز یک ورودیِ منفی (خبر، حرف یا تصویر) را کم کن و یک ورودیِ مثبت جایش بگذار.' },
  { icon: '📡', title: 'ارسال فرکانس ناب و خالص', text: 'دعا یعنی کل وجودم را روی یک خواسته تنظیم کنم و به خدا بسپارم؛ زبان، دل، ذهن و عمل، همه هم‌صدا. این یعنی هم‌جهت شدن با جریان خداوند.', ar: 'ادْعُونِي أَسْتَجِبْ لَكُمْ', ref: 'غافر ۶۰', todo: 'خواسته‌ات را در یک جملهٔ مثبت و با احساس بگو؛ بعد با آرامش به خدا بسپار.' },
  { icon: '📻', title: 'سیستم رادیویی جهان', text: 'جهان با قوانین تغییرناپذیرش فرکانس را دریافت می‌کند و پاسخ می‌دهد. هر چیزی ظرفیت و زمان خودش را دارد.', ar: 'فَلَن تَجِدَ لِسُنَّتِ اللَّهِ تَبْدِيلًا', ref: 'فاطر ۴۳', todo: 'سه نفس عمیق بکش و بگو: «حسابم با خداست». به قانون خدا اعتماد کن.' },
  { icon: '🤲', title: 'هدایت به‌وسیلهٔ دستان خدا', text: 'خدا با دستانش (ابر و باد، خورشید، آدم‌ها، پیام‌ها) راه را نشان می‌دهد؛ مثل آتش موسی، جویبار مریم و هدهد سلیمان. شرطش اعتماد و آرامش است.', ar: 'إِنَّ عَلَيْنَا لَلْهُدَىٰ', ref: 'لیل ۱۲', todo: 'امروز سه «دست خدا» را ببین و در دفتر شکر بنویس.' },
  { icon: '✅', title: 'تأیید؛ صدق بالحسنی', text: 'هدایت و خوبی‌ها را تأیید کن و به خدا نسبت بده: «هذا من فضل ربی». ان‌شاءالله و ماشاءالله از همین جاست.', ar: 'هَٰذَا مِن فَضْلِ رَبِّي', ref: 'نمل ۴۰', todo: 'هر خوبی‌ای که امروز رسید را با «هذا من فضل ربی» تأیید کن.' },
  { icon: '🌟', title: 'پایان چرخه و تحقق خواسته', text: 'خواسته محقق می‌شود؛ شکر، بخشش و انتخاب هدف بعدی. چرخه تمام می‌شود تا چرخهٔ تازه‌ای آغاز شود.', ar: 'فَإِذَا فَرَغْتَ فَانصَبْ', ref: 'شرح ۷', todo: 'شکر کن، آنچه را باید ببخش و هدف بعدی‌ات را انتخاب کن.' },
];

const CYCLE_PRAYER = 'بسم الله الرحمن الرحیم. الحمدلله رب العالمین. خدایا، مسئولیت زندگی‌ام را می‌پذیرم و از تو یاری می‌خواهم. ورودی‌های ذهنم را نگهبانی کن و مرا صبر، توجه و رشد بده. موانع ذهنی را از من دور کن. خواسته‌ام را با فرکانس خالص به تو می‌سپارم. مرا به دستان خودت هدایت کن و چشمم را به دیدن آن‌ها باز کن. هدایتت را تأیید می‌کنم و می‌گویم: هذا من فضل ربی. شکرت را به جا می‌آورم و در پایان هر چرخه، آمادهٔ چرخهٔ بعد می‌شوم. اهدنا الصراط المستقیم. آمین.';

export function CycleWheel({ kids, profile, onReward, onBoost }: PracticeProps) {
  const [state, setState] = useStored<{ visited: number[]; stage: number; desire: string; done: boolean }>(`nasr-cycle-v1:${profile.id}`, { visited: [], stage: -1, desire: '', done: false });
  const [sel, setSel] = useState(0);
  const muted = kids ? 'text-slate-500' : 'text-slate-400';
  const st = STAGES[sel];

  const choose = (i: number, e: MouseEvent) => {
    setSel(i);
    if (state.visited.includes(i)) return;
    const visited = [...state.visited, i];
    const finished = visited.length === STAGES.length && !state.done;
    setState({ ...state, visited, done: state.done || finished });
    onBoost(1);
    onReward(finished ? 11 : 1, pt(e));
  };

  const cx = 150;
  const cy = 150;
  const R = 104;
  const pos = (i: number) => {
    const a = -Math.PI / 2 + (i * 2 * Math.PI) / STAGES.length;
    return { x: cx + Math.cos(a) * R, y: cy + Math.sin(a) * R };
  };

  return (
    <div className="space-y-4">
      <div className={cn('rounded-3xl p-4 text-center', kids ? 'bg-gradient-to-l from-violet-300 to-sky-300 text-white' : 'bg-gradient-to-l from-violet-400/20 to-amber-300/10')}>
        <div className="text-xl font-black">چرخهٔ هفت‌مرحله‌ای تحقق خواسته</div>
        <div className="mt-1 text-xs opacity-85">از ایمان به غیب تا رسیدن به خواسته؛ روی هر مرحله بزن</div>
        <div className="mt-2"><Chip kids={kids}>کتابچهٔ چرخهٔ تحقق خواسته</Chip></div>
      </div>

      <label className="block">
        <span className="mb-1 block text-xs font-black">خواستهٔ من (فقط روی همین دستگاه ذخیره می‌شود)</span>
        <input
          value={state.desire}
          maxLength={120}
          onChange={(e) => setState({ ...state, desire: e.target.value })}
          placeholder="مثلاً: سلامت و آرامش برای خانواده‌ام"
          className={cn('w-full rounded-2xl border px-4 py-3 text-[15px] outline-none', kids ? 'border-sky-200 bg-white text-slate-800 focus:border-orange-300' : 'border-white/10 bg-black/20 text-white placeholder:text-slate-500 focus:border-amber-300/60')}
        />
      </label>

      <div className="relative mx-auto w-full max-w-[340px]">
        <svg viewBox="0 0 300 300" className="w-full" role="group" aria-label="نمودار چرخهٔ تحقق خواسته">
          <circle cx={cx} cy={cy} r={R} fill="none" stroke={kids ? '#bae6fd' : 'rgba(255,255,255,.14)'} strokeWidth="2" strokeDasharray="4 6" />
          {STAGES.map((_, i) => {
            const a = pos(i);
            const b = pos((i + 1) % STAGES.length);
            const lit = state.visited.includes(i) && state.visited.includes((i + 1) % STAGES.length);
            return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={lit ? '#fbbf24' : 'transparent'} strokeWidth="3" strokeLinecap="round" opacity="0.8" />;
          })}
          <text x={cx} y={cy - 6} textAnchor="middle" fontSize="15" fontWeight="800" fill={kids ? '#334155' : '#fde68a'}>{state.desire ? 'خواستهٔ من' : 'خواسته'}</text>
          <text x={cx} y={cy + 14} textAnchor="middle" fontSize="11" fill={kids ? '#64748b' : '#cbd5e1'}>{faNum(state.visited.length)} از {faNum(STAGES.length)} مرحله</text>
          {STAGES.map((s, i) => {
            const p = pos(i);
            const visited = state.visited.includes(i);
            const active = sel === i;
            return (
              <g key={s.title} onClick={(e) => choose(i, e as unknown as MouseEvent)} style={{ cursor: 'pointer' }} role="button" aria-label={`مرحلهٔ ${i + 1}: ${s.title}`}>
                {state.stage === i && <circle cx={p.x} cy={p.y} r="32" fill="none" stroke="#34d399" strokeWidth="2.5" strokeDasharray="3 4" />}
                <circle cx={p.x} cy={p.y} r={active ? 27 : 24} fill={visited ? 'url(#cycGold)' : kids ? '#ffffff' : '#1a2147'} stroke={active ? '#fbbf24' : visited ? '#f59e0b' : kids ? '#bae6fd' : 'rgba(255,255,255,.25)'} strokeWidth={active ? 3.5 : 2} />
                <text x={p.x} y={p.y + 7} textAnchor="middle" fontSize="21">{s.icon}</text>
                <circle cx={p.x + 17} cy={p.y - 17} r="9" fill={kids ? '#334155' : '#fbbf24'} />
                <text x={p.x + 17} y={p.y - 13} textAnchor="middle" fontSize="10" fontWeight="800" fill={kids ? '#fff' : '#1e293b'}>{faNum(i + 1)}</text>
              </g>
            );
          })}
          <defs>
            <radialGradient id="cycGold" cx="35%" cy="30%" r="80%">
              <stop offset="0" stopColor="#fff3b0" />
              <stop offset="1" stopColor="#f5b83d" />
            </radialGradient>
          </defs>
        </svg>
      </div>

      <div className={cn('space-y-3 rounded-3xl border p-4 animate-pop', kids ? 'border-sky-200 bg-white' : 'border-white/10 bg-white/[0.04]')} key={sel}>
        <div className="flex items-center gap-3">
          <span className="text-3xl">{st.icon}</span>
          <div>
            <div className={cn('text-[11px] font-bold', muted)}>مرحلهٔ {faNum(sel + 1)} از {faNum(STAGES.length)}</div>
            <h4 className="text-lg font-black">{st.title}</h4>
          </div>
        </div>
        <p className="text-[15px] leading-8">{st.text}</p>
        <Arabic ar={st.ar} refText={st.ref} kids={kids} />
        <div className={cn('rounded-2xl p-3 text-sm leading-7', kids ? 'bg-amber-50 text-amber-900' : 'bg-amber-300/10 text-amber-100')}>
          <b>تمرین پیشنهادی: </b>
          {st.todo}
        </div>
        <Btn variant={state.stage === sel ? (kids ? 'kids' : 'green') : kids ? 'kidsGhost' : 'ghost'} className="w-full" onClick={() => setState({ ...state, stage: state.stage === sel ? -1 : sel })}>
          {state.stage === sel ? '✓ الان در این مرحله‌ام' : 'من الان در این مرحله‌ام'}
        </Btn>
      </div>

      {state.done && (
        <div className="space-y-2 animate-pop">
          <div className="text-center text-sm font-black text-emerald-500">🎉 هر هفت مرحله را دیدی؛ دعای پایانی چرخه:</div>
          <Note kids={kids} src="کتابچهٔ چرخهٔ تحقق خواسته">{CYCLE_PRAYER}</Note>
        </div>
      )}
    </div>
  );
}

// ═════════════════ ۴) دوازده مانع ذهنی و جایگزین‌هایشان ═════════════════
const OBSTACLES = [
  { n: 'وعده‌های شیطان', thought: 'منابع محدودند و آینده خطرناک است.', fix: 'وعدهٔ فضل خدا را جای وعدهٔ فقر بنشان.', ar: 'الشَّيْطَانُ يَعِدُكُمُ الْفَقْرَ وَيَأْمُرُكُم بِالْفَحْشَاءِ ۖ وَاللَّهُ يَعِدُكُم مَّغْفِرَةً مِّنْهُ وَفَضْلًا', ref: 'بقره ۲۶۸' },
  { n: 'ماندن در فرکانس گناه', thought: 'من دیگر پاک نمی‌شوم.', fix: 'توبه کن و رها کن؛ از رحمت خدا ناامید نشو.', ar: 'لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ', ref: 'زمر ۵۳' },
  { n: 'غرور', thought: 'این نعمت از خودم است.', fix: 'بگو «ماشاءالله لا قوة إلا بالله»؛ نعمت از خداست.', ar: 'مَا شَاءَ اللَّهُ لَا قُوَّةَ إِلَّا بِاللَّهِ', ref: 'کهف ۳۹' },
  { n: 'طلبکار بودن از آدم‌ها', thought: 'دیگران به من بدهکارند.', fix: 'ببخش و درگذر؛ پاداشم با خداست.', ar: 'فَاعْفُ عَنْهُمْ وَاصْفَحْ ۚ إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ', ref: 'مائده ۱۳' },
  { n: 'مشغله‌های ذهنی و فیزیکی', thought: 'فرصت کافی ندارم.', fix: 'وقت خلوتی برای ذکر و توجه کنار بگذار.', ar: 'أَلْهَاكُمُ التَّكَاثُرُ', ref: 'تکاثر ۱' },
  { n: 'بدهی دانستن نعمت', thought: 'خوشی باید پس داده شود.', fix: 'نعمت فضل است نه وام؛ هدیه را با آرامش بپذیر.', ar: 'هَٰذَا عَطَاؤُنَا فَامْنُنْ أَوْ أَمْسِكْ بِغَيْرِ حِسَابٍ', ref: 'ص ۳۹' },
  { n: 'کمال‌گرایی', thought: 'تا کامل نشود، ارزش ندارد.', fix: 'ناقص شروع کن و پله‌پله اصلاح کن.', ar: 'وَخُلِقَ الْإِنسَانُ ضَعِيفًا', ref: 'نساء ۲۸' },
  { n: 'ندیدن دستان خدا', thought: 'کمک‌هایی که می‌رسند تصادفی‌اند.', fix: 'هم از دست شکر کن، هم از صاحبِ دست.', ar: 'فَبَعَثَ اللَّهُ غُرَابًا يَبْحَثُ فِي الْأَرْضِ', ref: 'مائده ۳۱' },
  { n: 'گفتار نازیبا', thought: 'گفتن فقط بیان است و اثری ندارد.', fix: 'قول سدید بگو؛ گفتار نیک، پندار نیک، کردار نیک.', ar: 'وَقُولُوا قَوْلًا سَدِيدًا يُصْلِحْ لَكُمْ أَعْمَالَكُمْ', ref: 'احزاب ۷۰ و ۷۱' },
  { n: 'فراموشکاری', thought: 'ارزش‌ها همیشه در یادم می‌مانند.', fix: 'یادآوری و دفتر شکر داشته باش.', ar: 'فَإِنِّي نَسِيتُ الْحُوتَ', ref: 'کهف ۶۳' },
  { n: 'نبودِ احساس شکر', thought: 'من با نعمت‌ها فاصله دارم.', fix: 'بنویس، ببین، نسبت بده.', ar: 'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ', ref: 'ابراهیم ۷' },
  { n: 'نبودِ احساس لیاقت', thought: 'من سزاوار نیستم.', fix: 'کرامتت را از خدا بدان؛ عزت نفس از اوست.', ar: 'وَلَقَدْ كَرَّمْنَا بَنِي آدَمَ', ref: 'اسراء ۷۰' },
];

export function ObstacleGame({ kids, onReward, onAnswer, onBoost }: PracticeProps) {
  const [order, setOrder] = useState(() => shuffle(OBSTACLES.map((_, i) => i)));
  const [pos, setPos] = useState(0);
  const [wrong, setWrong] = useState<number[]>([]);
  const [solved, setSolved] = useState(false);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const idx = order[pos];
  const cur = OBSTACLES[idx];
  const options = useMemo(() => shuffle([idx, ...shuffle(OBSTACLES.map((_, i) => i).filter((i) => i !== idx)).slice(0, 2)]), [idx]);
  const muted = kids ? 'text-slate-500' : 'text-slate-400';

  const pick = (i: number, e: MouseEvent) => {
    if (solved || wrong.includes(i)) return;
    if (i === idx) {
      setSolved(true);
      if (!wrong.length) {
        setScore((s) => s + 1);
        onAnswer?.(true);
        onReward(3, pt(e));
      }
    } else setWrong((w) => [...w, i]);
  };

  const next = (e: MouseEvent) => {
    if (pos + 1 >= OBSTACLES.length) {
      setOver(true);
      onBoost(3);
      onReward(10, pt(e));
      return;
    }
    setPos(pos + 1);
    setWrong([]);
    setSolved(false);
  };

  const restart = () => {
    setOrder(shuffle(OBSTACLES.map((_, i) => i)));
    setPos(0);
    setWrong([]);
    setSolved(false);
    setScore(0);
    setOver(false);
  };

  return (
    <div className="space-y-4">
      <div className={cn('rounded-3xl p-4 text-center', kids ? 'bg-gradient-to-l from-rose-300 to-orange-300 text-white' : 'bg-gradient-to-l from-rose-400/20 to-amber-300/10')}>
        <div className="text-xl font-black">دوازده مانع ذهنی</div>
        <div className="mt-1 text-xs opacity-85">ذهن چه می‌گوید و ایمان چه جایگزینی دارد؟</div>
        <div className="mt-2"><Chip kids={kids}>کتابچهٔ چرخهٔ تحقق خواسته — جدول دوازده مانع</Chip></div>
      </div>

      {over ? (
        <div className={cn('space-y-3 rounded-3xl border p-6 text-center animate-pop', kids ? 'border-sky-200 bg-white' : 'border-white/10 bg-white/[0.04]')}>
          <div className="text-6xl">🌟</div>
          <div className="text-2xl font-black">هر دوازده مانع را شناختی</div>
          <p className={cn('text-sm', muted)}>پاسخ درست در نخستین تلاش: {faNum(score)} از {faNum(OBSTACLES.length)}</p>
          <Btn variant={kids ? 'kids' : 'gold'} className="w-full py-3" onClick={restart}>
            دوباره بازی کن
          </Btn>
        </div>
      ) : (
        <div className="space-y-3" key={pos}>
          <div className="flex items-center justify-between text-xs">
            <span className={cn('rounded-full px-3 py-1 font-bold', kids ? 'bg-orange-100 text-orange-700' : 'bg-amber-300/10 text-amber-200')}>مانع: {cur.n}</span>
            <span className={muted}>{faNum(pos + 1)} / {faNum(OBSTACLES.length)}</span>
          </div>
          <div className={cn('rounded-3xl border p-5 text-center animate-pop', kids ? 'border-rose-200 bg-rose-50 text-rose-900' : 'border-rose-300/20 bg-rose-500/10 text-rose-100')}>
            <div className="text-3xl">💭</div>
            <div className="mt-1 text-xs font-bold opacity-70">ذهن می‌گوید:</div>
            <p className="mt-1 text-lg font-black leading-9">«{cur.thought}»</p>
          </div>
          <div className={cn('text-center text-sm font-bold', muted)}>جایگزین درست ایمان کدام است؟</div>
          <div className="grid gap-2">
            {options.map((i) => {
              const bad = wrong.includes(i);
              const good = solved && i === idx;
              return (
                <button
                  key={i}
                  disabled={solved || bad}
                  onClick={(e) => pick(i, e)}
                  className={cn('rounded-xl border-2 px-4 py-3 text-right text-[15px] leading-7 transition active:scale-[0.98]', good ? 'border-emerald-400 bg-emerald-400/15' : bad ? 'border-rose-400/60 bg-rose-500/10 line-through opacity-50' : kids ? 'border-sky-200 bg-white hover:border-orange-300 hover:bg-orange-50' : 'border-white/10 bg-white/[0.03] hover:border-amber-300/50 hover:bg-amber-300/5')}
                >
                  {OBSTACLES[i].fix}
                </button>
              );
            })}
          </div>
          {wrong.length > 0 && !solved && <div className={cn('rounded-2xl p-3 text-center text-sm animate-shake', kids ? 'bg-rose-50 text-rose-800' : 'bg-rose-500/10 text-rose-100')}>لا جناح علیکم؛ دوباره امتحان کن 🌱</div>}
          {solved && (
            <div className="space-y-3 animate-pop">
              <Arabic ar={cur.ar} refText={cur.ref} kids={kids} />
              <Btn variant={kids ? 'kids' : 'gold'} className="w-full py-3" onClick={next}>
                {pos + 1 >= OBSTACLES.length ? 'پایان' : 'مانع بعدی'}
              </Btn>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
