import { useEffect, useMemo, useRef, useState, type MouseEvent, type ReactNode } from 'react';
import { Check, ChevronLeft, ChevronRight, Copy, Printer, Search, Share2 } from 'lucide-react';
import { ALL_ENTRIES, MAIN_REALMS, REALMS, TOTAL_ITEMS, entriesOf, findGroup, findRealm, itemKey, norm, type AGroup, type ARealm, type Entry } from '../data/abundance';
import type { Verse } from '../data/abundance/kit';
import { useSite } from '../lib/SiteContext';
import { faNum } from '../lib/storage';
import type { Point } from '../lib/coins';
import { cn } from '../utils/cn';
import { Art } from './Art';
import { AdultArt } from './AdultArt';
import { QrCode } from './QrCode';
import skyHero from '../../public/images/adult/sky.jpg';
import earthHero from '../../public/images/adult/earth.jpg';
import seaHero from '../../public/images/adult/sea.jpg';
import bodyHero from '../../public/images/adult/body.jpg';
import madeHero from '../../public/images/adult/made.jpg';
import { Btn, Modal, QuoteCard } from './ui';

interface Props {
  kids?: boolean;
  collected: string[];
  onCollect: (key: string) => void;
  onReward: (amount: number, origin?: Point) => void;
  deepLink?: { realm?: string; group?: string } | null;
  onDeepLinkUsed?: () => void;
}

const linkFor = (realm: ARealm, group: AGroup) => `${location.origin}${location.pathname}#/abundance/${realm.id}/${group.id}`;

// ————— قطعه‌های کوچک —————
const ADULT_HERO: Record<string, string> = { sky: skyHero, earth: earthHero, sea: seaHero, body: bodyHero, made: madeHero };

function ArtTile({ a, size, className, kids }: { a: string; size: number; className?: string; kids?: boolean }) {
  if (!kids) {
    return <AdultArt a={a} size={size + 18} className={cn('shrink-0 overflow-hidden rounded-2xl shadow-lg ring-1 ring-black/20', className)} />;
  }
  return (
    <div className={cn('grid shrink-0 place-items-center rounded-2xl bg-gradient-to-b from-white to-slate-200 shadow-inner', className)} style={{ width: size + 14, height: size + 14 }}>
      <Art a={a} size={size} />
    </div>
  );
}

function Bar({ value, total, light }: { value: number; total: number; light?: boolean }) {
  return (
    <div className={cn('h-1.5 overflow-hidden rounded-full', light ? 'bg-white/25' : 'bg-black/10')}>
      <div className={cn('h-full rounded-full transition-all duration-500', light ? 'bg-white' : 'bg-gradient-to-l from-amber-300 to-emerald-400')} style={{ width: `${total ? Math.min(100, (value / total) * 100) : 0}%` }} />
    </div>
  );
}

function VerseCard({ v, kids }: { v: Verse; kids?: boolean }) {
  return (
    <div className={cn('rounded-2xl border px-4 py-3 text-center', kids ? 'border-emerald-300 bg-emerald-50' : 'border-amber-300/30 bg-gradient-to-b from-amber-200/10 to-transparent')}>
      <p dir="rtl" className={cn('quran text-xl', kids ? 'text-emerald-800' : 'text-amber-100')}>
        {v.ar}
      </p>
      <span className={cn('mt-1 inline-flex rounded-full px-2 py-0.5 text-[10px] font-medium', kids ? 'bg-amber-100 text-amber-800' : 'bg-white/5 text-amber-200/70')}>📖 {v.ref}</span>
    </div>
  );
}

// نشان QR کوچک با خط اسکن
function MiniQr({ value, size = 34, scan = false }: { value: string; size?: number; scan?: boolean }) {
  return (
    <span className="relative inline-block overflow-hidden rounded-md bg-white p-[3px] shadow ring-1 ring-black/10">
      <QrCode value={value} size={size} quiet={0} rounded={false} />
      {scan && <span className="qr-scan-line pointer-events-none absolute inset-x-0 top-0 h-[3px] bg-emerald-400 shadow-[0_0_8px_2px_#34d399]" />}
    </span>
  );
}

export function AbundanceExplorer({ kids, collected, onCollect, onReward, deepLink, onDeepLinkUsed }: Props) {
  const { THANK_EACH, BLESSING_INTRO, BLESSING_MAN_INTRO, BLESSING_END, THANKS_WORD } = useSite().content.library;
  const [realmId, setRealmId] = useState<string | null>(() => findRealm(deepLink?.realm)?.id ?? null);
  const [groupId, setGroupId] = useState<string | null>(() => findGroup(findRealm(deepLink?.realm), deepLink?.group)?.id ?? null);
  const [view, setView] = useState<'grid' | 'all'>('grid');
  const [query, setQuery] = useState('');
  const [sheet, setSheet] = useState<{ list: Entry[]; i: number } | null>(null);
  const [qr, setQr] = useState<{ realm: ARealm; group: AGroup } | null>(null);
  const [floats, setFloats] = useState<{ id: number; x: number; y: number }[]>([]);
  const [banner, setBanner] = useState<string | null>(null);
  const guard = useRef(new Map<string, number>());

  useEffect(() => {
    if (deepLink) onDeepLinkUsed?.();
    // فقط یک بار هنگام ورود از پیوند QR
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (!banner) return;
    const timer = setTimeout(() => setBanner(null), 3800);
    return () => clearTimeout(timer);
  }, [banner]);

  const seen = useMemo(() => new Set(collected), [collected]);
  const stats = useMemo(() => {
    const realms = new Map<string, { seen: number; total: number }>();
    const groups = new Map<string, { seen: number; total: number }>();
    let all = 0;
    for (const e of ALL_ENTRIES) {
      const got = seen.has(e.key) ? 1 : 0;
      all += got;
      const r = realms.get(e.realm.id) || { seen: 0, total: 0 };
      r.seen += got;
      r.total += 1;
      realms.set(e.realm.id, r);
      const g = groups.get(e.group.id) || { seen: 0, total: 0 };
      g.seen += got;
      g.total += 1;
      groups.set(e.group.id, g);
    }
    return { realms, groups, all };
  }, [seen]);

  const realm = findRealm(realmId);
  const group = findGroup(realm, groupId);
  const nq = norm(query);
  const results = useMemo(() => (nq.length < 2 ? [] : ALL_ENTRIES.filter((e) => norm(`${e.item[1]} ${e.item[2]} ${e.group.name}`).includes(nq)).slice(0, 60)), [nq]);

  const go = (r: string | null, g: string | null = null, v: 'grid' | 'all' = 'grid') => {
    setRealmId(r);
    setGroupId(g);
    setView(v);
    setQuery('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // شکرِ یک یا چند نعمت: ثبت، سکه، و جشن تکمیل گروه/بخش
  const thank = (entries: Entry[], e?: MouseEvent) => {
    const now = Date.now();
    const fresh = entries.filter((x) => !seen.has(x.key) && now - (guard.current.get(x.key) || 0) > 1500);
    if (!fresh.length) return;
    fresh.forEach((x) => {
      guard.current.set(x.key, now);
      onCollect(x.key);
    });
    const after = (k: string) => seen.has(k) || guard.current.has(k);
    let coins = fresh.length;
    const notes: string[] = [];
    const doneGroups = new Map<string, Entry>();
    const doneRealms = new Map<string, Entry>();
    fresh.forEach((x) => {
      doneGroups.set(x.group.id, x);
      doneRealms.set(x.realm.id, x);
    });
    doneGroups.forEach((x) => {
      if (x.group.items.every((it) => after(itemKey(x.group, it)))) {
        coins += 10;
        notes.push(`ماشاءالله! همهٔ «${x.group.name}» را دیدی و شکر کردی`);
      }
    });
    doneRealms.forEach((x) => {
      if (x.realm.groups.every((g) => g.items.every((it) => after(itemKey(g, it))))) {
        coins += 30;
        notes.push(`بخش «${x.realm.name}» کامل شد؛ الحمدلله رب العالمین`);
      }
    });
    const origin = e ? { x: e.clientX, y: e.clientY } : undefined;
    onReward(coins, origin);
    if (e) {
      const id = now + Math.random();
      setFloats((f) => [...f, { id, x: e.clientX, y: e.clientY }]);
      setTimeout(() => setFloats((f) => f.filter((x) => x.id !== id)), 1300);
    }
    if (notes.length) setBanner(notes.join(' · '));
  };

  const paint = (a: string, size: number) => (kids ? <Art a={a} size={size} /> : <AdultArt a={a} size={size} />);
  const card = kids ? 'border-sky-200 bg-white text-slate-700 shadow-sm' : 'border-white/10 bg-white/5 text-slate-100';
  const gotCard = 'border-amber-300 bg-gradient-to-b from-amber-100 to-yellow-200 text-slate-800';
  const muted = kids ? 'text-slate-500' : 'text-slate-400';

  // ————— کارت‌های نعمت —————
  const openSheet = (list: Entry[], i: number) => setSheet({ list, i });

  const gridItem = (list: Entry[], i: number) => {
    const x = list[i];
    const got = seen.has(x.key);
    return (
      <button key={x.key} onClick={() => openSheet(list, i)} className={cn('ab-rise relative flex flex-col items-center gap-1.5 rounded-2xl border-2 p-2 transition active:scale-95', got ? gotCard : card)} style={{ animationDelay: `${Math.min(i, 12) * 28}ms` }}>
        <ArtTile a={x.item[0]} size={54} kids={kids} />
        <span className="text-[11px] font-bold leading-4">{x.item[1]}</span>
        {got && <span className="absolute -left-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-emerald-500 text-white shadow"><Check size={12} strokeWidth={3} /></span>}
      </button>
    );
  };

  const rowItem = (list: Entry[], i: number, crumb = false) => {
    const x = list[i];
    const got = seen.has(x.key);
    return (
      <div key={x.key} className={cn('ab-rise flex gap-3 rounded-2xl border-2 p-3', got ? gotCard : card)} style={{ animationDelay: `${Math.min(i, 10) * 35}ms` }}>
        <button onClick={() => openSheet(list, i)} aria-label={`بزرگ‌نمایی ${x.item[1]}`}>
          <ArtTile a={x.item[0]} size={66} kids={kids} />
        </button>
        <div className="min-w-0 flex-1">
          {crumb && <div className="text-[10px] opacity-60">{x.realm.name} › {x.group.name}</div>}
          <div className="font-black">{x.item[1]}</div>
          <p className="mt-0.5 text-[13px] leading-6 opacity-85">{x.item[2]}</p>
          <button onClick={(e) => thank([x], e)} disabled={got} className={cn('mt-1.5 rounded-full px-3 py-1 text-[11px] font-black transition active:scale-95', got ? 'bg-emerald-500/90 text-white' : kids ? 'bg-orange-400 text-white' : 'bg-amber-300 text-slate-900')}>
            {got ? '✓ شکر شد' : '🤲 الحمدلله'}
          </button>
        </div>
      </div>
    );
  };

  // ————— صفحهٔ اصلی: بخش‌ها —————
  const home = (
    <div className="space-y-4">
      <VerseCard v={{ ar: 'وَإِن تَعُدُّوا نِعْمَتَ اللَّهِ لَا تُحْصُوهَا', ref: 'ابراهیم ۳۴' }} kids={kids} />
      <QuoteCard q={THANK_EACH} kids={kids} />
      <QuoteCard q={BLESSING_INTRO} kids={kids} />

      <div className={cn('rounded-2xl px-4 py-3', kids ? 'bg-amber-100 text-amber-900' : 'bg-amber-300/10 text-amber-100')}>
        <div className="flex items-center justify-between text-sm font-black">
          <span>🤲 نعمت‌هایی که دیدی و شکر کردی</span>
          <span>
            {faNum(stats.all)} / {faNum(TOTAL_ITEMS)}
          </span>
        </div>
        <div className="mt-2">
          <Bar value={stats.all} total={TOTAL_ITEMS} />
        </div>
        <div className="mt-1.5 text-[11px] opacity-75">هر نعمت تازه ۱ سکه، تکمیل هر گروه ۱۰ سکه و تکمیل هر بخش ۳۰ سکه</div>
      </div>

      <label className="relative block">
        <Search size={17} className={cn('pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2', muted)} />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جستجو در همهٔ نعمت‌ها… (مثلاً مرمر، کبوتر، تره)" className={cn('w-full rounded-2xl border py-3 pl-4 pr-10 text-sm outline-none', kids ? 'border-sky-200 bg-white text-slate-800 focus:border-orange-300' : 'border-white/10 bg-black/20 text-white placeholder:text-slate-500 focus:border-amber-300/60')} />
      </label>

      {nq.length >= 2 ? (
        <div className="space-y-2">
          <div className={cn('text-xs font-bold', muted)}>{results.length ? `${faNum(results.length)} نتیجه` : 'نعمتی با این نام پیدا نشد؛ یک واژهٔ دیگر را امتحان کن.'}</div>
          {results.map((_, i) => rowItem(results, i, true))}
        </div>
      ) : (
        <>
          {!kids && <div className="text-center text-[11px] font-bold text-amber-200/80">نسخهٔ بزرگسالان — نگاره‌های گرافیکی، با نور و صحنه</div>}
          <div className="grid grid-cols-3 gap-2">
            {REALMS.slice(0, MAIN_REALMS).map((r) => {
              const s = stats.realms.get(r.id)!;
              const photo = !kids && ADULT_HERO[r.id];
              return (
                <button key={r.id} onClick={() => go(r.id)} className={cn('relative overflow-hidden text-center text-white shadow-lg transition active:scale-95', photo ? 'min-h-40 rounded-3xl' : 'rounded-3xl p-3 pb-3.5')} style={photo ? { backgroundImage: `linear-gradient(180deg, rgba(0,0,0,.05) 10%, rgba(0,0,0,.78)), url(${photo})`, backgroundSize: 'cover', backgroundPosition: 'center' } : { background: `linear-gradient(160deg, ${r.from}, ${r.to})` }}>
                  {!photo && <span className="pointer-events-none absolute -left-6 -top-6 h-20 w-20 rounded-full bg-white/15" />}
                  {!photo && <span className="pointer-events-none absolute -bottom-8 -right-6 h-24 w-24 rounded-full bg-black/10" />}
                  <div className={cn('relative', photo ? 'flex h-full flex-col justify-end p-2.5 text-right' : '')}>
                    {!photo && <div className="flex justify-center pt-1 drop-shadow-lg">{paint(r.icon, 46)}</div>}
                    <div className={cn('font-black', photo ? 'text-sm' : 'mt-1 text-base')}>{r.name}</div>
                    <div className="text-[10px] font-bold opacity-85">
                      {faNum(r.groups.length)} بخش · {faNum(s.total)} نعمت
                    </div>
                    <div className="mt-1.5"><Bar value={s.seen} total={s.total} light /></div>
                    <div className="mt-1 text-[10px] font-black">{faNum(s.seen)} / {faNum(s.total)}</div>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {REALMS.slice(MAIN_REALMS).map((r) => {
              const s = stats.realms.get(r.id)!;
              const photo = !kids && ADULT_HERO[r.id];
              return (
                <button key={r.id} onClick={() => go(r.id)} className="relative flex min-h-24 items-end overflow-hidden rounded-3xl p-3 text-right text-white shadow-lg transition active:scale-95" style={photo ? { backgroundImage: `linear-gradient(180deg, rgba(0,0,0,.05), rgba(0,0,0,.75)), url(${photo})`, backgroundSize: 'cover', backgroundPosition: 'center' } : { background: `linear-gradient(160deg, ${r.from}, ${r.to})` }}>
                  {!photo && <span className="pointer-events-none absolute -left-5 -top-5 h-16 w-16 rounded-full bg-white/15" />}
                  {!photo && <div className="relative drop-shadow-lg">{paint(r.icon, 38)}</div>}
                  <div className="relative min-w-0 flex-1">
                    <div className="text-sm font-black leading-5">{r.name}</div>
                    <div className="text-[10px] font-bold opacity-85">{faNum(s.seen)} / {faNum(s.total)}</div>
                    <div className="mt-1"><Bar value={s.seen} total={s.total} light /></div>
                  </div>
                </button>
              );
            })}
          </div>
          <QuoteCard q={BLESSING_MAN_INTRO} kids={kids} />
          {stats.all === TOTAL_ITEMS && <QuoteCard q={BLESSING_END} kids={kids} big />}
        </>
      )}
    </div>
  );

  // ————— نان‌ریز (مسیر) —————
  const crumbs: ReactNode = realm && (
    <div className={cn('flex flex-wrap items-center gap-1 text-xs font-bold', muted)}>
      <button onClick={() => go(null)} className="rounded-full px-2 py-1 hover:underline">همهٔ بخش‌ها</button>
      <ChevronLeft size={13} />
      <button onClick={() => go(realm.id)} className={cn('rounded-full px-2 py-1', !group && (kids ? 'bg-orange-100 text-orange-700' : 'bg-amber-300/15 text-amber-200'))}>{realm.name}</button>
      {group && (
        <>
          <ChevronLeft size={13} />
          <span className={cn('rounded-full px-2 py-1', kids ? 'bg-orange-100 text-orange-700' : 'bg-amber-300/15 text-amber-200')}>{group.name}</span>
        </>
      )}
    </div>
  );

  // ————— درون یک بخش: گروه‌ها —————
  const realmView = realm && !group && (
    <div className="space-y-4">
      {crumbs}
      <div className="relative overflow-hidden rounded-3xl p-5 text-white shadow-lg" style={!kids && ADULT_HERO[realm.id] ? { backgroundImage: `linear-gradient(180deg, rgba(0,0,0,.25), rgba(0,0,0,.72)), url(${ADULT_HERO[realm.id]})`, backgroundSize: 'cover', backgroundPosition: 'center' } : { background: `linear-gradient(160deg, ${realm.from}, ${realm.to})` }}>
        <span className="pointer-events-none absolute -left-8 -top-10 h-32 w-32 rounded-full bg-white/15" />
        <div className="relative flex items-center gap-4">
          <div className="drop-shadow-lg">{paint(realm.icon, 58)}</div>
          <div className="min-w-0 flex-1">
            <h3 className="text-2xl font-black">{realm.name}</h3>
            <p className="mt-0.5 text-[13px] leading-6 opacity-90">{realm.tagline}</p>
          </div>
        </div>
        <div className="relative mt-3">
          <Bar value={stats.realms.get(realm.id)!.seen} total={stats.realms.get(realm.id)!.total} light />
          <div className="mt-1 text-[11px] font-bold opacity-90">{faNum(stats.realms.get(realm.id)!.seen)} از {faNum(stats.realms.get(realm.id)!.total)} نعمت دیده شد</div>
        </div>
      </div>
      {realm.verse && <VerseCard v={realm.verse} kids={kids} />}
      <div className={cn('text-xs font-bold', muted)}>یک بخش را باز کن؛ با زدن روی نشان QR همهٔ تصویرها و مشخصات یک‌جا باز می‌شود.</div>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        {realm.groups.map((g, i) => {
          const s = stats.groups.get(g.id)!;
          const done = s.seen === s.total;
          return (
            <div key={g.id} className="ab-rise relative" style={{ animationDelay: `${Math.min(i, 10) * 35}ms` }}>
              <button onClick={() => go(realm.id, g.id)} className={cn('flex h-full w-full flex-col items-center gap-1 rounded-3xl border-2 p-3 pt-4 text-center transition active:scale-95', done ? gotCard : card)}>
                {paint(g.icon, 40)}
                <span className="mt-1 text-sm font-black leading-5">{g.name}</span>
                <span className="text-[10px] font-bold opacity-70">{faNum(s.seen)} / {faNum(s.total)} نعمت</span>
                <span className="w-full"><Bar value={s.seen} total={s.total} /></span>
              </button>
              <button onClick={() => go(realm.id, g.id, 'all')} className="absolute left-2 top-2 transition active:scale-90" title="نمایش همهٔ تصاویر و مشخصات" aria-label={`نمایش همهٔ تصاویر و مشخصات ${g.name}`}>
                <MiniQr value={linkFor(realm, g)} size={26} />
              </button>
              {done && <span className="absolute right-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-emerald-500 text-white shadow"><Check size={12} strokeWidth={3} /></span>}
            </div>
          );
        })}
      </div>
    </div>
  );

  // ————— درون یک گروه: نعمت‌ها —————
  const list = realm && group ? entriesOf(realm, group) : [];
  const gs = group ? stats.groups.get(group.id)! : null;
  const groupView = realm && group && gs && (
    <div className="space-y-4">
      {crumbs}
      <div className={cn('rounded-3xl border p-4', card)}>
        <div className="flex items-start gap-3">
          <ArtTile a={group.icon} size={44} kids={kids} />
          <div className="min-w-0 flex-1">
            <h3 className="text-lg font-black">{group.name}</h3>
            <p className="mt-0.5 text-[13px] leading-6 opacity-80">{group.blurb}</p>
          </div>
          <button onClick={() => setQr({ realm, group })} className="flex shrink-0 flex-col items-center gap-0.5 transition active:scale-90" aria-label="نمایش کد QR این بخش" title="کد QR این بخش">
            <MiniQr value={linkFor(realm, group)} size={46} scan />
            <span className="text-[9px] font-black opacity-70">QR</span>
          </button>
        </div>
        <div className="mt-3">
          <Bar value={gs.seen} total={gs.total} />
          <div className="mt-1 flex justify-between text-[11px] font-bold opacity-75">
            <span>{faNum(gs.seen)} از {faNum(gs.total)} دیده شد</span>
            <span>{gs.seen === gs.total ? '✨ کامل شد' : `${faNum(gs.total - gs.seen)} نعمت مانده`}</span>
          </div>
        </div>
      </div>
      {group.verse && <VerseCard v={group.verse} kids={kids} />}

      <div className={cn('grid grid-cols-2 gap-1 rounded-2xl p-1', kids ? 'bg-white shadow-sm' : 'bg-white/5')}>
        {(
          [
            ['grid', '🖼️ تصاویر'],
            ['all', '📋 همه با مشخصات'],
          ] as const
        ).map(([k, label]) => (
          <button key={k} onClick={() => setView(k)} className={cn('rounded-xl py-2.5 text-xs font-black transition', view === k ? (kids ? 'bg-orange-400 text-white' : 'bg-amber-300 text-slate-900') : '')}>
            {label}
          </button>
        ))}
      </div>

      {view === 'grid' ? <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">{list.map((_, i) => gridItem(list, i))}</div> : <div className="space-y-2">{list.map((_, i) => rowItem(list, i))}</div>}

      <Btn variant={kids ? 'kids' : 'gold'} className="w-full py-3.5 text-base" disabled={gs.seen === gs.total} onClick={(e) => thank(list, e)}>
        {gs.seen === gs.total ? '✓ همهٔ این نعمت‌ها را شکر کردی' : '🤲 الحمدلله بر همهٔ این نعمت‌ها'}
      </Btn>
      <button onClick={() => go(realm.id)} className={cn('mx-auto flex items-center gap-1 text-xs font-bold', muted)}>
        <ChevronRight size={14} />
        بازگشت به بخش‌های «{realm.name}»
      </button>
    </div>
  );

  // ————— برگهٔ جزئیات یک نعمت —————
  const cur = sheet ? sheet.list[sheet.i] : null;
  const curGot = cur ? seen.has(cur.key) : false;
  const move = (d: number) => sheet && setSheet({ list: sheet.list, i: (sheet.i + d + sheet.list.length) % sheet.list.length });

  return (
    <div className="space-y-4">
      {realm ? group ? groupView : realmView : home}

      <Modal open={!!cur} onClose={() => setSheet(null)} title={cur ? `${cur.realm.name} › ${cur.group.name}` : ''} kids={kids}>
        {cur && (
          <div className="space-y-4 text-center">
            <div className="flex justify-center">
              <div className="grid place-items-center rounded-[2rem] bg-gradient-to-b from-white to-slate-200 p-4 shadow-inner animate-pop" key={cur.key}>
                {paint(cur.item[0], kids ? 132 : 168)}
              </div>
            </div>
            <h4 className="text-2xl font-black">{cur.item[1]}</h4>
            <p className={cn('rounded-2xl p-3 text-[15px] leading-8', kids ? 'bg-sky-50 text-slate-700' : 'bg-white/5 text-slate-200')}>{cur.item[2]}</p>
            {cur.group.verse && <VerseCard v={cur.group.verse} kids={kids} />}
            <div className={cn('text-[11px] leading-6', muted)}>ببین ← به خدا نسبت بده ← شکر کن</div>
            <Btn variant={kids ? 'kids' : 'gold'} className="w-full py-3.5 text-base" disabled={curGot} onClick={(e) => thank([cur], e)}>
              {curGot ? '✓ شکر شد؛ الحمدلله' : '🤲 این نعمت از خداست؛ الحمدلله'}
            </Btn>
            {sheet && sheet.list.length > 1 && (
              <div className="grid grid-cols-2 gap-2">
                <Btn variant={kids ? 'kidsGhost' : 'ghost'} onClick={() => move(1)}>
                  <ChevronRight size={16} /> قبلی
                </Btn>
                <Btn variant={kids ? 'kidsGhost' : 'ghost'} onClick={() => move(-1)}>
                  بعدی <ChevronLeft size={16} />
                </Btn>
              </div>
            )}
          </div>
        )}
      </Modal>

      {qr && <QrDialog realm={qr.realm} group={qr.group} kids={kids} onClose={() => setQr(null)} />}

      {banner && (
        <div className="pointer-events-none fixed inset-x-0 top-24 z-[80] flex justify-center px-4">
          <div className="max-w-md rounded-2xl border border-amber-300/40 bg-gradient-to-l from-amber-300 to-yellow-400 px-4 py-3 text-center text-sm font-black text-slate-900 shadow-2xl animate-pop">🎉 {banner}</div>
        </div>
      )}

      {floats.map((f) => (
        <span key={f.id} className="quran pointer-events-none fixed z-[70] -translate-x-1/2 text-lg font-bold text-emerald-500 animate-rise" style={{ left: f.x, top: f.y - 20 }}>
          {THANKS_WORD}
        </span>
      ))}
    </div>
  );
}

// ————— پنجرهٔ QR: قابل اسکن، کپی، اشتراک و چاپ —————
function QrDialog({ realm, group, kids, onClose }: { realm: ARealm; group: AGroup; kids?: boolean; onClose: () => void }) {
  const link = linkFor(realm, group);
  const [copied, setCopied] = useState(false);
  const canShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function';
  return (
    <Modal open onClose={onClose} title="کد QR این بخش" kids={kids}>
      <div className="space-y-4">
        <div className="print-area rounded-3xl bg-white p-5 text-center text-slate-900 shadow-inner">
          <div className="text-xs font-bold text-amber-700">گنجینهٔ فراوانی‌های خدا</div>
          <div className="mt-1 text-xl font-black">{realm.name} › {group.name}</div>
          <div className="relative mx-auto mt-3 w-fit overflow-hidden rounded-2xl ring-4 ring-slate-100">
            <QrCode value={link} size={230} quiet={2} />
            <span className="qr-scan-line no-print pointer-events-none absolute inset-x-0 top-0 h-1 bg-emerald-400 shadow-[0_0_12px_3px_#34d399]" />
          </div>
          <p className="mx-auto mt-3 max-w-xs text-[13px] leading-7 text-slate-600">با دوربین گوشی اسکن کن تا مستقیم به همین بخش برسی و همهٔ تصویرها و مشخصات نعمت‌ها را ببینی.</p>
          <div dir="ltr" className="mt-2 break-all rounded-xl bg-slate-100 px-3 py-2 text-[10px] text-slate-500">{link}</div>
        </div>
        <div className="no-print grid grid-cols-3 gap-2">
          <Btn
            variant={kids ? 'kidsGhost' : 'ghost'}
            onClick={() => {
              navigator.clipboard?.writeText(link).then(() => {
                setCopied(true);
                setTimeout(() => setCopied(false), 1800);
              });
            }}
          >
            {copied ? <Check size={15} /> : <Copy size={15} />}
            {copied ? 'کپی شد' : 'کپی پیوند'}
          </Btn>
          <Btn variant={kids ? 'kidsGhost' : 'ghost'} disabled={!canShare} onClick={() => navigator.share?.({ title: `${group.name} — گنجینهٔ فراوانی‌ها`, url: link }).catch(() => undefined)}>
            <Share2 size={15} /> اشتراک
          </Btn>
          <Btn variant={kids ? 'kids' : 'gold'} onClick={() => window.print()}>
            <Printer size={15} /> چاپ پوستر
          </Btn>
        </div>
      </div>
    </Modal>
  );
}
