import { useId, type ReactNode } from 'react';

// ————— تصویرساز نعمت‌ها —————
// اگر مقدار با «~» شروع نشود، همان ایموجی نمایش داده می‌شود.
// در غیر این صورت، یک تصویر برداری ساخته می‌شود: ~نوع:رنگ۱:رنگ۲:ویژگی…
// شکل هر تصویر از روی خود متن ساخته می‌شود؛ پس همیشه ثابت است ولی هر مورد با دیگری فرق دارد.

const f = (n: number) => Math.round(n * 10) / 10;

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function rgb(c: string): [number, number, number] {
  let h = c.replace('#', '');
  if (h.length === 3) h = h.split('').map((x) => x + x).join('');
  const n = parseInt(h, 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

// روشن (مثبت) یا تیره (منفی) کردن رنگ
function shade(c: string, amt: number) {
  const [r, g, b] = rgb(c);
  const target = amt < 0 ? 0 : 255;
  const k = Math.abs(amt);
  const m = (v: number) => Math.round((target - v) * k + v);
  return `rgb(${m(r)},${m(g)},${m(b)})`;
}

type Pt = readonly [number, number];
function blob(R: () => number, cx: number, cy: number, rx: number, ry: number, n = 9, jit = 0.16) {
  const pts: Pt[] = Array.from({ length: n }, (_, i) => {
    const t = (i / n) * Math.PI * 2;
    const k = 1 - jit + R() * jit * 2;
    return [cx + Math.cos(t) * rx * k, cy + Math.sin(t) * ry * k] as const;
  });
  const mid = (a: Pt, b: Pt): Pt => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const start = mid(pts[n - 1], pts[0]);
  let d = `M${f(start[0])} ${f(start[1])}`;
  for (let i = 0; i < n; i++) {
    const p = pts[i];
    const m = mid(p, pts[(i + 1) % n]);
    d += `Q${f(p[0])} ${f(p[1])} ${f(m[0])} ${f(m[1])}`;
  }
  return d + 'Z';
}

interface K {
  p: string[];
  R: () => number;
  id: string;
}

const Shadow = ({ rx = 34 }: { rx?: number }) => <ellipse cx="50" cy="91" rx={rx} ry="4.6" fill="#000" opacity="0.18" />;

// ————— سنگ —————
function Rock({ p, R, id }: K) {
  const [c1 = '#9ca3af', c2 = '#6b7280', pat = 'plain'] = p;
  const dark = shade(c2, -0.3);
  const light = shade(c1, 0.5);
  if (pat === 'crystal') {
    const prisms: [number, number, number, number, number][] = [
      [32, 88, 15, 50, -10],
      [52, 90, 19, 72, 0],
      [71, 88, 14, 44, 10],
    ];
    return (
      <>
        <Shadow />
        {prisms.map(([x, y, w, h, rot], i) => (
          <g key={i} transform={`rotate(${rot} ${x} ${y})`}>
            <path d={`M${x - w / 2} ${y}V${y - h + 12}L${x} ${y - h}L${x + w / 2} ${y - h + 12}V${y}Z`} fill={shade(c1, i === 1 ? 0.12 : -0.04)} />
            <path d={`M${x} ${y}V${y - h}L${x + w / 2} ${y - h + 12}V${y}Z`} fill={shade(c2, -0.12)} opacity="0.8" />
            <path d={`M${x - w / 2} ${y - h + 12}L${x} ${y - h}V${y - h + 16}Z`} fill="#fff" opacity="0.45" />
          </g>
        ))}
      </>
    );
  }
  const d = blob(R, 50, 60, 38, 27, 10, 0.17);
  let over: ReactNode = null;
  if (pat === 'veins') {
    over = [0, 1, 2, 3].map((i) => {
      const y0 = 34 + R() * 42;
      return <path key={i} d={`M4 ${f(y0)}C${f(28 + R() * 12)} ${f(y0 - 20 + R() * 10)} ${f(56 + R() * 12)} ${f(y0 + 16 - R() * 10)} 96 ${f(y0 - 12 + R() * 22)}`} fill="none" stroke={i % 2 ? dark : light} strokeWidth={f(0.7 + R() * 1.5)} opacity="0.7" />;
    });
  } else if (pat === 'speckle') {
    over = Array.from({ length: 36 }, (_, i) => <circle key={i} cx={f(14 + R() * 72)} cy={f(34 + R() * 50)} r={f(0.8 + R() * 1.9)} fill={i % 2 ? dark : light} opacity="0.8" />);
  } else if (pat === 'bands' || pat === 'layers') {
    over = Array.from({ length: 7 }, (_, i) => (
      <path key={i} d={pat === 'bands' ? `M0 ${38 + i * 8}C28 ${32 + i * 8} 60 ${44 + i * 8} 100 ${36 + i * 8}` : `M0 ${40 + i * 8}L100 ${36 + i * 8}`} fill="none" stroke={i % 2 ? dark : light} strokeWidth="4.4" opacity="0.4" />
    ));
  } else if (pat === 'porous') {
    over = Array.from({ length: 20 }, (_, i) => <circle key={i} cx={f(16 + R() * 68)} cy={f(36 + R() * 46)} r={f(1.3 + R() * 3.2)} fill={dark} opacity="0.5" />);
  }
  return (
    <>
      <defs>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={c1} />
          <stop offset="1" stopColor={c2} />
        </linearGradient>
        <clipPath id={`c${id}`}>
          <path d={d} />
        </clipPath>
      </defs>
      <Shadow />
      <path d={d} fill={`url(#g${id})`} />
      <g clipPath={`url(#c${id})`}>
        {over}
        <ellipse cx="38" cy="46" rx="18" ry="8" fill="#fff" opacity="0.17" transform="rotate(-18 38 46)" />
      </g>
      <path d={d} fill="none" stroke={dark} strokeWidth="1.2" opacity="0.55" />
    </>
  );
}

// ————— گوهر —————
function Gem({ p, id }: K) {
  const [c1 = '#7dd3fc', c2 = '#0369a1', cut = 'brilliant'] = p;
  const sparkle = <path d="M34 40l1.8 4.4 4.4 1.8-4.4 1.8L34 52.4l-1.8-4.4-4.4-1.8 4.4-1.8z" fill="#fff" opacity="0.9" transform="translate(2 -6) scale(.9)" />;
  if (cut === 'pearl') {
    return (
      <>
        <defs>
          <radialGradient id={`g${id}`} cx="35%" cy="30%" r="75%">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset="0.5" stopColor={c1} />
            <stop offset="1" stopColor={c2} />
          </radialGradient>
        </defs>
        <Shadow rx={26} />
        <circle cx="50" cy="54" r="30" fill={`url(#g${id})`} />
        <ellipse cx="40" cy="42" rx="9" ry="5.5" fill="#fff" opacity="0.8" transform="rotate(-30 40 42)" />
      </>
    );
  }
  if (cut === 'cabochon') {
    return (
      <>
        <defs>
          <radialGradient id={`g${id}`} cx="35%" cy="28%" r="85%">
            <stop offset="0" stopColor={shade(c1, 0.4)} />
            <stop offset="0.55" stopColor={c1} />
            <stop offset="1" stopColor={c2} />
          </radialGradient>
        </defs>
        <Shadow rx={32} />
        <ellipse cx="50" cy="58" rx="34" ry="29" fill={`url(#g${id})`} />
        {[0.72, 0.46].map((k) => (
          <ellipse key={k} cx="50" cy="58" rx={34 * k} ry={29 * k} fill="none" stroke={shade(c2, -0.2)} strokeWidth="1.6" opacity="0.35" />
        ))}
        <path d="M54 48c4-8 14-10 18-4" fill="none" stroke={shade(c2, -0.35)} strokeWidth="1.4" opacity="0.4" />
        <ellipse cx="36" cy="44" rx="11" ry="6" fill="#fff" opacity="0.5" transform="rotate(-28 36 44)" />
      </>
    );
  }
  if (cut === 'emerald') {
    const outer = '28,16 72,16 90,34 90,66 72,84 28,84 10,66 10,34';
    return (
      <>
        <Shadow rx={32} />
        <polygon points={outer} fill={c2} />
        <polygon points="32,24 68,24 80,36 80,64 68,76 32,76 20,64 20,36" fill={c1} />
        <polygon points="40,34 60,34 66,42 66,58 60,66 40,66 34,58 34,42" fill={shade(c1, 0.35)} />
        <path d="M28 16L40 34M72 16L60 34M90 34L66 42M90 66L66 58M72 84L60 66M28 84L40 66M10 66L34 58M10 34L34 42" stroke="#fff" strokeWidth="1" opacity="0.5" />
        {sparkle}
      </>
    );
  }
  // برلیان (الماس)
  return (
    <>
      <Shadow rx={30} />
      <polygon points="30,26 70,26 62,44 38,44" fill={shade(c1, 0.45)} />
      <polygon points="30,26 38,44 10,44" fill={shade(c1, 0.12)} />
      <polygon points="70,26 62,44 90,44" fill={c2} />
      <polygon points="30,26 50,26 38,44" fill={shade(c1, 0.3)} opacity="0.7" />
      <polygon points="10,44 38,44 50,88" fill={shade(c1, -0.06)} />
      <polygon points="38,44 62,44 50,88" fill={shade(c2, -0.05)} />
      <polygon points="62,44 90,44 50,88" fill={shade(c2, -0.28)} />
      <path d="M10 44H90M30 26L38 44L50 26L62 44L70 26" fill="none" stroke="#fff" strokeWidth="0.9" opacity="0.55" />
      {sparkle}
    </>
  );
}

// ————— شمش فلز —————
function Ingot({ p, id }: K) {
  const [c1 = '#f5c542', c2 = '#a16207'] = p;
  return (
    <>
      <defs>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={shade(c1, 0.2)} />
          <stop offset="1" stopColor={c2} />
        </linearGradient>
      </defs>
      <ellipse cx="50" cy="88" rx="42" ry="5" fill="#000" opacity="0.2" />
      <path d="M31 36H69L80 52H20Z" fill={shade(c1, 0.45)} />
      <path d="M20 52H80L93 82H7Z" fill={`url(#g${id})`} />
      <path d="M20 52H80L93 82H7Z" fill="none" stroke={shade(c2, -0.3)} strokeWidth="1.2" />
      <path d="M26 60H74" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" opacity="0.5" />
      <path d="M36 44H64" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" opacity="0.6" />
    </>
  );
}

// ————— سیاره —————
function Planet({ p, R, id }: K) {
  const [c1 = '#fbbf24', c2 = '#b45309', feat = 'none'] = p;
  const stars = Array.from({ length: 10 }, (_, i) => <circle key={i} cx={f(6 + R() * 88)} cy={f(6 + R() * 88)} r={f(0.5 + R() * 1.1)} fill="#fff" opacity={f(0.4 + R() * 0.5)} />);
  const ring = (back: boolean) => (
    <path d={back ? 'M8 52A42 11 0 0 1 92 52' : 'M8 52A42 11 0 0 0 92 52'} fill="none" stroke={shade(c1, 0.15)} strokeWidth="5" opacity={back ? 0.7 : 0.95} transform="rotate(-18 50 52)" />
  );
  return (
    <>
      <defs>
        <radialGradient id={`g${id}`} cx="35%" cy="30%" r="80%">
          <stop offset="0" stopColor={shade(c1, 0.35)} />
          <stop offset="0.55" stopColor={c1} />
          <stop offset="1" stopColor={c2} />
        </radialGradient>
        <linearGradient id={`b${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#0b1030" />
          <stop offset="1" stopColor="#2a2a6b" />
        </linearGradient>
        <clipPath id={`c${id}`}>
          <circle cx="50" cy="52" r="27" />
        </clipPath>
      </defs>
      <rect x="1" y="1" width="98" height="98" rx="20" fill={`url(#b${id})`} />
      {stars}
      {feat.includes('ring') && ring(true)}
      <circle cx="50" cy="52" r="27" fill={`url(#g${id})`} />
      {(feat.includes('bands') || feat.includes('ring')) && (
        <g clipPath={`url(#c${id})`} opacity="0.5">
          {[38, 47, 55, 64].map((y, i) => (
            <path key={y} d={`M20 ${y}C40 ${y - 4} 60 ${y + 4} 82 ${y}`} stroke={i % 2 ? shade(c2, -0.2) : shade(c1, 0.4)} strokeWidth="3.4" fill="none" />
          ))}
        </g>
      )}
      {feat.includes('spot') && <ellipse cx="58" cy="58" rx="7" ry="4" fill="#c2410c" opacity="0.8" />}
      <ellipse cx="41" cy="42" rx="9" ry="5" fill="#fff" opacity="0.2" transform="rotate(-30 41 42)" />
      {feat.includes('ring') && ring(false)}
    </>
  );
}

// ————— درخت —————
function Tree({ p, R }: K) {
  const [shape = 'round', leaf = '#3f9a46', trunk = '#6b4423', fruit] = p;
  const dk = shade(leaf, -0.28);
  const lt = shade(leaf, 0.24);
  const dots = (n: number, x0: number, y0: number, w: number, h: number) =>
    fruit ? Array.from({ length: n }, (_, i) => <circle key={i} cx={f(x0 + R() * w)} cy={f(y0 + R() * h)} r="3.1" fill={fruit} stroke={shade(fruit, -0.3)} strokeWidth="0.6" />) : null;
  switch (shape) {
    case 'oak':
      return (
        <>
          <Shadow rx={32} />
          <path d="M41 90L45 56H55L59 90Z" fill={trunk} />
          <path d="M50 66L34 52M50 62L66 50" stroke={trunk} strokeWidth="4" strokeLinecap="round" />
          {[[24, 52, 16], [76, 52, 16], [50, 52, 20], [36, 38, 18], [64, 38, 18], [50, 26, 18]].map(([x, y, r], i) => <circle key={`d${i}`} cx={x} cy={y} r={r} fill={dk} />)}
          {[[24, 49, 14], [76, 49, 14], [50, 48, 17], [36, 34, 15], [64, 34, 15], [50, 22, 15]].map(([x, y, r], i) => <circle key={`l${i}`} cx={x} cy={y} r={r} fill={leaf} />)}
          <circle cx="42" cy="26" r="8" fill={lt} opacity="0.55" />
          {dots(8, 20, 24, 58, 32)}
        </>
      );
    case 'cone':
      return (
        <>
          <Shadow rx={28} />
          <rect x="46" y="76" width="8" height="14" fill={trunk} />
          <path d="M50 34L86 78H14Z" fill={dk} />
          <path d="M50 20L79 58H21Z" fill={leaf} />
          <path d="M50 6L71 38H29Z" fill={lt} />
          <path d="M50 6L71 38H50Z M50 20L79 58H50Z" fill="#000" opacity="0.1" />
        </>
      );
    case 'cypress':
    case 'poplar': {
      const w = shape === 'poplar' ? 12 : 21;
      return (
        <>
          <Shadow rx={22} />
          <rect x="47" y="82" width="6" height="9" fill={trunk} />
          <path d={`M50 3C${50 + w} 26 ${50 + w + 1} 60 50 86C${50 - w - 1} 60 ${50 - w} 26 50 3Z`} fill={leaf} />
          <path d={`M50 3C${50 + w} 26 ${50 + w + 1} 60 50 86Z`} fill="#000" opacity="0.14" />
          {[22, 38, 54, 70].map((y) => (
            <path key={y} d={`M${50 - w * 0.6} ${y + 6}Q50 ${y - 4} ${50 + w * 0.6} ${y + 6}`} fill="none" stroke={lt} strokeWidth="1.6" opacity="0.7" />
          ))}
        </>
      );
    }
    case 'willow':
      return (
        <>
          <Shadow rx={30} />
          <path d="M48 91C45 72 51 62 50 44" stroke={trunk} strokeWidth="7" strokeLinecap="round" fill="none" />
          {[[50, 32, 22], [31, 40, 14], [69, 40, 14]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill={dk} />)}
          {[[50, 29, 19], [32, 37, 12], [68, 37, 12]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill={leaf} />)}
          {Array.from({ length: 13 }, (_, i) => {
            const x = 16 + i * 5.7;
            const sway = (i % 2 ? 1 : -1) * 3;
            return <path key={i} d={`M${f(x)} 40C${f(x - sway)} 54 ${f(x + sway)} 68 ${f(x)} ${78 - Math.abs(6 - i) * 2}`} fill="none" stroke={i % 3 ? leaf : lt} strokeWidth="2.6" strokeLinecap="round" />;
          })}
        </>
      );
    case 'palm':
      return (
        <>
          <Shadow rx={26} />
          <path d="M49 91C54 72 45 52 52 30" stroke={trunk} strokeWidth="7" strokeLinecap="round" fill="none" />
          {[3, 5, 7, 9, 11, 13, 15, 17].map((y) => <path key={y} d={`M${f(46 + (y % 5) * 0.4)} ${y * 5 + 6}l9 -2`} stroke={shade(trunk, -0.3)} strokeWidth="1" opacity="0.6" />)}
          {[[12, 44], [22, 16], [44, 6], [64, 8], [82, 20], [92, 46], [52, 4]].map(([ex, ey], i) => (
            <g key={i}>
              <path d={`M52 30Q${f((52 + ex) / 2)} ${f(Math.min(30, ey) - 10)} ${ex} ${ey}`} stroke={dk} strokeWidth="5.4" strokeLinecap="round" fill="none" />
              <path d={`M52 30Q${f((52 + ex) / 2)} ${f(Math.min(30, ey) - 10)} ${ex} ${ey}`} stroke={i % 2 ? leaf : lt} strokeWidth="2.6" strokeLinecap="round" fill="none" />
            </g>
          ))}
          {fruit && [0, 1, 2, 3, 4].map((i) => <ellipse key={i} cx={f(47 + i * 2.8)} cy={f(36 + (i % 2) * 4)} rx="2.7" ry="3.8" fill={fruit} />)}
        </>
      );
    case 'umbrella':
      return (
        <>
          <Shadow rx={34} />
          <path d="M50 91C47 72 54 56 50 36" stroke={trunk} strokeWidth="6" strokeLinecap="round" fill="none" />
          <path d="M50 60L34 46M50 54L68 44" stroke={trunk} strokeWidth="3.2" strokeLinecap="round" />
          <ellipse cx="50" cy="31" rx="44" ry="12" fill={dk} />
          <ellipse cx="50" cy="28" rx="39" ry="9.5" fill={leaf} />
          <ellipse cx="40" cy="24" rx="19" ry="4.2" fill={lt} opacity="0.55" />
          <ellipse cx="24" cy="46" rx="14" ry="5" fill={dk} />
          <ellipse cx="24" cy="44" rx="12" ry="4" fill={leaf} />
        </>
      );
    case 'bush':
      return (
        <>
          <Shadow rx={36} />
          {[[28, 70, 17], [50, 58, 22], [72, 70, 17], [40, 76, 15], [62, 76, 15]].map(([x, y, r], i) => <circle key={`d${i}`} cx={x} cy={y} r={r} fill={dk} />)}
          {[[28, 67, 14], [50, 54, 19], [72, 67, 14], [40, 72, 12], [62, 72, 12]].map(([x, y, r], i) => <circle key={`l${i}`} cx={x} cy={y} r={r} fill={leaf} />)}
          <circle cx="44" cy="46" r="8" fill={lt} opacity="0.5" />
          {dots(7, 22, 48, 56, 28)}
        </>
      );
    case 'baobab':
      return (
        <>
          <Shadow rx={30} />
          <path d="M34 91C40 72 36 54 40 38H60C64 54 60 72 66 91Z" fill={trunk} />
          <path d="M46 40L30 30M54 40L70 30M50 40V24" stroke={trunk} strokeWidth="4" strokeLinecap="round" />
          {[[30, 26, 12], [50, 18, 14], [70, 26, 12]].map(([x, y, r], i) => <circle key={`d${i}`} cx={x} cy={y} r={r} fill={dk} />)}
          {[[30, 23, 10], [50, 15, 12], [70, 23, 10]].map(([x, y, r], i) => <circle key={`l${i}`} cx={x} cy={y} r={r} fill={leaf} />)}
        </>
      );
    default:
      return (
        <>
          <Shadow rx={30} />
          <path d="M44 91L47 56H53L56 91Z" fill={trunk} />
          {[[50, 40, 24], [33, 52, 17], [67, 52, 17]].map(([x, y, r], i) => <circle key={`d${i}`} cx={x} cy={y} r={r} fill={dk} />)}
          {[[48, 36, 21], [34, 49, 14], [66, 49, 14]].map(([x, y, r], i) => <circle key={`l${i}`} cx={x} cy={y} r={r} fill={leaf} />)}
          <circle cx="42" cy="29" r="9" fill={lt} opacity="0.5" />
          {dots(9, 26, 24, 48, 34)}
        </>
      );
  }
}

// ————— میوه —————
function Fruit({ p, id }: K) {
  const [c1 = '#ef4444', c2 = '#991b1b', shape = 'round', leaf = '#3f9a46'] = p;
  const grad = (
    <defs>
      <radialGradient id={`g${id}`} cx="35%" cy="30%" r="80%">
        <stop offset="0" stopColor={shade(c1, 0.35)} />
        <stop offset="0.5" stopColor={c1} />
        <stop offset="1" stopColor={c2} />
      </radialGradient>
    </defs>
  );
  const fill = `url(#g${id})`;
  const stem = <path d="M50 30C50 24 52 19 56 15" stroke="#6b4423" strokeWidth="3.2" strokeLinecap="round" fill="none" />;
  const leafShape = <path d="M56 22C62 12 76 12 80 18C74 28 62 28 56 22Z" fill={leaf} />;
  const shine = (x: number, y: number) => <ellipse cx={x} cy={y} rx="7" ry="4.4" fill="#fff" opacity="0.38" transform={`rotate(-35 ${x} ${y})`} />;
  switch (shape) {
    case 'pear':
      return (
        <>
          {grad}
          <Shadow rx={26} />
          <path d="M50 18C60 18 62 34 70 48C80 62 74 88 50 88C26 88 20 62 30 48C38 34 40 18 50 18Z" fill={fill} />
          {stem}
          {leafShape}
          {shine(38, 58)}
        </>
      );
    case 'oval':
      return (
        <>
          {grad}
          <Shadow rx={22} />
          <ellipse cx="50" cy="58" rx="22" ry="31" fill={fill} />
          <path d="M44 28Q50 24 56 28" stroke={shade(c2, -0.4)} strokeWidth="3" strokeLinecap="round" fill="none" />
          {shine(41, 46)}
        </>
      );
    case 'cluster':
      return (
        <>
          {grad}
          <Shadow rx={26} />
          {[[38, 36], [50, 36], [62, 36], [32, 49], [44, 49], [56, 49], [68, 49], [38, 62], [50, 62], [62, 62], [44, 75], [56, 75], [50, 87]].map(([x, y], i) => (
            <g key={i}>
              <circle cx={x} cy={y} r="8.6" fill={fill} stroke={shade(c2, -0.3)} strokeWidth="0.6" />
              <circle cx={x - 2.6} cy={y - 2.8} r="2" fill="#fff" opacity="0.4" />
            </g>
          ))}
          {stem}
          {leafShape}
        </>
      );
    case 'crown':
      return (
        <>
          {grad}
          <Shadow rx={28} />
          <circle cx="50" cy="58" r="30" fill={fill} />
          <path d="M37 34L38 22L45 29L50 19L55 29L62 22L63 34Z" fill={shade(c2, -0.1)} />
          {shine(38, 48)}
          <path d="M30 70C40 78 60 78 70 70" stroke={shade(c2, -0.3)} strokeWidth="1.6" fill="none" opacity="0.4" />
        </>
      );
    case 'drop':
      return (
        <>
          {grad}
          <Shadow rx={26} />
          <path d="M50 16C58 28 78 44 74 66C71 82 60 88 50 88C40 88 29 82 26 66C22 44 42 28 50 16Z" fill={fill} />
          <path d="M50 20V12" stroke="#6b4423" strokeWidth="3.4" strokeLinecap="round" />
          {shine(40, 58)}
        </>
      );
    case 'heart':
      return (
        <>
          {grad}
          <Shadow rx={26} />
          <path d="M50 90C22 68 15 46 25 36C33 28 46 32 50 41C54 32 67 28 75 36C85 46 78 68 50 90Z" fill={fill} />
          {[[36, 48], [50, 52], [64, 48], [42, 62], [58, 62], [50, 74], [34, 38], [66, 38]].map(([x, y], i) => <ellipse key={i} cx={x} cy={y} rx="1.4" ry="2.1" fill="#fde68a" />)}
          <path d="M50 37L40 29L46 38L33 37L44 43L40 50L50 44L60 50L56 43L67 37L54 38L60 29Z" fill={leaf} />
        </>
      );
    default:
      return (
        <>
          {grad}
          <Shadow rx={26} />
          <circle cx="50" cy="58" r="30" fill={fill} />
          {stem}
          {leafShape}
          {shine(38, 46)}
        </>
      );
  }
}

// ————— سبزی —————
function Veg({ p, id }: K) {
  const [c1 = '#3f9a46', c2 = '#2d7a34', shape = 'leaf'] = p;
  const grad = (
    <defs>
      <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={shade(c1, 0.3)} />
        <stop offset="1" stopColor={c2} />
      </linearGradient>
    </defs>
  );
  const fill = `url(#g${id})`;
  switch (shape) {
    case 'blade':
      return (
        <>
          <Shadow rx={22} />
          {[-34, -26, -18, -10, -3, 5, 13, 21, 29, 36].map((dx, i) => (
            <path key={i} d={`M${50 + dx * 0.15} 90C${f(50 + dx * 0.2)} 62 ${f(50 + dx * 0.9)} 40 ${50 + dx} ${10 + Math.abs(dx) * 0.35}`} stroke={i % 2 ? c1 : c2} strokeWidth="3.3" strokeLinecap="round" fill="none" />
          ))}
          <rect x="41" y="68" width="18" height="5" rx="2.5" fill="#a16207" />
        </>
      );
    case 'root':
      return (
        <>
          {grad}
          <Shadow rx={20} />
          {[-16, -6, 5, 15].map((dx, i) => <path key={i} d={`M50 36C${50 + dx * 0.5} 24 ${50 + dx} 16 ${50 + dx * 1.3} 6`} stroke={i % 2 ? '#3f9a46' : '#2d7a34'} strokeWidth="3.6" strokeLinecap="round" fill="none" />)}
          <path d="M34 38C34 30 66 30 66 38C64 62 55 80 50 94C45 80 36 62 34 38Z" fill={fill} />
          {[48, 58, 68].map((y, i) => <path key={y} d={`M${38 + i * 2} ${y}h${10 - i * 2}`} stroke={shade(c2, -0.3)} strokeWidth="1.2" opacity="0.5" />)}
        </>
      );
    case 'beet':
      return (
        <>
          {grad}
          <Shadow rx={24} />
          {[-14, -2, 10].map((dx, i) => <path key={i} d={`M50 36C${50 + dx * 0.4} 26 ${50 + dx} 16 ${50 + dx * 1.2} 6`} stroke="#9f1239" strokeWidth="3" strokeLinecap="round" fill="none" />)}
          <path d="M50 8C36 4 30 14 34 22C42 22 48 18 50 8ZM52 8C66 4 72 14 68 22C60 22 54 18 52 8Z" fill="#3f9a46" opacity="0.9" />
          <circle cx="50" cy="58" r="26" fill={fill} />
          <path d="M50 84C50 88 49 92 47 96" stroke={shade(c2, -0.2)} strokeWidth="2.4" strokeLinecap="round" />
          <ellipse cx="40" cy="48" rx="7" ry="4" fill="#fff" opacity="0.28" transform="rotate(-35 40 48)" />
        </>
      );
    case 'bulb':
      return (
        <>
          {grad}
          <Shadow rx={26} />
          <path d="M50 10C53 26 80 36 80 62C80 82 64 90 50 90C36 90 20 82 20 62C20 36 47 26 50 10Z" fill={fill} />
          {[-16, -6, 6, 16].map((dx, i) => <path key={i} d={`M${50 + dx * 0.3} 24C${50 + dx * 1.6} 40 ${50 + dx * 2.1} 64 ${50 + dx * 0.9} 88`} stroke={shade(c2, -0.2)} strokeWidth="1.3" fill="none" opacity="0.55" />)}
          <path d="M44 90L42 97M50 91V98M56 90L58 97" stroke="#d6c7a3" strokeWidth="1.6" strokeLinecap="round" />
          <ellipse cx="38" cy="54" rx="6" ry="12" fill="#fff" opacity="0.22" transform="rotate(12 38 54)" />
        </>
      );
    case 'pod':
      return (
        <>
          {grad}
          <Shadow rx={34} />
          <path d="M12 72C24 28 68 14 90 22C88 52 58 86 12 72Z" fill={fill} />
          {[[28, 60], [42, 50], [56, 41], [70, 32]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="6.2" fill={shade(c1, 0.3)} opacity="0.75" />)}
          <path d="M12 72C30 62 62 40 90 22" fill="none" stroke={shade(c2, -0.25)} strokeWidth="1.4" opacity="0.6" />
        </>
      );
    case 'long':
      return (
        <>
          {grad}
          <Shadow rx={30} />
          <g transform="rotate(32 50 50)">
            <rect x="37" y="8" width="26" height="82" rx="13" fill={fill} />
            <path d="M37 18Q50 4 63 18L60 24Q50 16 40 24Z" fill="#3f9a46" />
            <ellipse cx="45" cy="42" rx="3" ry="14" fill="#fff" opacity="0.3" />
            {[30, 46, 62, 76].map((y, i) => <circle key={y} cx={i % 2 ? 56 : 44} cy={y} r="1.1" fill={shade(c2, -0.4)} opacity="0.5" />)}
          </g>
        </>
      );
    default:
      return (
        <>
          <Shadow rx={30} />
          {[-62, -38, -14, 10, 34, 58].map((a, i) => (
            <g key={i} transform={`rotate(${a} 50 90)`}>
              <path d={`M50 90C${36 + (i % 2) * 3} 62 ${38} 30 50 ${8 + (i % 3) * 5}C${62} 30 ${64 - (i % 2) * 3} 62 50 90Z`} fill={i % 2 ? c1 : c2} />
              <path d={`M50 88V${14 + (i % 3) * 5}`} stroke="#fff" strokeWidth="1.1" opacity="0.4" />
            </g>
          ))}
        </>
      );
  }
}

// ————— ابر —————
function Cloud({ p, R, id }: K) {
  const t = p[0] || 'cumulus';
  const dark = ['cumulonimbus', 'nimbostratus', 'altostratus'].includes(t);
  const sky = dark ? ['#41536e', '#8c9db5'] : t === 'fog' ? ['#8aa0b3', '#d6e2ea'] : ['#4a97dd', '#c0e3ff'];
  const white = `url(#w${id})`;
  const gray = `url(#k${id})`;
  const puff = (list: number[][], fill: string) => list.map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill={fill} />);
  let body: ReactNode = null;
  switch (t) {
    case 'cumulonimbus':
      body = (
        <>
          <rect x="22" y="68" width="56" height="12" rx="6" fill={gray} />
          {puff([[50, 68, 16], [38, 60, 13], [62, 60, 13], [47, 47, 15], [56, 36, 14], [47, 26, 11]], white)}
          <ellipse cx="50" cy="18" rx="34" ry="6.5" fill="#fff" opacity="0.95" />
          <path d="M14 86l-3 9M26 88l-3 9M62 86l-3 9M74 88l-3 9M86 86l-3 9" stroke="#bfe0ff" strokeWidth="1.6" strokeLinecap="round" opacity="0.8" />
          <path d="M52 72L43 87H50L45 98L59 81H52Z" fill="#ffe14d" stroke="#d99a00" strokeWidth="0.6" />
        </>
      );
      break;
    case 'nimbostratus':
      body = (
        <>
          {[[8, 22, 84, 17], [14, 40, 72, 17], [6, 58, 88, 14]].map(([x, y, w, h], i) => <rect key={i} x={x} y={y} width={w} height={h} rx="8" fill={gray} opacity={0.95 - i * 0.08} />)}
          {Array.from({ length: 10 }, (_, i) => <path key={i} d={`M${12 + i * 8.5} ${76 + (i % 3) * 4}l-3 10`} stroke="#cfe6ff" strokeWidth="1.6" strokeLinecap="round" opacity="0.85" />)}
        </>
      );
      break;
    case 'stratus':
      body = (
        <>
          {[[12, 30, 76, 13], [20, 48, 62, 13], [8, 66, 84, 13]].map(([x, y, w, h], i) => <rect key={i} x={x} y={y} width={w} height={h} rx="6.5" fill={i === 1 ? white : gray} opacity="0.95" />)}
        </>
      );
      break;
    case 'cirrus':
      body = (
        <g stroke="#fff" strokeLinecap="round" fill="none" opacity="0.95">
          <path d="M8 30C30 22 52 42 90 24" strokeWidth="3.2" />
          <path d="M14 46C36 36 58 56 94 40" strokeWidth="2.8" />
          <path d="M6 62C28 52 50 70 84 56" strokeWidth="3" />
          <path d="M22 76C42 68 62 82 90 72" strokeWidth="2.2" />
          <path d="M90 24q6-1 8 5M94 40q5-1 6 4M84 56q5 0 7 5" strokeWidth="1.8" />
        </g>
      );
      break;
    case 'cirrocumulus':
      body = (
        <g fill="#fff">
          {Array.from({ length: 5 }, (_, r) => Array.from({ length: 7 }, (_, c) => <circle key={`${r}${c}`} cx={f(12 + c * 12 + (r % 2) * 6 + R() * 2)} cy={f(24 + r * 13 + R() * 2)} r={f(3.2 + R() * 1.4)} opacity="0.95" />))}
        </g>
      );
      break;
    case 'cirrostratus':
      body = (
        <>
          <rect x="0" y="22" width="100" height="56" fill="#fff" opacity="0.34" />
          <rect x="0" y="34" width="100" height="30" fill="#fff" opacity="0.28" />
          <circle cx="50" cy="46" r="27" fill="none" stroke="#fff" strokeWidth="2.2" opacity="0.7" />
          <circle cx="50" cy="46" r="9" fill="#fff3a0" />
          <circle cx="50" cy="46" r="14" fill="#fff3a0" opacity="0.35" />
        </>
      );
      break;
    case 'altocumulus':
      body = (
        <>
          {Array.from({ length: 3 }, (_, r) => Array.from({ length: 5 }, (_, c) => <ellipse key={`${r}${c}`} cx={20 + c * 15 + (r % 2) * 7} cy={32 + r * 18} rx="9.5" ry="6.4" fill={r === 2 ? gray : white} />))}
        </>
      );
      break;
    case 'altostratus':
      body = (
        <>
          <rect x="0" y="26" width="100" height="42" fill="#b8c4d3" opacity="0.9" />
          <rect x="0" y="40" width="100" height="30" fill="#9aa9bc" opacity="0.7" />
          <circle cx="62" cy="44" r="9" fill="#fff" opacity="0.55" />
          <circle cx="62" cy="44" r="15" fill="#fff" opacity="0.18" />
        </>
      );
      break;
    case 'stratocumulus':
      body = (
        <>
          {[18, 38, 58, 78].map((x, i) => <ellipse key={`a${i}`} cx={x} cy={44} rx="15" ry="10" fill={white} />)}
          {[28, 48, 68, 86].map((x, i) => <ellipse key={`b${i}`} cx={x} cy={60} rx="15" ry="9.5" fill={gray} />)}
        </>
      );
      break;
    case 'lenticular':
      body = (
        <>
          <ellipse cx="50" cy="22" rx="17" ry="4.4" fill={white} />
          <ellipse cx="50" cy="33" rx="25" ry="6" fill={white} />
          <ellipse cx="50" cy="45" rx="31" ry="6.6" fill={white} />
          <path d="M0 100L36 58L56 100Z" fill="#53627a" />
          <path d="M42 100L72 66L100 100Z" fill="#3e4c63" />
          <path d="M36 58L31 66L36 64L41 68Z" fill="#fff" opacity="0.85" />
        </>
      );
      break;
    case 'fog':
      body = (
        <>
          <rect x="0" y="70" width="100" height="30" fill="#5f7a60" />
          {[12, 30, 50, 68, 86].map((x, i) => <path key={x} d={`M${x} ${74 - (i % 2) * 6}l-7 22h14z`} fill="#3d5a40" />)}
          {[48, 60, 72].map((y, i) => <rect key={y} x={-6 + i * 8} y={y} width={100 - i * 4} height="11" rx="5.5" fill="#fff" opacity={0.62 + i * 0.05} />)}
        </>
      );
      break;
    case 'mammatus':
      body = (
        <>
          <rect x="4" y="18" width="92" height="22" rx="10" fill={gray} />
          {Array.from({ length: 8 }, (_, i) => <circle key={i} cx={13 + i * 10.6} cy={f(42 + R() * 9)} r="6.4" fill={i % 2 ? white : gray} />)}
          {Array.from({ length: 7 }, (_, i) => <circle key={`b${i}`} cx={18 + i * 10.6} cy={f(54 + R() * 8)} r="5.4" fill={white} opacity="0.9" />)}
        </>
      );
      break;
    default:
      body = (
        <>
          <rect x="18" y="62" width="66" height="16" rx="8" fill={gray} />
          {puff([[30, 64, 13], [45, 52, 18], [63, 56, 16], [76, 66, 11], [52, 68, 14]], white)}
          <g opacity="0.75">{puff([[14, 32, 6], [22, 28, 8], [31, 33, 6]], white)}</g>
        </>
      );
  }
  return (
    <>
      <defs>
        <linearGradient id={`s${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={sky[0]} />
          <stop offset="1" stopColor={sky[1]} />
        </linearGradient>
        <linearGradient id={`w${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor={dark ? '#aab6c6' : '#d3e0ee'} />
        </linearGradient>
        <linearGradient id={`k${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={dark ? '#7d8da3' : '#eef4fa'} />
          <stop offset="1" stopColor={dark ? '#36445a' : '#a9b9cc'} />
        </linearGradient>
        <clipPath id={`t${id}`}>
          <rect x="1" y="1" width="98" height="98" rx="20" />
        </clipPath>
      </defs>
      <rect x="1" y="1" width="98" height="98" rx="20" fill={`url(#s${id})`} />
      <g clipPath={`url(#t${id})`}>{body}</g>
    </>
  );
}

// ————— ماهی —————
function Fish({ p, R, id }: K) {
  const [c1 = '#60a5fa', c2 = '#1e3a8a', pat = 'plain', shape = 'normal'] = p;
  const dims: Record<string, [number, number, number]> = { normal: [30, 20, 42], long: [33, 8, 41], round: [24, 24, 44], tall: [20, 29, 46], sword: [28, 9, 50] };
  const [rx, ry, cx] = dims[shape] || dims.normal;
  const cy = 50;
  const fin = shade(c1, -0.22);
  const tx = cx + rx - 3;
  const spots = pat === 'spots' ? Array.from({ length: 12 }, (_, i) => <circle key={i} cx={f(cx - rx * 0.6 + R() * rx * 1.4)} cy={f(cy - ry * 0.7 + R() * ry * 1.4)} r={f(1.4 + R() * 1.6)} fill={c2} opacity="0.85" />) : null;
  const stripes = pat === 'stripes' ? [-0.3, 0.05, 0.4].map((k, i) => <rect key={i} x={cx + rx * k - 3} y={cy - ry - 4} width="6" height={ry * 2 + 8} fill={c2} opacity="0.92" />) : null;
  return (
    <>
      <defs>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={shade(c1, -0.12)} />
          <stop offset="0.55" stopColor={c1} />
          <stop offset="1" stopColor={shade(c1, 0.5)} />
        </linearGradient>
        <clipPath id={`c${id}`}>
          <ellipse cx={cx} cy={cy} rx={rx} ry={ry} />
        </clipPath>
      </defs>
      {shape === 'sword' && <path d={`M${cx - rx + 2} ${cy}L${cx - rx - 18} ${cy - 1.5}`} stroke={fin} strokeWidth="3" strokeLinecap="round" />}
      <path d={`M${tx} ${cy}L${tx + 20} ${f(cy - ry * 0.9 - 5)}Q${tx + 13} ${cy} ${tx + 20} ${f(cy + ry * 0.9 + 5)}Z`} fill={fin} />
      <path d={`M${f(cx - rx * 0.4)} ${f(cy - ry * 0.82)}Q${cx} ${f(cy - ry * (shape === 'tall' ? 2.1 : 1.75))} ${f(cx + rx * 0.5)} ${f(cy - ry * 0.78)}Z`} fill={fin} />
      {shape === 'tall' && <path d={`M${f(cx - rx * 0.3)} ${f(cy + ry * 0.82)}Q${cx} ${f(cy + ry * 2)} ${f(cx + rx * 0.5)} ${f(cy + ry * 0.78)}Z`} fill={fin} />}
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={`url(#g${id})`} />
      <g clipPath={`url(#c${id})`}>
        {stripes}
        {spots}
        {pat === 'belly' && <rect x={cx - rx} y={cy + ry * 0.15} width={rx * 2} height={ry} fill="#fff" opacity="0.5" />}
        <ellipse cx={cx - rx * 0.1} cy={cy - ry * 0.5} rx={rx * 0.6} ry={ry * 0.18} fill="#fff" opacity="0.25" />
      </g>
      <path d={`M${f(cx - rx * 0.36)} ${f(cy - ry * 0.6)}Q${f(cx - rx * 0.5)} ${cy} ${f(cx - rx * 0.36)} ${f(cy + ry * 0.6)}`} fill="none" stroke={shade(c1, -0.4)} strokeWidth="1.2" opacity="0.6" />
      <ellipse cx={cx - 2} cy={f(cy + ry * 0.3)} rx="6" ry="2.8" fill={fin} transform={`rotate(25 ${cx - 2} ${cy + ry * 0.3})`} />
      <circle cx={f(cx - rx * 0.64)} cy={f(cy - ry * 0.2)} r={f(Math.max(2.4, Math.min(4, ry * 0.22)))} fill="#fff" />
      <circle cx={f(cx - rx * 0.66)} cy={f(cy - ry * 0.2)} r={f(Math.max(1.3, Math.min(2.2, ry * 0.12)))} fill="#111" />
    </>
  );
}

// ————— صدف و بی‌مهرگان دریایی —————
function Shell({ p, R, id }: K) {
  const [c1 = '#f9a8d4', c2 = '#be185d', kind = 'fan'] = p;
  const grad = (
    <defs>
      <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={shade(c1, 0.35)} />
        <stop offset="1" stopColor={c2} />
      </linearGradient>
    </defs>
  );
  const fill = `url(#g${id})`;
  switch (kind) {
    case 'spiral': {
      const pts: string[] = [];
      for (let a = 0; a <= Math.PI * 5.2; a += 0.2) {
        const r = 2 + a * 2.1;
        pts.push(`${f(50 + Math.cos(a) * r)} ${f(54 + Math.sin(a) * r)}`);
      }
      return (
        <>
          {grad}
          <Shadow rx={32} />
          <circle cx="50" cy="54" r="36" fill={fill} />
          <polyline points={pts.join(' ')} fill="none" stroke={shade(c2, -0.2)} strokeWidth="3.4" strokeLinecap="round" opacity="0.75" />
          <ellipse cx="38" cy="38" rx="11" ry="5.5" fill="#fff" opacity="0.35" transform="rotate(-35 38 38)" />
        </>
      );
    }
    case 'conch':
      return (
        <>
          {grad}
          <Shadow rx={32} />
          {[[48, 18, 5, 5], [46, 27, 10, 8], [47, 38, 16, 11], [48, 52, 22, 14], [50, 68, 28, 17]].map(([x, y, rx, ry], i) => (
            <ellipse key={i} cx={x} cy={y} rx={rx} ry={ry} fill={i % 2 ? shade(c1, 0.15) : fill} stroke={shade(c2, -0.3)} strokeWidth="0.8" />
          ))}
          {[-14, 0, 14].map((dx) => <path key={dx} d={`M${50 + dx} 62l${dx / 4} 11`} stroke={shade(c2, -0.2)} strokeWidth="1.2" opacity="0.5" />)}
          <ellipse cx="62" cy="70" rx="13" ry="9" fill="#fbcfe8" stroke={shade(c2, -0.2)} strokeWidth="1" transform="rotate(-20 62 70)" />
        </>
      );
    case 'clam':
      return (
        <>
          {grad}
          <Shadow rx={34} />
          <path d="M12 66C8 36 30 18 50 18C70 18 92 36 88 66C80 80 20 80 12 66Z" fill={fill} />
          {[0.8, 0.6, 0.4].map((k) => <path key={k} d={`M${50 - 36 * k} ${66 - 6 * k}C${48 - 36 * k} ${50 - 18 * k} 36 ${24 + 20 * (1 - k)} 50 ${24 + 20 * (1 - k)}C64 ${24 + 20 * (1 - k)} ${52 + 36 * k} ${50 - 18 * k} ${50 + 36 * k} ${66 - 6 * k}`} fill="none" stroke={shade(c2, -0.2)} strokeWidth="1.5" opacity="0.5" />)}
          <path d="M14 68C24 78 76 78 86 68" fill="none" stroke={shade(c2, -0.35)} strokeWidth="2" />
          <ellipse cx="38" cy="36" rx="12" ry="5" fill="#fff" opacity="0.35" transform="rotate(-30 38 36)" />
        </>
      );
    case 'star': {
      const pts = Array.from({ length: 10 }, (_, i) => {
        const r = i % 2 ? 17 : 42;
        const a = -Math.PI / 2 + (i * Math.PI) / 5;
        return `${f(50 + Math.cos(a) * r)} ${f(54 + Math.sin(a) * r)}`;
      }).join(' ');
      return (
        <>
          {grad}
          <Shadow rx={34} />
          <polygon points={pts} fill={fill} stroke={c1} strokeWidth="7" strokeLinejoin="round" />
          <polygon points={pts} fill={fill} />
          {Array.from({ length: 5 }, (_, i) => {
            const a = -Math.PI / 2 + (i * 2 * Math.PI) / 5;
            return [0.35, 0.58, 0.8].map((k) => <circle key={`${i}${k}`} cx={f(50 + Math.cos(a) * 42 * k)} cy={f(54 + Math.sin(a) * 42 * k)} r="1.9" fill="#fff" opacity="0.65" />);
          })}
        </>
      );
    }
    case 'urchin':
      return (
        <>
          {grad}
          <Shadow rx={30} />
          {Array.from({ length: 30 }, (_, i) => {
            const a = (i / 30) * Math.PI * 2;
            const L = 38 + R() * 5;
            return <line key={i} x1={f(50 + Math.cos(a) * 20)} y1={f(56 + Math.sin(a) * 20)} x2={f(50 + Math.cos(a) * L)} y2={f(56 + Math.sin(a) * L)} stroke={c2} strokeWidth="2.2" strokeLinecap="round" />;
          })}
          <circle cx="50" cy="56" r="22" fill={fill} />
          <ellipse cx="42" cy="48" rx="7" ry="3.5" fill="#fff" opacity="0.3" transform="rotate(-35 42 48)" />
        </>
      );
    default: {
      // صدف بادبزنی
      const ribs = Array.from({ length: 9 }, (_, i) => {
        const a = (-155 + i * 16.25) * (Math.PI / 180);
        return <line key={i} x1="50" y1="84" x2={f(50 + Math.cos(a) * 46)} y2={f(84 + Math.sin(a) * 46)} stroke={shade(c2, -0.15)} strokeWidth="1.5" opacity="0.55" />;
      });
      const a1 = (-155 * Math.PI) / 180;
      const a2 = (-25 * Math.PI) / 180;
      return (
        <>
          {grad}
          <Shadow rx={32} />
          <path d={`M50 84L${f(50 + Math.cos(a1) * 46)} ${f(84 + Math.sin(a1) * 46)}A46 46 0 0 1 ${f(50 + Math.cos(a2) * 46)} ${f(84 + Math.sin(a2) * 46)}Z`} fill={fill} />
          {ribs}
          <path d="M36 86L40 76H60L64 86Z" fill={shade(c1, -0.1)} stroke={shade(c2, -0.2)} strokeWidth="0.8" />
        </>
      );
    }
  }
}

// ————— پرنده —————
function Bird({ p, id }: K) {
  const [c1 = '#9ca3af', c2 = '#4b5563', feat = 'none'] = p;
  const long = feat === 'long';
  const by = long ? 40 : 56;
  return (
    <>
      <defs>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={shade(c1, 0.12)} />
          <stop offset="1" stopColor={shade(c1, -0.18)} />
        </linearGradient>
      </defs>
      {feat === 'fan' && (
        <g>
          {Array.from({ length: 11 }, (_, i) => {
            const a = (-80 + i * 16) * (Math.PI / 180);
            return (
              <g key={i}>
                <line x1="72" y1="58" x2={f(72 + Math.sin(a) * 44)} y2={f(58 - Math.cos(a) * 44)} stroke={c2} strokeWidth="2" />
                <circle cx={f(72 + Math.sin(a) * 40)} cy={f(58 - Math.cos(a) * 40)} r="4.4" fill={shade(c2, 0.1)} stroke="#f59e0b" strokeWidth="1" />
                <circle cx={f(72 + Math.sin(a) * 40)} cy={f(58 - Math.cos(a) * 40)} r="1.7" fill="#1d4ed8" />
              </g>
            );
          })}
        </g>
      )}
      <Shadow rx={26} />
      {/* پاها */}
      <path d={`M48 ${by + 14}V${long ? 90 : 84}M58 ${by + 14}V${long ? 90 : 84}`} stroke="#d97706" strokeWidth={long ? 2 : 2.6} strokeLinecap="round" />
      <path d={`M42 ${long ? 90 : 84}h9M52 ${long ? 90 : 84}h9`} stroke="#d97706" strokeWidth="2.2" strokeLinecap="round" />
      {/* دم */}
      {feat !== 'fan' && <path d={`M72 ${by - 2}L94 ${by - 12}L91 ${by + 4}L94 ${by + 12}L72 ${by + 8}Z`} fill={c2} />}
      {/* گردن بلند */}
      {long && <path d={`M40 ${by - 2}C28 ${by - 10} 36 ${by - 24} 30 ${by - 30}`} stroke={c1} strokeWidth="6.4" strokeLinecap="round" fill="none" />}
      {/* بدن و بال */}
      <ellipse cx="56" cy={by} rx="25" ry="16" fill={`url(#g${id})`} />
      <path d={`M40 ${by - 3}C50 ${by - 14} 72 ${by - 6} 78 ${by + 4}C66 ${by + 12} 48 ${by + 10} 40 ${by - 3}Z`} fill={c2} opacity="0.92" />
      <path d={`M48 ${by + 2}C56 ${by - 4} 66 ${by - 2} 72 ${by + 3}`} stroke="#fff" strokeWidth="1" fill="none" opacity="0.4" />
      {/* سر */}
      <circle cx={long ? 29 : 31} cy={long ? by - 32 : by - 12} r="10.5" fill={shade(c1, 0.05)} />
      {feat === 'crest' && <path d={`M${27} ${by - 22}L24 ${by - 36}L31 ${by - 26}L34 ${by - 38}L37 ${by - 24}L43 ${by - 32}L39 ${by - 19}Z`} fill="#f97316" stroke={shade('#f97316', -0.3)} strokeWidth="0.7" />}
      <path d={`M${long ? 20 : 22} ${long ? by - 33 : by - 13}L${long ? 4 : 6} ${long ? by - 28 : by - 8}L${long ? 20 : 22} ${long ? by - 28 : by - 7}Z`} fill="#f59e0b" stroke="#b45309" strokeWidth="0.6" />
      <circle cx={long ? 28 : 30} cy={long ? by - 34 : by - 14} r="2" fill="#fff" />
      <circle cx={long ? 27.5 : 29.5} cy={long ? by - 34 : by - 14} r="1" fill="#111" />
    </>
  );
}

// ————— مرجان و عروس دریایی —————
function Coral({ p }: K) {
  const [c = '#f472b6'] = p;
  return (
    <>
      <ellipse cx="50" cy="90" rx="32" ry="6" fill="#64748b" opacity="0.65" />
      <g stroke={c} strokeWidth="6.5" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M50 90V58M50 70L32 50L28 28M50 62L68 44L74 22M32 50L16 44M68 44L86 40M50 58V28L44 12M28 28L20 20M74 22L82 14" />
      </g>
      <g stroke={shade(c, 0.5)} strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.7">
        <path d="M50 88V60M50 68L33 50M50 60L67 44M50 56V30" />
      </g>
      {[[28, 28], [74, 22], [44, 12], [16, 44], [86, 40], [20, 20], [82, 14]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="4.4" fill={shade(c, 0.35)} />)}
    </>
  );
}

function Jelly({ p, id }: K) {
  const [c1 = '#c4b5fd', c2 = '#7c3aed'] = p;
  return (
    <>
      <defs>
        <radialGradient id={`g${id}`} cx="40%" cy="25%" r="85%">
          <stop offset="0" stopColor="#fff" stopOpacity="0.9" />
          <stop offset="0.5" stopColor={c1} stopOpacity="0.85" />
          <stop offset="1" stopColor={c2} stopOpacity="0.8" />
        </radialGradient>
      </defs>
      {[24, 34, 44, 54, 64, 74].map((x, i) => (
        <path key={x} d={`M${x} 52C${x - 6} 64 ${x + 6} 74 ${x - 2} 88C${x - 5} 92 ${x} 94 ${x + 2} 96`} stroke={i % 2 ? c1 : c2} strokeWidth="2.6" strokeLinecap="round" fill="none" opacity="0.85" />
      ))}
      <path d="M14 54C14 16 86 16 86 54C74 60 62 50 50 56C38 50 26 60 14 54Z" fill={`url(#g${id})`} stroke={c2} strokeWidth="1" />
      <ellipse cx="38" cy="32" rx="10" ry="5" fill="#fff" opacity="0.6" transform="rotate(-25 38 32)" />
    </>
  );
}

// ————— دانه‌ها (غلات، حبوبات، ادویه) —————
function Seeds({ p, R }: K) {
  const [c1 = '#d9b86a', c2 = '#9a7a2e', shape = 'round'] = p;
  const dims: Record<string, [number, number]> = { rice: [5.6, 1.8], wheat: [3.8, 2.2], bean: [4.3, 2.7], round: [3, 2.8] };
  const [rx, ry] = dims[shape] || dims.round;
  const list = Array.from({ length: 74 }, (_, i) => {
    const x = 50 + (R() - 0.5) * 2 * 40;
    const maxH = 46 * (1 - Math.pow(Math.abs(x - 50) / 40, 1.5));
    return { x, y: 88 - R() * maxH, rot: R() * 180, k: i % 3 };
  }).sort((a, b) => a.y - b.y);
  return (
    <>
      <Shadow rx={40} />
      {list.map((s, i) => (
        <g key={i} transform={`translate(${f(s.x)} ${f(s.y)}) rotate(${f(s.rot)})`}>
          <ellipse rx={rx} ry={ry} fill={s.k === 0 ? c1 : s.k === 1 ? shade(c1, -0.14) : c2} stroke={shade(c2, -0.38)} strokeWidth="0.35" />
          {(shape === 'wheat' || shape === 'bean') && <path d={`M${-rx * 0.65} 0H${rx * 0.65}`} stroke={shade(c2, -0.35)} strokeWidth="0.4" />}
          <ellipse cx={-rx * 0.28} cy={-ry * 0.4} rx={rx * 0.34} ry={ry * 0.24} fill="#fff" opacity="0.38" />
        </g>
      ))}
    </>
  );
}

// ————— گل —————
function Flower({ p }: K) {
  const [petal = '#f472b6', center = '#fde047', shape = 'five'] = p;
  const cx = 50;
  const cy = 36;
  const stem = (
    <>
      <path d="M50 97C50 80 48 66 50 52" stroke="#3f8f3a" strokeWidth="3.4" strokeLinecap="round" fill="none" />
      <path d="M50 84C40 82 34 74 32 66C42 66 49 72 50 84Z" fill="#4aa14a" />
      <path d="M50 78C60 76 66 68 68 60C58 60 51 66 50 78Z" fill="#3f8f3a" />
    </>
  );
  if (shape === 'tulip') {
    return (
      <>
        {stem}
        <path d="M30 22C30 44 38 58 50 58C62 58 70 44 70 22C62 28 56 20 50 10C44 20 38 28 30 22Z" fill={petal} />
        <path d="M50 10C44 20 44 42 50 58C56 42 56 20 50 10Z" fill={shade(petal, -0.15)} />
      </>
    );
  }
  const cfg: Record<string, { n: number; d: number; rx: number; ry: number; r: number }> = {
    five: { n: 5, d: 13, rx: 9.5, ry: 11, r: 6 },
    many: { n: 14, d: 14, rx: 3.4, ry: 12, r: 6.5 },
    narcissus: { n: 6, d: 13, rx: 7, ry: 11.5, r: 8.5 },
  };
  const c = cfg[shape] || cfg.five;
  return (
    <>
      {stem}
      {Array.from({ length: c.n }, (_, i) => (
        <ellipse key={i} cx={cx} cy={cy - c.d} rx={c.rx} ry={c.ry} fill={petal} stroke={shade(petal, -0.25)} strokeWidth="0.7" transform={`rotate(${(i * 360) / c.n} ${cx} ${cy})`} />
      ))}
      <circle cx={cx} cy={cy} r={c.r} fill={center} stroke={shade(center, -0.3)} strokeWidth="0.8" />
      {shape === 'narcissus' && <circle cx={cx} cy={cy} r="4.4" fill={shade(center, -0.2)} />}
      <circle cx={cx - 2} cy={cy - 2} r="1.6" fill="#fff" opacity="0.5" />
    </>
  );
}

// ————— اندام‌های بدن —————
function Organ({ p, id }: K) {
  const [c1 = '#c0614a', c2 = '#7a2e1f', shape = 'liver'] = p;
  const grad = (
    <defs>
      <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={shade(c1, 0.25)} />
        <stop offset="1" stopColor={c2} />
      </linearGradient>
    </defs>
  );
  const fill = `url(#g${id})`;
  const line = shade(c2, -0.3);
  const shine = <ellipse cx="38" cy="38" rx="12" ry="5" fill="#fff" opacity="0.28" transform="rotate(-25 38 38)" />;
  switch (shape) {
    case 'kidney':
      return (
        <>
          {grad}
          <Shadow rx={26} />
          <path d="M60 12C86 14 92 44 79 67C70 83 46 91 34 79C26 71 38 62 46 56C52 50 44 44 36 36C26 24 44 10 60 12Z" fill={fill} stroke={line} strokeWidth="1.2" />
          <path d="M46 54C40 62 34 66 26 68M48 58C44 66 42 72 38 78" stroke={shade(c1, 0.5)} strokeWidth="3" strokeLinecap="round" fill="none" opacity="0.8" />
          {shine}
        </>
      );
    case 'stomach':
      return (
        <>
          {grad}
          <Shadow rx={28} />
          <path d="M36 4V14" stroke={shade(c1, 0.2)} strokeWidth="7" strokeLinecap="round" />
          <path d="M36 12C24 12 28 28 36 34C46 42 72 40 77 60C81 84 52 94 38 82C26 72 36 56 28 44C20 30 22 12 36 12Z" fill={fill} stroke={line} strokeWidth="1.2" />
          <path d="M40 34C54 40 66 48 70 62" stroke={shade(c2, -0.1)} strokeWidth="1.2" fill="none" opacity="0.45" />
          {shine}
        </>
      );
    case 'intestine':
      return (
        <>
          <Shadow rx={34} />
          <path d="M22 24H78C90 24 90 42 78 42H22C10 42 10 60 22 60H78C90 60 90 78 78 78H34" stroke={c2} strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d="M22 24H78C90 24 90 42 78 42H22C10 42 10 60 22 60H78C90 60 90 78 78 78H34" stroke={c1} strokeWidth="8.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d="M24 22H76" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity="0.35" />
        </>
      );
    default:
      return (
        <>
          {grad}
          <Shadow rx={34} />
          <path d="M8 52C10 30 46 20 90 36C95 55 72 78 42 73C24 72 8 68 8 52Z" fill={fill} stroke={line} strokeWidth="1.2" />
          <path d="M30 30C40 44 46 58 44 72" stroke={shade(c2, -0.1)} strokeWidth="1.3" fill="none" opacity="0.45" />
          <circle cx="62" cy="72" r="6.4" fill="#5e8f3a" stroke="#3d6226" strokeWidth="1" />
          {shine}
        </>
      );
  }
}

const KINDS: Record<string, (k: K) => ReactNode> = {
  rock: Rock, gem: Gem, ingot: Ingot, planet: Planet, tree: Tree, fruit: Fruit, veg: Veg,
  cloud: Cloud, fish: Fish, shell: Shell, bird: Bird, coral: Coral, jelly: Jelly,
  seeds: Seeds, flower: Flower, organ: Organ,
};

export function Art({ a, size = 64, className }: { a: string; size?: number; className?: string }) {
  const id = useId().replace(/:/g, '');
  if (!a.startsWith('~')) {
    return (
      <span className={className} role="img" aria-hidden="true" style={{ display: 'inline-grid', placeItems: 'center', width: size, height: size, fontSize: size * 0.8, lineHeight: 1 }}>
        {a}
      </span>
    );
  }
  const [kind, ...p] = a.slice(1).split(':');
  const Draw = KINDS[kind];
  if (!Draw) return null;
  const R = rng(hash(a));
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} role="img" aria-hidden="true" style={{ display: 'block' }}>
      {Draw({ p, R, id })}
    </svg>
  );
}
