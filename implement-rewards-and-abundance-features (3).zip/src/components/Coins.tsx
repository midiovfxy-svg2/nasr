import { useCallback, useEffect, useId, useRef, useState, useSyncExternalStore } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { faNum } from '../lib/storage';
import { cn } from '../utils/cn';
import { getPending, landCoin, onBurst, onCoinLand, playCoin, reducedMotion, resetPending, setSound, soundEnabled, watchPending, watchSound, type CoinBurst } from '../lib/coins';

// ————— نشان سکه (طلایی با ستارهٔ هشت‌پر) —————
export function CoinIcon({ size = 20, className }: { size?: number; className?: string }) {
  const id = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 40 40" width={size} height={size} className={className} aria-hidden="true">
      <defs>
        <radialGradient id={`cg${id}`} cx="35%" cy="28%" r="80%">
          <stop offset="0" stopColor="#fff7c2" />
          <stop offset="0.38" stopColor="#ffd84d" />
          <stop offset="0.75" stopColor="#e1a41c" />
          <stop offset="1" stopColor="#a8700a" />
        </radialGradient>
      </defs>
      <circle cx="20" cy="20" r="19" fill={`url(#cg${id})`} />
      <circle cx="20" cy="20" r="19" fill="none" stroke="#8a5a06" strokeWidth="1.2" opacity="0.7" />
      <circle cx="20" cy="20" r="14.2" fill="none" stroke="#fff3b0" strokeWidth="1.4" opacity="0.85" />
      <circle cx="20" cy="20" r="14.2" fill="none" stroke="#a8700a" strokeWidth="0.7" opacity="0.6" transform="translate(0.6 0.6)" />
      <path d="M20 9.5l2.2 6 6.3-.3-5 3.9 1.9 6-5.4-3.5-5.4 3.5 1.9-6-5-3.9 6.3.3z" fill="#b97d0c" opacity="0.9" />
      <path d="M20 10.5l1.9 5.3 5.6-.2-4.4 3.4 1.7 5.3-4.8-3.1-4.8 3.1 1.7-5.3-4.4-3.4 5.6.2z" fill="#ffe27a" />
    </svg>
  );
}

// ————— شمارندهٔ سکه: مقصد پرواز سکه‌ها —————
export function CoinPill({ value, kids, compact = false, className }: { value: number; kids?: boolean; compact?: boolean; className?: string }) {
  const pending = useSyncExternalStore(watchPending, getPending);
  const sound = useSyncExternalStore(watchSound, soundEnabled);
  const [shown, setShown] = useState(value);
  const [pulse, setPulse] = useState(0);

  // وقتی سکه‌ای در راه نیست، شمارنده همیشه با مقدار واقعی هماهنگ است
  useEffect(() => {
    if (pending === 0) setShown(value);
  }, [value, pending]);

  // هر سکه که می‌رسد، شمارنده یک پله بالا می‌رود
  useEffect(
    () =>
      onCoinLand((share) => {
        if (share > 0) setShown((s) => s + share);
        setPulse((p) => p + 1);
      }),
    [],
  );

  return (
    <div
      data-coin-target
      className={cn(
        'relative rounded-xl text-center font-black',
        compact ? 'flex items-center gap-1.5 px-2.5 py-1.5 text-xs' : 'px-2 py-1.5 text-xs',
        kids ? 'bg-amber-100 text-amber-800 ring-1 ring-amber-300' : 'bg-amber-300/15 text-amber-200 ring-1 ring-amber-300/30',
        className,
      )}
      role="status"
      aria-label={`${faNum(shown)} سکه`}
    >
      <span key={pulse} className="inline-flex items-center justify-center gap-1 tabular-nums" style={pulse ? { animation: 'coin-pop 0.38s ease-out' } : undefined}>
        <CoinIcon size={compact ? 18 : 15} />
        {faNum(shown)}
      </span>
      {compact ? <span className="text-[9px] font-bold opacity-70">سکه</span> : <div className="text-[9px] font-bold opacity-70">سکه</div>}
      <button
        type="button"
        onClick={() => setSound(!sound)}
        className={cn('absolute -left-1.5 -top-1.5 grid h-[18px] w-[18px] place-items-center rounded-full border text-[9px]', kids ? 'border-amber-200 bg-white text-amber-700' : 'border-white/15 bg-[#161d3d] text-amber-200')}
        aria-label={sound ? 'خاموش‌کردن صدای سکه' : 'روشن‌کردن صدای سکه'}
        title={sound ? 'خاموش‌کردن صدای سکه' : 'روشن‌کردن صدای سکه'}
      >
        {sound ? <Volume2 size={10} /> : <VolumeX size={10} />}
      </button>
    </div>
  );
}

// ————— لایهٔ پرواز: سکه‌ها از محل پاسخ بیرون می‌ریزند و بالا می‌روند —————
function Sprite({ index, burst, onEnd }: { index: number; burst: CoinBurst; onEnd: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const endRef = useRef(onEnd);
  endRef.current = onEnd;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const share = Math.floor(((index + 1) * burst.amount) / burst.count) - Math.floor((index * burst.amount) / burst.count);
    const target = document.querySelector<HTMLElement>('[data-coin-target]');
    const r = target?.getBoundingClientRect();
    const tx = r && r.width ? r.left + r.width / 2 : window.innerWidth / 2;
    const ty = r && r.height ? r.top + r.height / 2 : 36;

    // مرورگرهای قدیمی بدون Web Animations: سکه بی‌حرکت به شمارنده می‌رسد
    if (typeof el.animate !== 'function') {
      landCoin(share);
      endRef.current();
      return;
    }

    const ang = (index / burst.count) * Math.PI * 2 + Math.random() * 0.8;
    const dist = 38 + Math.random() * 46;
    const sx = burst.x + Math.cos(ang) * dist;
    const sy = burst.y + Math.sin(ang) * dist * 0.75 - 26;
    const mx = (sx + tx) / 2 + (Math.random() - 0.5) * 70;
    const my = Math.min(sy, ty) + (Math.abs(sy - ty) * 0.42) - 24;
    const spin = (Math.random() > 0.5 ? 1 : -1) * (720 + Math.random() * 360);
    const pos = (x: number, y: number, s: number, rot: number) => `translate3d(${x}px, ${y}px, 0) scale(${s}) rotateY(${rot}deg)`;
    const delay = index * 55;

    const anim = el.animate(
      [
        { transform: pos(burst.x, burst.y, 0.25, 0), opacity: 0, offset: 0, easing: 'cubic-bezier(.16,.9,.3,1)' },
        { transform: pos(sx, sy, 1.15, spin * 0.2), opacity: 1, offset: 0.2, easing: 'ease-in-out' },
        { transform: pos(sx, sy - 8, 1.05, spin * 0.3), opacity: 1, offset: 0.34, easing: 'cubic-bezier(.45,.05,.85,.5)' },
        { transform: pos(mx, my, 0.9, spin * 0.65), opacity: 1, offset: 0.68, easing: 'cubic-bezier(.2,.4,.6,1)' },
        { transform: pos(tx, ty, 0.5, spin), opacity: 1, offset: 0.96 },
        { transform: pos(tx, ty, 0.3, spin), opacity: 0, offset: 1 },
      ],
      { duration: 1250 + Math.random() * 250, delay, fill: 'both' },
    );
    anim.onfinish = () => {
      playCoin(index);
      landCoin(share);
      endRef.current();
    };
    return () => anim.cancel();
  }, [burst, index]);

  return (
    <div ref={ref} className="absolute left-0 top-0 -ml-[15px] -mt-[15px] opacity-0 will-change-transform" style={{ width: 30, height: 30, filter: 'drop-shadow(0 3px 5px rgba(120,70,0,.45))' }}>
      <CoinIcon size={30} />
    </div>
  );
}

function Burst({ burst, onDone }: { burst: CoinBurst; onDone: () => void }) {
  const left = useRef(burst.count);
  const reduce = useRef(reducedMotion()).current;
  const [label, setLabel] = useState(true);

  useEffect(() => {
    if (!reduce) return;
    // بدون حرکت: فقط شمارنده یک‌جا بالا می‌رود
    landCoin(burst.amount);
    const timer = setTimeout(onDone, 900);
    return () => clearTimeout(timer);
  }, [reduce, burst.amount, onDone]);

  useEffect(() => {
    const timer = setTimeout(() => setLabel(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const end = useCallback(() => {
    left.current -= 1;
    if (left.current <= 0) onDone();
  }, [onDone]);

  return (
    <>
      {label && (
        <span
          className="absolute whitespace-nowrap rounded-full bg-amber-400 px-2.5 py-0.5 text-sm font-black text-amber-950 shadow-lg"
          style={{ left: burst.x, top: burst.y - 54, animation: reduce ? undefined : 'coin-label 1.5s ease-out forwards' }}
        >
          +{faNum(burst.amount)} 🪙
        </span>
      )}
      {!reduce && Array.from({ length: burst.count }, (_, i) => <Sprite key={i} index={i} burst={burst} onEnd={end} />)}
    </>
  );
}

export function CoinLayer() {
  const [bursts, setBursts] = useState<CoinBurst[]>([]);
  useEffect(() => onBurst((b) => setBursts((list) => [...list, b])), []);
  useEffect(() => {
    if (!bursts.length) resetPending();
  }, [bursts.length]);
  const done = useCallback((id: number) => setBursts((list) => list.filter((b) => b.id !== id)), []);
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[90] overflow-hidden" style={{ perspective: 700 }}>
      {bursts.map((b) => (
        <Burst key={b.id} burst={b} onDone={() => done(b.id)} />
      ))}
    </div>
  );
}
