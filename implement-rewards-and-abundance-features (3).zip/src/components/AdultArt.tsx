import { useId, type ReactNode } from 'react';
import { Art } from './Art';

// نگاره‌های گرافیکی ویژهٔ بزرگسالان: صحنه با نور، سایه و پس‌زمینه — نه ایموجی کودکانه.
// اگر کد با «~» باشد، همان تصویرسازی دقیق داخل قاب عکاسی قرار می‌گیرد.

type Theme = 'sky' | 'land' | 'sea' | 'dusk' | 'studio' | 'warm' | 'night';

function themeOf(code: string): Theme {
  const k = code.slice(1).split(':')[0];
  if (['fish', 'shell', 'coral', 'jelly'].includes(k)) return 'sea';
  if (['cloud', 'planet', 'bird'].includes(k)) return 'sky';
  if (['tree', 'flower', 'veg', 'seeds'].includes(k)) return 'land';
  if (k === 'organ') return 'warm';
  return 'studio';
}

const AS_CODE: Record<string, string> = {
  '🍎': '~fruit:#e11d48:#9f1239:round',
  '🍐': '~fruit:#d9e37a:#65a30d:pear',
  '🍑': '~fruit:#fb923c:#c2410c:round',
  '🍒': '~fruit:#dc2626:#7f1d1d:round',
  '🍇': '~fruit:#7c3aed:#3b0764:cluster',
  '🍓': '~fruit:#ef4444:#9f1239:heart',
  '🫐': '~fruit:#3b82f6:#1e3a8a:round',
  '🍌': '~fruit:#fde047:#ca8a04:oval',
  '🍊': '~fruit:#f97316:#c2410c:round',
  '🍋': '~fruit:#fde047:#eab308:oval',
  '🍍': '~fruit:#f59e0b:#b45309:oval',
  '🥭': '~fruit:#f59e0b:#c2410c:drop',
  '🥥': '~fruit:#f5f5f4:#a8a29e:round',
  '🥝': '~fruit:#84cc16:#3f6212:round',
  '🥜': '~seeds:#d6a56b:#92400e:bean',
  '🌰': '~fruit:#92400e:#451a03:drop',
  '🥬': '~veg:#4ade80:#166534:leaf',
  '🥕': '~veg:#f97316:#9a3412:root',
  '🥔': '~veg:#d6b48a:#a16207:bulb',
  '🧅': '~veg:#f5e6c8:#d6c08a:bulb',
  '🧄': '~veg:#f5f5f4:#d6d3d1:bulb',
  '🥦': '~veg:#22c55e:#14532d:leaf',
  '🥒': '~veg:#65a30d:#3f6212:long',
  '🍅': '~fruit:#ef4444:#991b1b:round',
  '🍆': '~fruit:#6d28d9:#3b0764:drop',
  '🫑': '~fruit:#22c55e:#14532d:drop',
  '🌶️': '~fruit:#dc2626:#7f1d1d:drop',
  '🍉': '~fruit:#22c55e:#14532d:round',
  '🍈': '~fruit:#fde68a:#d97706:round',
  '🌽': '~seeds:#fde047:#ca8a04:wheat',
  '🌹': '~flower:#e11d48:#14532d:many',
  '🌷': '~flower:#ef4444:#fde047:tulip',
  '🌻': '~flower:#facc15:#92400e:five',
  '🌼': '~flower:#f8fafc:#facc15:five',
  '🌸': '~flower:#fbcfe8:#f9a8d4:five',
  '🌺': '~flower:#fb7185:#be123c:many',
  '💐': '~flower:#f472b6:#facc15:many',
  '🕊️': '~bird:#e7e5e4:#94a3b8',
  '🐦': '~bird:#a67c52:#6b4423',
  '🦅': '~bird:#8b6914:#3f2a14',
  '🦢': '~bird:#f8fafc:#64748b:long',
  '🦩': '~bird:#fb7185:#9f1239:long',
  '🦚': '~bird:#166534:#14532d:fan',
  '🦜': '~bird:#22c55e:#1d4ed8',
  '🦉': '~bird:#c4a574:#78350f',
  '🦆': '~bird:#f8fafc:#ea580c',
  '🐓': '~bird:#dc2626:#7f1d1d:crest',
  '🐔': '~bird:#f5f5f4:#a16207',
  '🐥': '~bird:#fde047:#f59e0b',
  '🦃': '~bird:#7c2d12:#44403c:fan',
  '🐧': '~bird:#1f2937:#e2e8f0:long',
  '🐡': '~fish:#f59e0b:#fde68a:spots:round',
  '🐠': '~fish:#fb923c:#38bdf8:stripes',
  '🐟': '~fish:#38bdf8:#1e3a8a',
  '🦈': '~fish:#94a3b8:#475569:plain:long',
  '🦪': '~shell:#f5f5f4:#d6d3d1:clam',
  '🐚': '~shell:#fcd9a8:#d4a574:spiral',
  '🫀': '~organ:#e11d48:#9f1239:liver',
  '🫁': '~organ:#f0a898:#c0614a:stomach',
  '🧠': '~organ:#f0a8b4:#9f1239:kidney',
  '☁️': '~cloud:cumulus',
  '🌤️': '~cloud:cumulus',
  '🍄': '~veg:#e7e5e4:#a8a29e:bulb',
};

type Beast = { b: string; d: string; l: string; f?: string };
const BEAST: Record<string, Beast> = {
  '🐑': { b: '#f5f5f4', d: '#d6d3d1', l: '#fff', f: 'fluff' },
  '🐐': { b: '#d6d3d1', d: '#78716c', l: '#f5f5f4', f: 'horn' },
  '🐄': { b: '#f5f5f4', d: '#44403c', l: '#fff', f: 'spot' },
  '🐃': { b: '#44403c', d: '#1c1917', l: '#78716c', f: 'horn' },
  '🐪': { b: '#d6a56b', d: '#92400e', l: '#f5e6c8', f: 'hump' },
  '🐎': { b: '#92400e', d: '#451a03', l: '#d6a56b' },
  '🐕': { b: '#d6a56b', d: '#78350f', l: '#f5e6c8', f: 'snout' },
  '🐈': { b: '#f5f5f4', d: '#a8a29e', l: '#fff' },
  '🐇': { b: '#f5f5f4', d: '#d6d3d1', l: '#fff', f: 'hop' },
  '🦁': { b: '#d6a56b', d: '#92400e', l: '#f5e6c8', f: 'mane' },
  '🐅': { b: '#f59e0b', d: '#1c1917', l: '#fde68a', f: 'stripe' },
  '🐆': { b: '#d6a56b', d: '#1c1917', l: '#f5e6c8', f: 'spot' },
  '🐻': { b: '#92400e', d: '#451a03', l: '#d6a56b', f: 'snout' },
  '🐺': { b: '#94a3b8', d: '#334155', l: '#e2e8f0', f: 'snout' },
  '🦊': { b: '#ea580c', d: '#9a3412', l: '#fff', f: 'snout' },
  '🦌': { b: '#a16207', d: '#78350f', l: '#f5e6c8', f: 'horn' },
  '🦓': { b: '#f5f5f4', d: '#1c1917', l: '#fff', f: 'stripe' },
  '🦒': { b: '#f59e0b', d: '#92400e', l: '#fde68a', f: 'neck spot' },
  '🐘': { b: '#94a3b8', d: '#475569', l: '#e2e8f0', f: 'trunk' },
  '🦏': { b: '#a8a29e', d: '#57534e', l: '#e7e5e4', f: 'horn' },
  '🦘': { b: '#d6a56b', d: '#92400e', l: '#f5e6c8', f: 'hop' },
  '🐒': { b: '#a16207', d: '#78350f', l: '#f5e6c8' },
  '🐼': { b: '#f5f5f4', d: '#1c1917', l: '#fff', f: 'spot' },
  '🐨': { b: '#a8a29e', d: '#57534e', l: '#e7e5e4', f: 'fluff' },
  '🦇': { b: '#44403c', d: '#1c1917', l: '#a8a29e', f: 'bat' },
  '🐿️': { b: '#d6a56b', d: '#92400e', l: '#fff', f: 'fluff' },
  '🐗': { b: '#78716c', d: '#44403c', l: '#d6d3d1', f: 'snout' },
  '🐻‍❄️': { b: '#f8fafc', d: '#94a3b8', l: '#fff', f: 'snout' },
  '🐍': { b: '#65a30d', d: '#3f6212', l: '#d9f99d', f: 'snake' },
  '🦎': { b: '#84cc16', d: '#3f6212', l: '#ecfccb' },
  '🐢': { b: '#65a30d', d: '#365314', l: '#d9f99d', f: 'shell' },
  '🐸': { b: '#4ade80', d: '#166534', l: '#dcfce7', f: 'hop' },
  '🐊': { b: '#4d7c0f', d: '#365314', l: '#d9f99d', f: 'snout' },
  '🦭': { b: '#94a3b8', d: '#475569', l: '#e2e8f0', f: 'seal' },
  '🐋': { b: '#60a5fa', d: '#1e3a8a', l: '#dbeafe', f: 'whale' },
  '🐳': { b: '#38bdf8', d: '#0369a1', l: '#e0f2fe', f: 'whale' },
  '🐬': { b: '#64748b', d: '#334155', l: '#e2e8f0', f: 'whale' },
  '🐙': { b: '#c084fc', d: '#6b21a8', l: '#f3e8ff', f: 'octo' },
  '🦑': { b: '#f472b6', d: '#9d174d', l: '#fce7f3', f: 'octo' },
  '🦐': { b: '#fb7185', d: '#9f1239', l: '#ffe4e6', f: 'shrimp' },
  '🦀': { b: '#ef4444', d: '#991b1b', l: '#fecaca', f: 'crab' },
  '🦞': { b: '#dc2626', d: '#7f1d1d', l: '#fecaca', f: 'crab' },
};

type Ride = { k: string; c: string; a?: string };
const RIDE: Record<string, Ride> = {
  '🚗': { k: 'car', c: '#1e3a5f' },
  '🚕': { k: 'car', c: '#facc15', a: 'taxi' },
  '🚌': { k: 'bus', c: '#1d4ed8' },
  '🚐': { k: 'bus', c: '#0f766e' },
  '🚚': { k: 'truck', c: '#b45309' },
  '🛻': { k: 'truck', c: '#44403c' },
  '🏍️': { k: 'bike', c: '#1c1917' },
  '🚲': { k: 'bike', c: '#166534', a: 'cycle' },
  '🛴': { k: 'bike', c: '#64748b', a: 'scoot' },
  '🚆': { k: 'train', c: '#1e3a8a' },
  '🚇': { k: 'train', c: '#334155' },
  '🚜': { k: 'truck', c: '#65a30d', a: 'tractor' },
  '🚑': { k: 'bus', c: '#f8fafc', a: 'medic' },
  '🚡': { k: 'cable', c: '#ef4444' },
  '✈️': { k: 'plane', c: '#e2e8f0' },
  '🛩️': { k: 'plane', c: '#f8fafc', a: 'small' },
  '🚁': { k: 'heli', c: '#1e3a5f' },
  '🎈': { k: 'balloon', c: '#ef4444' },
  '🪂': { k: 'chute', c: '#f97316' },
  '🪁': { k: 'kite', c: '#38bdf8' },
  '🛰️': { k: 'sat', c: '#e2e8f0' },
  '🚀': { k: 'rocket', c: '#e2e8f0' },
  '⛵': { k: 'boat', c: '#f8fafc', a: 'sail' },
  '🚢': { k: 'boat', c: '#1e3a5f' },
  '⛴️': { k: 'boat', c: '#334155' },
  '🚤': { k: 'boat', c: '#f8fafc', a: 'speed' },
  '🛶': { k: 'boat', c: '#a16207', a: 'canoe' },
};

type Place = { k: string; w: string; r: string };
const PLACE: Record<string, Place> = {
  '🏠': { k: 'house', w: '#f5e6c8', r: '#9f1239' },
  '🕌': { k: 'mosque', w: '#f5f5f4', r: '#0f766e' },
  '🏫': { k: 'school', w: '#f8fafc', r: '#1d4ed8' },
  '🏥': { k: 'school', w: '#f8fafc', r: '#ef4444' },
  '🏦': { k: 'tower', w: '#e7e5e4', r: '#44403c' },
  '🏢': { k: 'tower', w: '#cbd5e1', r: '#1e3a5f' },
  '🏪': { k: 'shop', w: '#f5e6c8', r: '#b45309' },
  '🍽️': { k: 'shop', w: '#fff7ed', r: '#c2410c' },
  '🥖': { k: 'shop', w: '#fef3c7', r: '#a16207' },
  '💊': { k: 'shop', w: '#f8fafc', r: '#16a34a' },
  '💐': { k: 'shop', w: '#fdf2f8', r: '#db2777' },
  '🍦': { k: 'shop', w: '#fff7ed', r: '#f97316' },
  '⛽': { k: 'shop', w: '#f8fafc', r: '#dc2626' },
  '📮': { k: 'shop', w: '#fef2f2', r: '#b91c1c' },
  '🚒': { k: 'shop', w: '#fee2e2', r: '#dc2626' },
  '🌉': { k: 'bridge', w: '#94a3b8', r: '#334155' },
  '🛣️': { k: 'road', w: '#57534e', r: '#facc15' },
  '🚦': { k: 'signal', w: '#1c1917', r: '#22c55e' },
  '🌆': { k: 'city', w: '#1e293b', r: '#fbbf24' },
  '🏞️': { k: 'park', w: '#4ade80', r: '#166534' },
  '🏊': { k: 'pool', w: '#38bdf8', r: '#0369a1' },
  '📚': { k: 'books', w: '#1e3a8a', r: '#b45309' },
  '✏️': { k: 'books', w: '#f8fafc', r: '#eab308' },
  '👟': { k: 'shop', w: '#f5f5f4', r: '#1e3a5f' },
  '🏋️': { k: 'school', w: '#e7e5e4', r: '#44403c' },
};

const OBJECTS = new Set(['🛏️', '🛋️', '🪑', '🚪', '🪟', '💡', '🚰', '🧊', '🍳', '🧶', '🚿', '🧼', '🔥', '📺', '🔑', '🖊️', '💻', '📱', '🕰️', '👓', '📷', '🔭', '🔬', '🧭', '🌐', '👕', '👖', '🧥', '🧣', '🧤', '👒', '🎒', '⌚', '💍', '🛢️', '🍞', '🫓', '🍚', '🍲', '🥣', '🥛', '🧀', '🧈', '🍯', '🥚', '🍵', '🍖', '🥗', '🍰', '🐝', '🦋', '🐜', '🐞', '🐛', '🦗', '🪲', '🕷️']);

function Backdrop({ theme, id }: { theme: Theme; id: string }) {
  const sky: Record<Theme, [string, string, string]> = {
    sky: ['#7ec8f0', '#1d4e89', '#8fb56a'],
    land: ['#9fd4f0', '#d7ecc0', '#3f7d32'],
    sea: ['#7dd3fc', '#0c4a6e', '#e7d3a1'],
    dusk: ['#312e81', '#fb923c', '#44403c'],
    studio: ['#f7f3ea', '#d9d2c5', '#c4bdb0'],
    warm: ['#f3d2b5', '#7c2d12', '#44403c'],
    night: ['#0b1228', '#1e3a8a', '#1e293b'],
  };
  const [a, b, g] = sky[theme];
  return (
    <>
      <defs>
        <linearGradient id={`bg${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={a} />
          <stop offset="0.62" stopColor={b} />
          <stop offset="1" stopColor={g} />
        </linearGradient>
        <filter id={`gr${id}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" result="n" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
      </defs>
      <rect width="100" height="100" fill={`url(#bg${id})`} />
      {theme === 'sky' && (
        <>
          <circle cx="78" cy="18" r="8" fill="#fff7d6" opacity="0.9" />
          <ellipse cx="28" cy="24" rx="14" ry="6" fill="#fff" opacity="0.75" />
          <ellipse cx="40" cy="26" rx="10" ry="5" fill="#fff" opacity="0.8" />
        </>
      )}
      {theme === 'sea' && (
        <>
          <path d="M0 18C20 10 30 26 50 18C70 10 80 26 100 16V0H0Z" fill="#e0f2fe" opacity="0.35" />
          <path d="M20 0L28 70" stroke="#fff" strokeWidth="1.2" opacity="0.25" />
          <path d="M48 0L58 78" stroke="#fff" strokeWidth="1.6" opacity="0.2" />
          <path d="M74 0L70 64" stroke="#fff" strokeWidth="1" opacity="0.22" />
        </>
      )}
      {theme === 'night' && [12, 28, 46, 70, 88].map((x, i) => <circle key={x} cx={x} cy={10 + (i % 3) * 8} r="0.7" fill="#fff" opacity="0.8" />)}
      {(theme === 'land' || theme === 'sky' || theme === 'dusk') && <path d="M0 78C22 68 40 84 62 74C80 66 90 80 100 72V100H0Z" fill={g} opacity="0.55" />}
      <rect width="100" height="100" filter={`url(#gr${id})`} opacity="0.07" />
    </>
  );
}

function BeastDraw({ s }: { s: Beast }) {
  const feat = s.f || '';
  const neck = feat.includes('neck');
  const whale = feat.includes('whale') || feat.includes('seal');
  const snake = feat.includes('snake');
  const octo = feat.includes('octo');
  const crab = feat.includes('crab');
  const shrimp = feat.includes('shrimp');
  if (snake) {
    return (
      <g>
        <path d="M18 70C28 52 40 74 52 58C64 42 72 64 84 50" fill="none" stroke={s.d} strokeWidth="9" strokeLinecap="round" />
        <path d="M18 70C28 52 40 74 52 58C64 42 72 64 84 50" fill="none" stroke={s.b} strokeWidth="6" strokeLinecap="round" />
        <circle cx="84" cy="50" r="5" fill={s.b} />
        <circle cx="86" cy="48.5" r="1" fill="#111" />
      </g>
    );
  }
  if (octo) {
    return (
      <g>
        <ellipse cx="50" cy="40" rx="18" ry="14" fill={s.b} />
        <ellipse cx="50" cy="36" rx="10" ry="6" fill={s.l} opacity="0.45" />
        {[18, 30, 42, 54, 66, 78].map((x, i) => (
          <path key={x} d={`M${x} 50C${x - 6} 66 ${x + 8} 74 ${x} 88`} stroke={i % 2 ? s.d : s.b} strokeWidth="4.2" fill="none" strokeLinecap="round" />
        ))}
        <circle cx="44" cy="38" r="1.6" fill="#111" />
        <circle cx="56" cy="38" r="1.6" fill="#111" />
      </g>
    );
  }
  if (crab) {
    return (
      <g>
        <ellipse cx="50" cy="58" rx="22" ry="14" fill={s.b} />
        <path d="M28 52C14 40 16 28 26 30" stroke={s.d} strokeWidth="3.4" fill="none" />
        <path d="M72 52C86 40 84 28 74 30" stroke={s.d} strokeWidth="3.4" fill="none" />
        <circle cx="26" cy="30" r="5" fill={s.d} />
        <circle cx="74" cy="30" r="5" fill={s.d} />
        {[0, 1, 2].map((i) => (
          <path key={i} d={`M${36 + i * 8} 70l-3 10M${58 + i * 6} 70l3 10`} stroke={s.d} strokeWidth="2.2" strokeLinecap="round" />
        ))}
        <circle cx="43" cy="54" r="1.5" fill="#111" />
        <circle cx="57" cy="54" r="1.5" fill="#111" />
      </g>
    );
  }
  if (shrimp) {
    return (
      <g>
        <path d="M22 62C34 40 62 36 78 48C70 58 50 62 36 70C28 74 22 70 22 62Z" fill={s.b} />
        <path d="M22 62C18 52 24 46 30 48" stroke={s.d} strokeWidth="2" fill="none" />
        <circle cx="70" cy="46" r="1.4" fill="#111" />
      </g>
    );
  }
  if (whale) {
    return (
      <g>
        <ellipse cx="52" cy="58" rx="30" ry="14" fill={s.b} />
        <path d="M78 52L94 40L90 58Z" fill={s.d} />
        <ellipse cx="34" cy="52" rx="8" ry="4" fill={s.l} opacity="0.35" />
        <circle cx="30" cy="54" r="1.6" fill="#111" />
        <path d="M48 46C52 34 60 36 58 46" fill={s.d} opacity="0.7" />
      </g>
    );
  }
  const hy = neck ? 34 : 48;
  return (
    <g>
      <ellipse cx="54" cy="86" rx="26" ry="4" fill="#000" opacity="0.18" />
      {feat.includes('bat') && <path d="M20 40C8 28 18 18 34 36C46 18 78 16 86 34C70 30 58 40 50 42C40 36 28 30 20 40Z" fill={s.d} />}
      {!feat.includes('bat') && (
        <>
          <path d="M40 78V62M50 80V60M62 78V62M72 76V64" stroke={s.d} strokeWidth="3.2" strokeLinecap="round" />
          <ellipse cx="58" cy="60" rx="24" ry="14" fill={s.b} />
          <ellipse cx="58" cy="64" rx="16" ry="7" fill={s.l} opacity="0.35" />
        </>
      )}
      {feat.includes('mane') && <circle cx="30" cy="46" r="16" fill={s.d} />}
      {neck && <path d="M40 58C36 40 34 28 30 18" stroke={s.b} strokeWidth="7" strokeLinecap="round" />}
      {feat.includes('hump') && <ellipse cx="62" cy="46" rx="10" ry="7" fill={s.b} />}
      {feat.includes('trunk') && (
        <>
          <path d="M24 58C18 70 22 80 30 78" stroke={s.b} strokeWidth="4" fill="none" strokeLinecap="round" />
          <ellipse cx="22" cy="46" rx="8" ry="10" fill={s.b} />
        </>
      )}
      <ellipse cx={neck ? 28 : 30} cy={hy} rx="11" ry="9" fill={s.b} />
      <ellipse cx={neck ? 24 : 26} cy={hy + 2} rx="4" ry="3" fill={s.l} opacity="0.7" />
      {feat.includes('horn') && <path d={`M${neck ? 26 : 28} ${hy - 8}l-2-10M${neck ? 32 : 34} ${hy - 8}l4-9`} stroke={s.d} strokeWidth="1.8" strokeLinecap="round" />}
      {feat.includes('hop') && <ellipse cx="22" cy={hy - 8} rx="3" ry="8" fill={s.b} />}
      {feat.includes('fluff') && <circle cx="30" cy={hy} r="13" fill={s.l} opacity="0.55" />}
      <circle cx={neck ? 26 : 28} cy={hy - 1} r="1.5" fill="#111" />
      <circle cx={neck ? 26.6 : 28.6} cy={hy - 1.5} r="0.5" fill="#fff" />
      {feat.includes('stripe') && [48, 58, 68].map((x) => <path key={x} d={`M${x} 50c2 8 2 16 0 22`} stroke={s.d} strokeWidth="2.2" fill="none" />)}
      {feat.includes('spot') && [46, 58, 68, 54].map((x, i) => <circle key={x} cx={x} cy={54 + (i % 2) * 8} r="2.2" fill={s.d} opacity="0.8" />)}
      {feat.includes('shell') && <ellipse cx="58" cy="56" rx="16" ry="11" fill={s.d} />}
      <path d="M78 58C90 52 92 68 80 66" stroke={s.d} strokeWidth="2.4" fill="none" strokeLinecap="round" />
    </g>
  );
}

function RideDraw({ s }: { s: Ride }) {
  const wheel = (x: number, y: number, r = 7) => (
    <g key={x}>
      <circle cx={x} cy={y} r={r} fill="#1c1917" />
      <circle cx={x} cy={y} r={r - 2.4} fill="#d6d3d1" />
      <circle cx={x} cy={y} r="1.3" fill="#44403c" />
    </g>
  );
  if (s.k === 'plane') {
    const small = s.a === 'small';
    return (
      <g>
        <ellipse cx="54" cy="78" rx="22" ry="3" fill="#000" opacity="0.12" />
        <path d="M16 52H78L90 48L78 56H16Z" fill={s.c} />
        <path d="M40 52L28 34H40L52 52Z" fill="#94a3b8" />
        <path d="M48 56L36 72H46L56 56Z" fill="#94a3b8" />
        <path d="M78 48L92 40V56L78 56Z" fill="#64748b" />
        {!small && [24, 34, 46, 58].map((x) => <rect key={x} x={x} y="49" width="6" height="3.2" rx="1" fill="#bae6fd" />)}
        <path d="M20 50H70" stroke="#fff" strokeWidth="1" opacity="0.45" />
      </g>
    );
  }
  if (s.k === 'heli') {
    return (
      <g>
        <ellipse cx="48" cy="62" rx="22" ry="10" fill={s.c} />
        <rect x="40" y="40" width="14" height="14" rx="3" fill="#cbd5e1" />
        <path d="M14 38H82" stroke="#334155" strokeWidth="2" />
        <path d="M48 40V30" stroke="#334155" strokeWidth="2" />
        <path d="M66 58H86L82 64H66Z" fill={s.c} />
      </g>
    );
  }
  if (s.k === 'rocket') {
    return (
      <g>
        <path d="M50 12C62 28 66 48 62 78H38C34 48 38 28 50 12Z" fill={s.c} />
        <path d="M38 62L26 78H40Z" fill="#ef4444" />
        <path d="M62 62L74 78H60Z" fill="#ef4444" />
        <circle cx="50" cy="40" r="5" fill="#7dd3fc" />
        <path d="M44 78L50 92L56 78" fill="#f59e0b" />
      </g>
    );
  }
  if (s.k === 'balloon') return <g><ellipse cx="50" cy="40" rx="18" ry="24" fill={s.c} /><path d="M50 64V82" stroke="#444" strokeWidth="1" /><rect x="42" y="82" width="16" height="8" rx="2" fill="#a16207" /></g>;
  if (s.k === 'chute') return <g><path d="M16 36C24 16 76 16 84 36Z" fill={s.c} /><path d="M16 36L50 72L84 36" fill="none" stroke="#444" strokeWidth="1" /><circle cx="50" cy="76" r="4" fill="#1c1917" /></g>;
  if (s.k === 'kite') return <g><path d="M50 16L78 48L50 84L22 48Z" fill={s.c} /><path d="M50 16V84M22 48H78" stroke="#fff" strokeWidth="1" opacity="0.6" /><path d="M50 84C58 90 62 86 66 94" stroke="#ef4444" fill="none" /></g>;
  if (s.k === 'sat') return <g><rect x="40" y="40" width="20" height="16" rx="2" fill={s.c} /><rect x="8" y="42" width="28" height="12" fill="#38bdf8" /><rect x="64" y="42" width="28" height="12" fill="#38bdf8" /><circle cx="50" cy="36" r="3" fill="#fbbf24" /></g>;
  if (s.k === 'cable') return <g><path d="M8 28C30 18 70 18 92 28" stroke="#444" strokeWidth="1.4" fill="none" /><rect x="40" y="36" width="20" height="14" rx="3" fill={s.c} /><path d="M50 28V36" stroke="#444" /></g>;
  if (s.k === 'boat') {
    if (s.a === 'sail') return <g><path d="M24 66H78L70 78H32Z" fill="#a16207" /><path d="M50 24V66" stroke="#444" strokeWidth="2" /><path d="M50 26L72 60H50Z" fill={s.c} /></g>;
    if (s.a === 'canoe') return <g><path d="M16 62C30 78 70 78 84 62C70 70 30 70 16 62Z" fill={s.c} /><path d="M30 58L70 50" stroke="#444" strokeWidth="2" /></g>;
    if (s.a === 'speed') return <g><path d="M18 60H82L74 72H30Z" fill={s.c} stroke="#94a3b8" />{wheel(0, 0, 0)}<path d="M24 60C40 48 60 50 78 58" stroke="#38bdf8" strokeWidth="2" fill="none" /></g>;
    return <g><path d="M12 62H88L80 80H20Z" fill={s.c} /><rect x="28" y="46" width="40" height="16" rx="2" fill="#e2e8f0" /><rect x="34" y="50" width="8" height="6" fill="#7dd3fc" /><rect x="48" y="50" width="8" height="6" fill="#7dd3fc" /></g>;
  }
  if (s.k === 'bike') {
    return (
      <g>
        {wheel(28, 68, 10)}
        {wheel(72, 68, 10)}
        <path d="M28 68L46 42H64L72 68M46 42L58 68L28 68" stroke={s.c} strokeWidth="2.4" fill="none" />
        {s.a !== 'cycle' && s.a !== 'scoot' && <rect x="40" y="36" width="16" height="8" rx="2" fill="#334155" />}
      </g>
    );
  }
  if (s.k === 'train') {
    return (
      <g>
        <rect x="10" y="40" width="80" height="28" rx="6" fill={s.c} />
        {[20, 36, 52, 68].map((x) => <rect key={x} x={x} y="46" width="10" height="10" rx="1.5" fill="#bae6fd" />)}
        {wheel(24, 72, 5)}
        {wheel(76, 72, 5)}
        <rect x="8" y="36" width="18" height="6" rx="2" fill="#fbbf24" />
      </g>
    );
  }
  const bus = s.k === 'bus';
  const truck = s.k === 'truck';
  return (
    <g>
      <ellipse cx="50" cy="80" rx="30" ry="3.5" fill="#000" opacity="0.16" />
      {truck ? (
        <>
          <path d="M14 58H52V40H28L14 52Z" fill={s.c} />
          <rect x="52" y="46" width="32" height="18" rx="2" fill={s.a === 'tractor' ? '#365314' : '#44403c'} />
          <path d="M30 42H48V52H22Z" fill="#bae6fd" />
        </>
      ) : (
        <path d={`M16 ${bus ? 36 : 46}H78C84 ${bus ? 36 : 46} 86 52 84 62H16C12 62 12 ${bus ? 42 : 50} 16 ${bus ? 36 : 46}Z`} fill={s.c} />
      )}
      {!truck && [24, 38, 52, 66].slice(0, bus ? 4 : 2).map((x) => <rect key={x} x={x} y={bus ? 42 : 50} width={bus ? 10 : 14} height="8" rx="1.5" fill="#dbeafe" />)}
      {s.a === 'medic' && <path d="M46 44H54V48H58V54H54V58H46V54H42V48H46Z" fill="#ef4444" />}
      {s.a === 'taxi' && <rect x="40" y="40" width="16" height="4" rx="1" fill="#1c1917" />}
      <path d="M20 52H70" stroke="#fff" strokeWidth="1.4" opacity="0.35" />
      {wheel(30, 68)}
      {wheel(70, 68)}
      <circle cx="80" cy={bus ? 48 : 54} r="2" fill="#fde68a" />
    </g>
  );
}

function PlaceDraw({ s }: { s: Place }) {
  if (s.k === 'road') return <g><path d="M10 90L40 40H60L90 90Z" fill="#57534e" /><path d="M50 48V84" stroke="#facc15" strokeWidth="2" strokeDasharray="4 3" /></g>;
  if (s.k === 'signal') return <g><rect x="46" y="28" width="8" height="58" fill="#444" /><rect x="36" y="16" width="28" height="40" rx="4" fill="#1c1917" /><circle cx="50" cy="26" r="4" fill="#ef4444" /><circle cx="50" cy="36" r="4" fill="#facc15" /><circle cx="50" cy="46" r="4" fill="#22c55e" /></g>;
  if (s.k === 'bridge') return <g><path d="M8 62C28 40 72 40 92 62" stroke={s.r} strokeWidth="4" fill="none" /><path d="M8 70H92" stroke={s.w} strokeWidth="6" /><path d="M20 70V88M50 70V88M80 70V88" stroke={s.w} strokeWidth="3" /></g>;
  if (s.k === 'park') return <g><ellipse cx="50" cy="78" rx="36" ry="8" fill="#166534" /><circle cx="34" cy="58" r="12" fill="#22c55e" /><circle cx="52" cy="50" r="14" fill="#16a34a" /><circle cx="68" cy="58" r="11" fill="#4ade80" /><rect x="48" y="64" width="5" height="16" fill="#78350f" /></g>;
  if (s.k === 'pool') return <g><rect x="16" y="36" width="68" height="40" rx="6" fill="#e2e8f0" /><rect x="22" y="42" width="56" height="28" rx="3" fill={s.w} /><path d="M26 54H74" stroke="#fff" strokeWidth="1.4" opacity="0.6" /></g>;
  if (s.k === 'books') return <g><rect x="22" y="28" width="14" height="48" rx="1" fill="#1d4ed8" /><rect x="38" y="34" width="16" height="42" rx="1" fill="#b45309" /><rect x="56" y="30" width="14" height="46" rx="1" fill="#166534" /><path d="M24 36H34M40 44H52" stroke="#fff" strokeWidth="1" opacity="0.5" /></g>;
  if (s.k === 'city') {
    return (
      <g>
        {[18, 36, 54, 72].map((x, i) => (
          <g key={x}>
            <rect x={x} y={30 + (i % 2) * 10} width="16" height={60 - (i % 2) * 10} fill={i % 2 ? '#1e293b' : '#334155'} />
            {[0, 1, 2, 3].map((r) => <rect key={r} x={x + 3} y={38 + (i % 2) * 10 + r * 10} width="4" height="4" fill="#fbbf24" opacity="0.85" />)}
          </g>
        ))}
      </g>
    );
  }
  if (s.k === 'mosque') {
    return (
      <g>
        <rect x="22" y="48" width="56" height="32" fill={s.w} />
        <path d="M22 48C22 30 78 30 78 48" fill={s.r} />
        <circle cx="50" cy="34" r="4" fill="#fbbf24" />
        <rect x="16" y="28" width="8" height="52" fill={s.w} />
        <path d="M16 28C16 16 24 16 24 28" fill={s.r} />
        <rect x="44" y="58" width="12" height="22" fill={s.r} />
      </g>
    );
  }
  const h = s.k === 'tower' ? 24 : s.k === 'school' ? 34 : 40;
  return (
    <g>
      <ellipse cx="50" cy="88" rx="28" ry="4" fill="#000" opacity="0.12" />
      <rect x="24" y={h + 8} width="52" height={72 - h} fill={s.w} />
      {s.k === 'house' ? <path d={`M18 ${h + 10}L50 ${h - 8}L82 ${h + 10}Z`} fill={s.r} /> : <rect x="24" y={h} width="52" height="10" fill={s.r} />}
      {[0, 1].map((c) => [0, 1].map((r) => <rect key={`${c}${r}`} x={32 + c * 18} y={h + 16 + r * 14} width="10" height="8" rx="1" fill="#7dd3fc" />))}
      <rect x="44" y="68" width="12" height="16" fill={s.r} />
    </g>
  );
}

function ObjectDraw({ e }: { e: string }) {
  const box = (node: ReactNode) => (
    <g>
      <ellipse cx="50" cy="84" rx="18" ry="3.5" fill="#000" opacity="0.12" />
      {node}
      <ellipse cx="40" cy="40" rx="8" ry="3" fill="#fff" opacity="0.28" />
    </g>
  );
  switch (e) {
    case '🛏️': return box(<><rect x="18" y="48" width="64" height="22" rx="4" fill="#e2e8f0" /><rect x="22" y="40" width="16" height="12" rx="2" fill="#f8fafc" /><rect x="16" y="44" width="6" height="28" fill="#a16207" /></>);
    case '🛋️': return box(<><rect x="16" y="50" width="68" height="20" rx="6" fill="#7c2d12" /><rect x="24" y="44" width="18" height="12" rx="3" fill="#9a3412" /><rect x="46" y="44" width="18" height="12" rx="3" fill="#9a3412" /></>);
    case '🪑': return box(<><rect x="30" y="36" width="28" height="8" rx="2" fill="#a16207" /><rect x="34" y="44" width="4" height="28" fill="#78350f" /><rect x="52" y="44" width="4" height="28" fill="#78350f" /></>);
    case '🚪': return box(<><rect x="32" y="22" width="36" height="60" rx="2" fill="#a16207" /><circle cx="60" cy="54" r="2" fill="#fbbf24" /></>);
    case '🪟': return box(<><rect x="24" y="24" width="52" height="44" rx="2" fill="#bae6fd" stroke="#444" strokeWidth="3" /><path d="M50 24V68M24 46H76" stroke="#444" strokeWidth="2" /></>);
    case '💡': return box(<><circle cx="50" cy="40" r="14" fill="#fde68a" /><rect x="44" y="52" width="12" height="8" fill="#a8a29e" /><path d="M40 28C46 22 56 22 60 30" stroke="#fff" strokeWidth="2" fill="none" /></>);
    case '🚰': return box(<><path d="M36 24H64V36H56V70H44V36H36Z" fill="#94a3b8" /><path d="M48 70C48 78 56 78 56 70" stroke="#38bdf8" strokeWidth="2" fill="none" /></>);
    case '🧊': return box(<><rect x="28" y="30" width="44" height="48" rx="3" fill="#e2e8f0" /><rect x="34" y="38" width="14" height="18" fill="#bae6fd" /></>);
    case '🍳': return box(<><ellipse cx="46" cy="58" rx="24" ry="10" fill="#444" /><ellipse cx="46" cy="54" rx="16" ry="7" fill="#fde68a" /><circle cx="48" cy="54" r="4" fill="#f59e0b" /></>);
    case '🧶': return box(<><ellipse cx="50" cy="58" rx="22" ry="14" fill="#b45309" /><path d="M36 54C46 48 58 64 68 56" stroke="#f5e6c8" strokeWidth="1.4" fill="none" /></>);
    case '🚿': return box(<><path d="M40 20H60V28H40Z" fill="#94a3b8" />{[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${38 + i * 6} 30v16`} stroke="#7dd3fc" strokeWidth="1.6" />)}</>);
    case '🧼': return box(<><rect x="28" y="40" width="44" height="26" rx="8" fill="#fbcfe8" /><ellipse cx="42" cy="48" rx="8" ry="4" fill="#fff" opacity="0.5" /></>);
    case '🔥': return box(<><path d="M50 18C62 36 70 40 66 58C62 74 38 76 34 58C30 42 40 36 50 18Z" fill="#f97316" /><path d="M50 36C56 46 58 50 54 62C48 54 46 48 50 36Z" fill="#fde68a" /></>);
    case '📺': return box(<><rect x="20" y="30" width="60" height="40" rx="3" fill="#1e293b" /><rect x="26" y="36" width="48" height="28" fill="#38bdf8" /></>);
    case '🔑': return box(<><circle cx="38" cy="44" r="10" fill="#fbbf24" /><circle cx="38" cy="44" r="4" fill="#fff" /><rect x="46" y="42" width="26" height="5" fill="#fbbf24" /></>);
    case '🖊️': return box(<><rect x="46" y="18" width="8" height="58" rx="2" fill="#1e3a8a" transform="rotate(18 50 48)" /><path d="M58 72L50 84L46 70" fill="#fbbf24" /></>);
    case '💻': return box(<><rect x="22" y="32" width="56" height="36" rx="2" fill="#1e293b" /><rect x="26" y="36" width="48" height="26" fill="#38bdf8" /><path d="M16 70H84" stroke="#94a3b8" strokeWidth="3" /></>);
    case '📱': return box(<><rect x="36" y="18" width="28" height="52" rx="4" fill="#1e293b" /><rect x="40" y="24" width="20" height="36" fill="#38bdf8" /></>);
    case '🕰️': case '⌚': return box(<><circle cx="50" cy="50" r="22" fill="#f5f5f4" stroke="#a16207" strokeWidth="4" /><path d="M50 36V50L60 58" stroke="#1c1917" strokeWidth="2" /></>);
    case '👓': return box(<><circle cx="36" cy="52" r="12" fill="none" stroke="#1e293b" strokeWidth="3" /><circle cx="64" cy="52" r="12" fill="none" stroke="#1e293b" strokeWidth="3" /><path d="M48 52H52" stroke="#1e293b" strokeWidth="3" /></>);
    case '📷': return box(<><rect x="22" y="36" width="56" height="36" rx="4" fill="#1e293b" /><circle cx="50" cy="54" r="10" fill="#38bdf8" /><rect x="36" y="28" width="16" height="8" fill="#334155" /></>);
    case '🔭': return box(<><rect x="28" y="40" width="48" height="12" rx="6" fill="#444" transform="rotate(-28 50 48)" /><rect x="46" y="52" width="6" height="28" fill="#78350f" /></>);
    case '🔬': return box(<><rect x="46" y="20" width="8" height="36" fill="#94a3b8" /><circle cx="50" cy="62" r="10" fill="#7dd3fc" /><rect x="30" y="74" width="40" height="6" rx="2" fill="#444" /></>);
    case '🧭': return box(<><circle cx="50" cy="52" r="22" fill="#f5f5f4" stroke="#a16207" strokeWidth="3" /><path d="M50 34L56 52L50 70L44 52Z" fill="#ef4444" /></>);
    case '🌐': return box(<><circle cx="50" cy="52" r="22" fill="#38bdf8" /><ellipse cx="50" cy="52" rx="10" ry="22" fill="none" stroke="#fff" /><path d="M28 52H72M34 40H66M34 64H66" stroke="#fff" fill="none" /></>);
    case '👕': return box(<path d="M34 28L50 36L66 28L78 40L66 48V78H34V48L22 40Z" fill="#3b82f6" />);
    case '👖': return box(<path d="M32 24H68V48L60 80H48L50 48L40 80H28Z" fill="#1e3a8a" />);
    case '🧥': return box(<path d="M30 26L50 34L70 26L82 42L68 50V80H32V50L18 42Z" fill="#44403c" />);
    case '🧣': return box(<path d="M30 30H70V42H58V78H44V42H30Z" fill="#dc2626" />);
    case '🧤': return box(<path d="M36 40V70H64V48C64 36 52 34 50 44V36C50 28 40 28 40 38V44C36 34 28 38 36 40Z" fill="#a16207" />);
    case '👒': return box(<><ellipse cx="50" cy="62" rx="28" ry="8" fill="#f5e6c8" /><path d="M34 62C34 40 66 40 66 62" fill="#fbcfe8" /></>);
    case '🎒': return box(<><rect x="30" y="32" width="40" height="44" rx="6" fill="#1d4ed8" /><path d="M38 32C38 20 62 20 62 32" fill="none" stroke="#1e3a8a" strokeWidth="4" /></>);
    case '💍': return box(<><circle cx="50" cy="54" r="14" fill="none" stroke="#fbbf24" strokeWidth="5" /><circle cx="50" cy="38" r="4" fill="#38bdf8" /></>);
    case '🛢️': return box(<><rect x="34" y="28" width="32" height="48" rx="4" fill="#1c1917" /><rect x="38" y="22" width="24" height="8" fill="#444" /></>);
    case '🍞': case '🫓': return box(<><rect x="22" y="40" width="56" height="28" rx="10" fill="#d6a56b" /><path d="M30 48H70" stroke="#a16207" strokeWidth="1" /></>);
    case '🍚': return box(<><path d="M24 46H76L68 74H32Z" fill="#f5f5f4" /><ellipse cx="50" cy="50" rx="18" ry="6" fill="#fff" /></>);
    case '🍲': case '🥣': return box(<><path d="M22 46H78L70 72H30Z" fill="#b45309" /><ellipse cx="50" cy="46" rx="24" ry="8" fill="#ea580c" /></>);
    case '🥛': return box(<><path d="M36 28H64L60 76H40Z" fill="#f8fafc" /><rect x="36" y="28" width="28" height="8" fill="#e2e8f0" /></>);
    case '🧀': return box(<path d="M24 68L50 28L76 68Z" fill="#fde68a" />);
    case '🧈': return box(<rect x="26" y="40" width="48" height="26" rx="3" fill="#fde68a" />);
    case '🍯': return box(<><rect x="32" y="36" width="36" height="36" rx="4" fill="#fbbf24" /><rect x="40" y="28" width="20" height="8" rx="2" fill="#a16207" /></>);
    case '🥚': return box(<ellipse cx="50" cy="54" rx="16" ry="22" fill="#f5f5f4" />);
    case '🍵': return box(<><path d="M28 40H68L62 72H34Z" fill="#f5f5f4" /><path d="M68 46H78C84 46 84 62 76 62H66" fill="none" stroke="#d6d3d1" strokeWidth="3" /></>);
    case '🍖': return box(<><ellipse cx="42" cy="58" rx="18" ry="12" fill="#ef4444" /><rect x="52" y="40" width="8" height="28" rx="3" fill="#f5f5f4" transform="rotate(30 56 54)" /></>);
    case '🥗': return box(<><path d="M22 50H78L70 74H30Z" fill="#e2e8f0" /><circle cx="40" cy="52" r="6" fill="#22c55e" /><circle cx="54" cy="48" r="7" fill="#4ade80" /><circle cx="64" cy="54" r="5" fill="#ef4444" /></>);
    case '🍰': return box(<><path d="M24 46H76L70 74H30Z" fill="#fbcfe8" /><rect x="24" y="40" width="52" height="8" fill="#f9a8d4" /><circle cx="50" cy="36" r="4" fill="#ef4444" /></>);
    case '🐝': return box(<><ellipse cx="50" cy="54" rx="14" ry="10" fill="#facc15" /><path d="M40 50H60M40 56H60" stroke="#1c1917" /><ellipse cx="36" cy="46" rx="8" ry="4" fill="#e0f2fe" opacity="0.8" /></>);
    case '🦋': return box(<><ellipse cx="36" cy="48" rx="14" ry="18" fill="#a78bfa" /><ellipse cx="64" cy="48" rx="14" ry="18" fill="#818cf8" /><rect x="47" y="36" width="6" height="28" rx="3" fill="#1c1917" /></>);
    case '🐜': return box(<><circle cx="36" cy="58" r="6" fill="#1c1917" /><circle cx="50" cy="54" r="5" fill="#1c1917" /><circle cx="62" cy="50" r="4" fill="#1c1917" /></>);
    case '🐞': return box(<><ellipse cx="50" cy="56" rx="16" ry="12" fill="#ef4444" /><path d="M50 44V68" stroke="#1c1917" /><circle cx="50" cy="40" r="6" fill="#1c1917" /></>);
    case '🐛': return box(<><ellipse cx="50" cy="58" rx="22" ry="10" fill="#84cc16" /><circle cx="28" cy="54" r="6" fill="#65a30d" /></>);
    case '🦗': return box(<><ellipse cx="50" cy="58" rx="16" ry="8" fill="#65a30d" /><path d="M34 52L24 36M66 52L76 36" stroke="#3f6212" strokeWidth="2" /></>);
    case '🪲': return box(<><ellipse cx="50" cy="56" rx="16" ry="14" fill="#166534" /><ellipse cx="50" cy="52" rx="8" ry="6" fill="#22c55e" opacity="0.5" /></>);
    case '🕷️': return box(<><circle cx="50" cy="52" r="8" fill="#1c1917" />{[0, 1, 2, 3].map((i) => <path key={i} d={`M${42 - i} 48L${24} ${36 + i * 8}M${58 + i} 48L${76} ${36 + i * 8}`} stroke="#1c1917" strokeWidth="1.6" />)}</>);
    default: return <circle cx="50" cy="54" r="16" fill="#d6d3d1" />;
  }
}

function SkyDraw({ e }: { e: string }) {
  if (e === '☀️') return <g><circle cx="50" cy="50" r="16" fill="#fde68a" /><circle cx="50" cy="50" r="16" fill="url(#none)" />{[0, 45, 90, 135].map((a) => <line key={a} x1="50" y1="26" x2="50" y2="14" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" transform={`rotate(${a} 50 50)`} />)}<ellipse cx="44" cy="44" rx="5" ry="3" fill="#fff" opacity="0.55" /></g>;
  if (e === '🌕' || e === '🌙' || e === '🌑' || e === '🌘' || e === '🌖') {
    return <g><circle cx="50" cy="50" r="18" fill={e === '🌑' ? '#334155' : '#f5f5f4'} /><circle cx="44" cy="44" r="3" fill="#d6d3d1" /><circle cx="56" cy="54" r="4" fill="#e7e5e4" />{e === '🌙' && <circle cx="58" cy="46" r="14" fill="#1d4e89" />}{e === '🌘' && <circle cx="60" cy="50" r="14" fill="#1d4e89" />}</g>;
  }
  if (e === '⭐' || e === '🌠') return <g><path d="M50 18L56 40H78L60 52L66 74L50 60L34 74L40 52L22 40H44Z" fill="#fde68a" />{e === '🌠' && <path d="M50 60L20 88" stroke="#fff" strokeWidth="2" opacity="0.7" />}</g>;
  if (e === '🌌') return <g><path d="M10 70C30 40 50 80 70 46C82 28 90 50 96 40" stroke="#e0e7ff" strokeWidth="8" fill="none" opacity="0.7" />{[20, 40, 60, 78].map((x) => <circle key={x} cx={x} cy={30 + (x % 17)} r="1" fill="#fff" />)}</g>;
  if (e === '☄️') return <g><ellipse cx="62" cy="40" rx="10" ry="8" fill="#d6d3d1" /><path d="M54 46L16 78" stroke="#fb923c" strokeWidth="4" opacity="0.8" /></g>;
  if (e === '💨' || e === '🌬️' || e === '🍃') return <g>{[30, 44, 58].map((y, i) => <path key={y} d={`M16 ${y}H${70 - i * 8}`} stroke="#fff" strokeWidth={3 - i * 0.4} strokeLinecap="round" opacity="0.85" />)}{e === '🍃' && <ellipse cx="62" cy="36" rx="8" ry="4" fill="#4ade80" transform="rotate(-30 62 36)" />}</g>;
  if (e === '🌧️' || e === '❄️' || e === '🧊' || e === '💧') return <g><ellipse cx="40" cy="36" rx="16" ry="10" fill="#fff" /><ellipse cx="58" cy="38" rx="14" ry="9" fill="#e2e8f0" />{(e === '🌧️' ? [28, 40, 52, 64] : []).map((x) => <path key={x} d={`M${x} 50l-3 16`} stroke="#7dd3fc" strokeWidth="1.6" />)}{e === '❄️' && <path d="M50 46V78M36 52L64 72M36 72L64 52" stroke="#fff" strokeWidth="2" />}{e === '💧' && <path d="M50 44C62 60 62 74 50 80C38 74 38 60 50 44Z" fill="#38bdf8" />}{e === '🧊' && <rect x="36" y="48" width="28" height="24" rx="3" fill="#e0f2fe" stroke="#fff" />}</g>;
  if (e === '⚡') return <path d="M54 16L34 52H48L42 84L70 42H54L62 16Z" fill="#fde047" />;
  if (e === '🌈') return <g>{[28, 22, 16].map((r, i) => <path key={r} d={`M${18 + i * 4} 70A${r} ${r} 0 0 1 ${82 - i * 4} 70`} fill="none" stroke={['#ef4444', '#facc15', '#22c55e'][i]} strokeWidth="4" />)}</g>;
  if (e === '🍁') return <path d="M50 20C70 30 78 50 62 70C50 60 40 78 36 84C40 64 28 50 18 48C34 40 36 28 50 20Z" fill="#ea580c" />;
  if (e === '🌅' || e === '🌇') return <g><circle cx="50" cy="62" r="16" fill="#f97316" /><path d="M0 66H100V100H0Z" fill={e === '🌇' ? '#7c2d12' : '#166534'} opacity="0.85" /><path d="M0 66C20 58 40 74 70 62C84 56 92 64 100 60V66Z" fill="#fb923c" opacity="0.5" /></g>;
  if (e === '🌃') return <g>{[18, 36, 54, 74].map((x, i) => <rect key={x} x={x} y={40 + (i % 2) * 8} width="12" height="40" fill="#1e293b" />)}{[22, 40, 60, 80, 30].map((x, i) => <circle key={x} cx={x} cy={16 + (i % 3) * 6} r="1" fill="#fff" />)}</g>;
  return <circle cx="50" cy="48" r="14" fill="#fde68a" />;
}

function LandDraw({ e }: { e: string }) {
  if (e === '⛰️' || e === '🏔️' || e === '🗻') return <g><path d="M8 82L36 36L52 58L70 28L94 82Z" fill="#64748b" /><path d="M70 28L58 48L78 46Z" fill="#fff" />{e === '🗻' && <path d="M36 36L32 24L40 30Z" fill="#fff" />}<path d="M0 82H100V100H0Z" fill="#3f7d32" /></g>;
  if (e === '🌋') return <g><path d="M16 82L40 36H60L84 82Z" fill="#57534e" /><path d="M44 36L50 18L56 36" fill="#ef4444" /><ellipse cx="50" cy="20" rx="6" ry="3" fill="#fbbf24" /></g>;
  if (e === '🌾' || e === '🌄') return <g>{[20, 32, 44, 56, 68, 80].map((x) => <path key={x} d={`M${x} 80C${x - 4} 60 ${x + 2} 48 ${x} 36`} stroke="#d6a56b" strokeWidth="2" fill="none" />)}<path d="M0 80H100V100H0Z" fill="#65a30d" /></g>;
  if (e === '🏜️') return <g><path d="M0 70C20 50 30 78 50 58C70 40 80 72 100 52V100H0Z" fill="#e7c27a" /><path d="M0 82C24 70 40 90 70 74C84 66 92 80 100 74V100H0Z" fill="#d4a017" /></g>;
  if (e === '🌳' || e === '🌲') return <g><rect x="46" y="62" width="8" height="22" fill="#78350f" />{e === '🌲' ? <path d="M50 18L78 66H22Z" fill="#166534" /> : <><circle cx="50" cy="46" r="18" fill="#166534" /><circle cx="36" cy="54" r="12" fill="#15803d" /><circle cx="64" cy="54" r="12" fill="#22c55e" /></>}</g>;
  if (e === '🏞️') return <g><path d="M0 80L30 40L46 62L68 34L100 80Z" fill="#64748b" /><path d="M0 72C30 64 40 80 70 68C84 62 92 74 100 66V100H0Z" fill="#38bdf8" /></g>;
  if (e === '💧') return <path d="M50 22C68 46 70 66 50 80C30 66 32 46 50 22Z" fill="#38bdf8" />;
  if (e === '🕳️') return <g><ellipse cx="50" cy="62" rx="28" ry="12" fill="#44403c" /><ellipse cx="50" cy="58" rx="16" ry="6" fill="#1c1917" /></g>;
  if (e === '🧊') return <path d="M20 70L36 36L64 30L82 58L60 82Z" fill="#e0f2fe" stroke="#fff" />;
  if (e === '🏝️') return <g><path d="M0 70H100V100H0Z" fill="#38bdf8" /><ellipse cx="50" cy="68" rx="22" ry="8" fill="#e7c27a" /><rect x="48" y="40" width="4" height="28" fill="#78350f" /><path d="M50 42C70 36 74 52 50 50C30 46 34 34 50 42Z" fill="#166534" /></g>;
  return <circle cx="50" cy="54" r="16" fill="#86efac" />;
}

function BodyDraw({ e }: { e: string }) {
  if (e === '👁️') return <g><ellipse cx="50" cy="52" rx="28" ry="16" fill="#fff" stroke="#d6d3d1" /><circle cx="50" cy="52" r="8" fill="#1d4ed8" /><circle cx="50" cy="52" r="4" fill="#111" /><circle cx="53" cy="49" r="1.6" fill="#fff" /></g>;
  if (e === '👂') return <path d="M58 24C36 24 30 48 36 64C40 76 52 78 56 68V40C62 48 66 44 62 34" fill="#f3d2b5" stroke="#c4a484" />;
  if (e === '👃') return <path d="M50 24C62 40 70 52 62 68C56 76 44 76 38 68C30 52 38 40 50 24Z" fill="#f3d2b5" />;
  if (e === '👅') return <path d="M32 36H68V52C68 74 32 74 32 52Z" fill="#fda4af" />;
  if (e === '🤲' || e === '✋') return <g><path d="M28 48C28 30 40 28 44 40V36C44 26 54 26 54 38V34C54 24 64 26 64 38V42C70 36 78 42 74 52V70H36C30 70 28 60 28 48Z" fill="#f3d2b5" /><path d="M36 70H74" stroke="#e7b89a" /></g>;
  if (e === '🦶') return <path d="M24 48H62C74 48 78 62 70 70H28C20 70 18 56 24 48Z" fill="#f3d2b5" />;
  if (e === '🦴') return <g><rect x="28" y="46" width="44" height="8" rx="4" fill="#f5f5f4" /><circle cx="28" cy="46" r="6" fill="#f5f5f4" /><circle cx="28" cy="54" r="6" fill="#f5f5f4" /><circle cx="72" cy="46" r="6" fill="#f5f5f4" /><circle cx="72" cy="54" r="6" fill="#f5f5f4" /></g>;
  if (e === '💪') return <path d="M30 70C30 40 48 28 62 36C74 42 70 58 58 60C70 64 74 78 58 78H36Z" fill="#f3d2b5" />;
  if (e === '🦷') return <path d="M36 28H64V52C64 70 54 78 50 70C46 78 36 70 36 52Z" fill="#fff" stroke="#e7e5e4" />;
  if (e === '🧍') return <g><circle cx="50" cy="28" r="8" fill="#f3d2b5" /><path d="M38 40H62L66 78H56V92H44V78H34Z" fill="#1e3a8a" /></g>;
  if (e === '🩸') return <path d="M50 22C66 44 68 62 50 78C32 62 34 44 50 22Z" fill="#dc2626" />;
  if (e === '❤️') return <path d="M50 78C28 60 24 40 34 32C42 26 48 32 50 38C52 32 58 26 66 32C76 40 72 60 50 78Z" fill="#e11d48" />;
  if (e === '😊' || e === '😢') return <g><circle cx="50" cy="50" r="22" fill="#f3d2b5" /><circle cx="42" cy="46" r="2" fill="#111" /><circle cx="58" cy="46" r="2" fill="#111" />{e === '😊' ? <path d="M40 56C46 64 54 64 60 56" stroke="#9a3412" fill="none" strokeWidth="2" /> : <path d="M58 40C60 48 58 52 56 56" stroke="#38bdf8" strokeWidth="1.6" />}</g>;
  if (e === '😴') return <g><path d="M30 58C30 40 70 40 70 58V70H30Z" fill="#1e3a8a" /><circle cx="40" cy="36" r="8" fill="#f3d2b5" /><path d="M62 30H78M66 38H80" stroke="#94a3b8" strokeWidth="2" /></g>;
  if (e === '🛡️') return <path d="M50 16L78 28V52C78 70 50 84 50 84C50 84 22 70 22 52V28Z" fill="#1d4ed8" />;
  if (e === '✨' || e === '💭' || e === '🧩' || e === '🗣️' || e === '🌬️') return <g><circle cx="50" cy="50" r="16" fill="#fde68a" opacity="0.9" /><path d="M50 28V36M50 64V72M32 50H40M60 50H68" stroke="#fbbf24" strokeWidth="2" /></g>;
  return <circle cx="50" cy="52" r="16" fill="#f3d2b5" />;
}

const SKY_SET = new Set(['☀️', '🌕', '🌙', '⭐', '💨', '🌬️', '🍃', '🌧️', '❄️', '💧', '⚡', '🌈', '🍁', '🌅', '🌇', '🌃', '🌠', '☄️', '🌌', '🌑', '🌘', '🌖', '🧊']);
const LAND_SET = new Set(['⛰️', '🏔️', '🗻', '🌋', '🌾', '🏜️', '🌳', '🌲', '🌄', '🏞️', '💧', '🕳️', '🧊', '🏝️']);
const BODY_SET = new Set(['👁️', '👂', '👃', '👅', '🤲', '🦴', '💪', '✋', '🦶', '🦷', '🧍', '🗣️', '💭', '🧩', '😴', '😊', '😢', '🛡️', '🌬️', '❤️', '✨', '🩸']);

function themeForEmoji(e: string): Theme {
  if (SKY_SET.has(e)) return e === '🌃' || e === '🌌' ? 'night' : 'sky';
  if (LAND_SET.has(e) || BEAST[e]) return 'land';
  if (['🐋', '🐳', '🐬', '🦈', '🦭', '🐙', '🦑', '🦐', '🦀', '🦞', '🌊', '🏖️'].includes(e)) return 'sea';
  if (RIDE[e] || PLACE[e] || e === '🌆') return 'dusk';
  if (BODY_SET.has(e)) return 'warm';
  return 'studio';
}

function Scene({ e }: { e: string }) {
  if (BEAST[e]) return <BeastDraw s={BEAST[e]} />;
  if (RIDE[e]) return <RideDraw s={RIDE[e]} />;
  if (PLACE[e]) return <PlaceDraw s={PLACE[e]} />;
  if (SKY_SET.has(e)) return <SkyDraw e={e} />;
  if (LAND_SET.has(e)) return <LandDraw e={e} />;
  if (BODY_SET.has(e)) return <BodyDraw e={e} />;
  if (OBJECTS.has(e) || e === '🧊') return <ObjectDraw e={e} />;
  if (e === '🌊' || e === '🏖️') {
    return (
      <g>
        <path d="M0 58C16 50 24 66 40 58C56 50 64 66 80 58C90 52 96 60 100 56V100H0Z" fill="#38bdf8" />
        <path d="M0 70C20 62 30 78 50 68C70 58 80 74 100 64V100H0Z" fill="#0ea5e9" />
        {e === '🏖️' && <path d="M0 78C30 70 60 86 100 74V100H0Z" fill="#e7c27a" />}
      </g>
    );
  }
  return <circle cx="50" cy="54" r="14" fill="#d6d3d1" />;
}

export function AdultArt({ a, size = 64, className }: { a: string; size?: number; className?: string }) {
  const id = useId().replace(/:/g, '');
  const code = a.startsWith('~') ? a : AS_CODE[a];
  const theme = code ? themeOf(code) : themeForEmoji(a);
  return (
    <div className={className} role="img" aria-hidden="true" style={{ position: 'relative', width: size, height: size, overflow: 'hidden', borderRadius: Math.round(size * 0.18) }}>
      <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block' }}>
        <Backdrop theme={theme} id={id} />
        {!code && <Scene e={a} />}
      </svg>
      {code && (
        <div style={{ position: 'absolute', inset: '8%', display: 'grid', placeItems: 'center' }}>
          <Art a={code} size={Math.round(size * 0.78)} />
        </div>
      )}
    </div>
  );
}
