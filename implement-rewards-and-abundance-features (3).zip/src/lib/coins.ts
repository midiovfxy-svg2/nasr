// سکه‌ها: رویداد پرواز، شمارندهٔ «سکه‌های در راه» و صدای سکه
// منطق ذخیرهٔ سکه در پروفایل است (App.awardCoins)؛ این فایل فقط جلوه‌ها را هماهنگ می‌کند.

export interface CoinBurst {
  id: number;
  amount: number;
  count: number;
  x: number;
  y: number;
}

export interface Point {
  x: number;
  y: number;
}

const burstListeners = new Set<(b: CoinBurst) => void>();
const pendingListeners = new Set<() => void>();
const landListeners = new Set<(share: number) => void>();
const soundListeners = new Set<() => void>();
let seq = 0;
let pending = 0;

export const getPending = () => pending;
export function watchPending(fn: () => void) {
  pendingListeners.add(fn);
  return () => {
    pendingListeners.delete(fn);
  };
}
const notifyPending = () => pendingListeners.forEach((fn) => fn());

export function onBurst(fn: (b: CoinBurst) => void) {
  burstListeners.add(fn);
  return () => {
    burstListeners.delete(fn);
  };
}

export function onCoinLand(fn: (share: number) => void) {
  landListeners.add(fn);
  return () => {
    landListeners.delete(fn);
  };
}

// یک سکه به شمارنده رسید
export function landCoin(share: number) {
  pending = Math.max(0, pending - share);
  landListeners.forEach((fn) => fn(share));
  notifyPending();
}

export function resetPending() {
  if (!pending) return;
  pending = 0;
  notifyPending();
}

// ————— محل آخرین لمس: سکه‌ها از همان جایی که کاربر پاسخ داده بیرون می‌ریزند —————
let pointer = { x: 0, y: 0, at: 0 };
if (typeof window !== 'undefined') {
  window.addEventListener(
    'pointerdown',
    (e) => {
      pointer = { x: e.clientX, y: e.clientY, at: Date.now() };
    },
    { capture: true, passive: true },
  );
}

export function originNow(): Point {
  if (Date.now() - pointer.at < 3500) return { x: pointer.x, y: pointer.y };
  return { x: window.innerWidth / 2, y: window.innerHeight * 0.45 };
}

export function emitCoins(amount: number, origin?: Point) {
  if (!Number.isFinite(amount) || amount <= 0) return;
  const o = origin || originNow();
  const count = Math.max(4, Math.min(16, Math.round(amount * 1.6)));
  if (!burstListeners.size) return;
  pending += amount;
  notifyPending();
  const burst: CoinBurst = { id: ++seq, amount, count, x: o.x, y: o.y };
  burstListeners.forEach((fn) => fn(burst));
}

// ————— صدا —————
const SOUND_KEY = 'nasr-sound';
let soundOn = (() => {
  try {
    return localStorage.getItem(SOUND_KEY) !== 'off';
  } catch {
    return true;
  }
})();
let audio: AudioContext | null = null;

export const soundEnabled = () => soundOn;
export function watchSound(fn: () => void) {
  soundListeners.add(fn);
  return () => {
    soundListeners.delete(fn);
  };
}
export function setSound(on: boolean) {
  soundOn = on;
  try {
    localStorage.setItem(SOUND_KEY, on ? 'on' : 'off');
  } catch {
    /* ذخیره‌سازی اختیاری است */
  }
  soundListeners.forEach((fn) => fn());
}

// صدای «چینگ» سکه؛ هر سکهٔ پشت‌سرهم کمی زیرتر می‌شود
export function playCoin(step = 0) {
  if (!soundOn) return;
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    audio ||= new AC();
    const c = audio;
    if (c.state === 'suspended') void c.resume();
    const t = c.currentTime;
    const base = 1318.5 * Math.pow(2, Math.min(step, 8) / 12);
    for (const [freq, delay] of [
      [base, 0],
      [base * 1.5, 0.075],
    ] as const) {
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + delay);
      gain.gain.setValueAtTime(0.0001, t + delay);
      gain.gain.exponentialRampToValueAtTime(0.06, t + delay + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + 0.3);
      osc.connect(gain);
      gain.connect(c.destination);
      osc.start(t + delay);
      osc.stop(t + delay + 0.32);
    }
  } catch {
    /* صدا اختیاری است */
  }
}

export function reducedMotion() {
  if (typeof window === 'undefined') return false;
  return window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || document.documentElement.classList.contains('motion-off');
}
